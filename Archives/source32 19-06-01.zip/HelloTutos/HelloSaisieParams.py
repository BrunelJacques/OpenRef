# !/usr/bin/env python
# -*- coding: utf-8 -*-

#----------------------------------------------------------------------------
# Application :    Projet XPY, gestion d'une grille de saisie PropertyGrid
# Auteurs:          Jacques BRUNEL, d'après Yvan LUCAS Noethys
# Copyright:       (c) 2019-04     Cerfrance Provence, Matthania
# Licence:         Licence GNU GPL
#----------------------------------------------------------------------------

import wx
import sys
import wx.propgrid as wxpg
import copy

class Bouton_reinitialisation(wx.Button):
    def __init__(self, parent, ctrl_parametres=None):
        wx.Button.__init__(self,parent, -1, "Reinit")
        self.ctrl_parametres = ctrl_parametres
        self.SetToolTip(("Cliquez ici pour réinitialiser tous les paramètres"))
        self.Bind(wx.EVT_BUTTON, self.OnBouton)

    def OnBouton(self, event):
        self.ctrl_parametres.Reinitialisation()

class Bouton_sauvegarde(wx.Button):
    def __init__(self, parent, ctrl_parametres=None):
        wx.Button.__init__(self, parent, -1,"Sauve")
        self.ctrl_parametres = ctrl_parametres
        self.SetToolTip(("Cliquez ici pour mémoriser tous les paramètres"))
        self.Bind(wx.EVT_BUTTON, self.OnBouton)

    def OnBouton(self, event):
        self.ctrl_parametres.OnSauvegarde(event)

    # ************************   Pour Test    *******************************

class CTRL(wxpg.PropertyGrid) :
    def __init__(self, parent, matrice={}, valeursDefaut={}, style=wxpg.PG_SPLITTER_AUTO_CENTER):
        wxpg.PropertyGrid.__init__(self, parent, -1, style=style)
        self.parent = parent
        self.dictValeursDefaut = valeursDefaut

        couleurFond = "#e5ecf3"
        self.SetCaptionBackgroundColour(couleurFond)
        self.SetMarginColour(couleurFond)

        self.Bind( wxpg.EVT_PG_CHANGED, self.OnPropGridChange )
        
        # Remplissage de la matrice
        self.InitMatrice(matrice)
        
        # Remplissage des valeurs
        self.SetDictValeurs(self.dictValeursDefaut)

    def OnPropGridChange(self, event):
        event.Skip()

    def InitMatrice(self,matrice={}):
        # Compose la grille de saisie des paramètres selon le dictionnaire matrice
        for categorie in matrice:
            # Chapitre
            if isinstance(categorie,str):
                self.Append(wxpg.PropertyCategory(categorie))

                for ligne in matrice[categorie]:
                    if 'genre' in ligne:
                        if ligne['genre'].lower() in ['enum','combo']:
                            propriete = wxpg.EnumProperty(label= ligne['label'], name=ligne['name'], labels=ligne['labels'], values=ligne['values'], value=ligne['value'])
                        elif ligne['genre'].lower() == 'multichoice':
                            propriete = wxpg.MultiChoiceProperty(label= ligne['label'], name=ligne['name'], choices=ligne['labels'], value=ligne['value'])
                        elif ligne['genre'].lower() in ['bool','check']:
                            propriete = wxpg.BoolProperty(label= ligne['label'], name=ligne['name'],value=ligne['value'])
                            self.UseCheckbox = 1

                        else:
                            commande = "wxpg." + ligne['genre']+"Property(label= ligne['label'], name=ligne['name'], value=ligne['value'])"
                            propriete = eval(commande)
                        if 'help' in ligne and ligne['genre'] != 'Bool':
                            propriete.SetHelpString(ligne['help'])
                        self.Append(propriete)
                        if ligne['genre'] == 'Bool':
                            self.SetPropertyAttribute(ligne['name'], "UseCheckbox", True)

    def Reinitialisation(self):
        dlg = wx.MessageDialog(None, ("Souhaitez-vous vraiment réinitialiser tous les paramètres ?"), ("Paramètres par défaut"), wx.YES_NO|wx.NO_DEFAULT|wx.CANCEL|wx.ICON_QUESTION)
        reponse = dlg.ShowModal() 
        dlg.Destroy()
        if reponse == wx.ID_YES :
            self.SetDictValeurs(self.dictValeursDefaut)

    def SetDictValeurs(self,valeurs={}):
        # Alimente les valeurs dans la grille
        for nom,valeur in valeurs.items():
            propriete = self.GetPropertyByName(nom)
            propriete.SetValue(valeur)

    def GetDictValeurs(self) :
        return self.GetPropertyValues()

class Panel(wx.Panel):
    def __init__(self, parent, *args, matrice={}, donnees={}, lblbox="Paramètres", **kwds):
        wx.Panel.__init__(self,*args, **kwds)

        self.parent = parent
        self.ctrl = CTRL(self,matrice,donnees)
        self.bouton_action = Bouton_sauvegarde(self, self.parent)
        self.bouton_reinit = Bouton_reinitialisation(self, self.ctrl)
        cadre_staticbox = wx.StaticBox(self,-1,label=lblbox)
        topbox = wx.StaticBoxSizer(cadre_staticbox,wx.HORIZONTAL)
        topbox.Add(self.ctrl,1,wx.ALL|wx.EXPAND,4)
        droite_flex = wx.FlexGridSizer(2,1,0,0)
        droite_flex.Add(self.bouton_action, 0, wx.ALL|wx.TOP, 4)
        droite_flex.Add(self.bouton_reinit, 0, wx.ALL|wx.TOP, 4)
        topbox.Add(droite_flex,0,wx.ALL|wx.TOP,1)
        topbox.MinSize = (300,400)
        self.SetSizerAndFit(topbox)

class Frame(wx.Frame):
    def __init__(self, *args, matrice={}, donnees={}, btnaction=None, lblbox="Paramètres", **kwds):
        wx.Frame.__init__(self,*args, **kwds)
        panel = Panel(self, self, -1, matrice=matrice, donnees=donnees, lblbox=lblbox)
        sizer_1 = wx.BoxSizer(wx.VERTICAL)
        sizer_1.Add(panel, 1, wx.ALL|wx.EXPAND,4)
        self.MinSize = (800,600)

        btnaction = wx.Button(self, -1, "Action")
        if btnaction:
            sizer_1.Add(btnaction,0,0,0)
            self.Bind(wx.EVT_BUTTON, self.OnBoutonAction, btnaction)
        self.SetBackgroundColour(wx.WHITE)
        self.SetSizerAndFit(sizer_1)
        self.Layout()
        self.CentreOnScreen()

    def OnSauvegarde(self, event):
        #Bouton Test
        print("Bonjour l'action de sauvegarde dans la frame")

    def OnBoutonAction(self, event):
        #Bouton Test
        print("Bonjour l'action OnBoutonAction de l'appli")

if __name__ == '__main__':
    app = wx.App(0)
    dictDonnees = {'memoriser': 2, 'ouiNon': False, 'monTexte': "élève", 'choix': ["choix2", "choix3"]}
    dictMatrice = {
        # Chapitre  = categorie ou box verticale
        "Mémorisation": [
            # Alinea 11 = ligne dans la box
            {'genre': 'Enum', 'name': 'memoriser', 'label': 'Mémoriser les paramètres', 'value': 3,
             'labels': ["Non", "Oui", "Peut-être"], 'values': [0, 1, 3],
             'help': 'Faut-il mémoriser les paramètres?'},
            # Alinea 12
            {'genre': 'Dir', 'name': 'repertoire', 'label': 'Choix du répertoire', 'value': '',
             'help': 'Veuillez choisir le répertoire'},
        ],
        # Chapitre 2
        "Autres éléments": [
            # Alinea 21 et suivants
            {'genre': 'Bool', 'name': 'ouiNon', 'label': 'Etes-vous oui ou non', 'value': True,
             'help': 'Cochez pour le oui'},
            {'genre': 'String', 'name': 'monTexte', 'label': 'Saisir un texte', 'value': '',
             'help': 'Saisir votre texte'},
            {'genre': 'Int', 'name': 'entier', 'label': 'Saisir un entier', 'value': 0,
             'help': 'Saisir votre nombre entier'},
            {'genre': 'Float', 'name': 'float', 'label': 'Saisir un nombre réel', 'value': 0.0,
             'help': 'Saisir votre nombre réel'},
            {'genre': 'Colour', 'name': 'couleur', 'label': 'Choisir votre couleur', 'value': wx.Colour(255, 0, 0),
             'help': 'Saisir votre couleur préférée'},
            {'genre': 'MultiChoice', 'name': 'choix', 'label': 'Choix multiples', 'value': [],
             'labels': ["choix 1", "choix 2", "choix3"]},
        ]
    }
    frame_1 = Frame(None,title="mon titre", matrice=dictMatrice, donnees=dictDonnees)
    app.SetTopWindow(frame_1)
    frame_1.Show()
    app.MainLoop()

