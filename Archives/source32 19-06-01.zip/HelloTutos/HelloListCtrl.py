import wx

########################################################################
class MyForm(wx.Frame):

    #----------------------------------------------------------------------
    def __init__(self):
        wx.Frame.__init__(self, None, wx.ID_ANY, "List Control Tutorial")

        # Add a panel so it looks the correct on all platforms
        panel = wx.Panel(self, wx.ID_ANY)
        self.index = 0

        self.list_ctrl = wx.ListCtrl(panel, -1, style=wx.LC_REPORT|wx.LC_SINGLE_SEL)
        #self.list_ctrl = wx.ListCtrl(panel, size=(-1,100), style=wx.LC_REPORT |wx.BORDER_SUNKEN )
        #self.list_ctrl.InsertColumn(0, 'Subject')
        #self.list_ctrl.InsertColumn(1, 'Due')
        #self.list_ctrl.InsertColumn(2, 'Location', width=125)
        self.list_ctrl.AppendColumn('Subject',wx.LIST_FORMAT_LEFT,width=100)
        self.list_ctrl.AppendColumn('Due',wx.LIST_FORMAT_LEFT,width=100)
        self.list_ctrl.AppendColumn('Location',wx.LIST_FORMAT_LEFT,width=100)
        self.list_ctrl.AppendColumn('Colonne 4',wx.LIST_FORMAT_LEFT,width=100)

        btn = wx.Button(panel, label="Add Line")
        btn2 = wx.Button(panel, label="Get Data")
        btn.Bind(wx.EVT_BUTTON, self.add_line)
        btn2.Bind(wx.EVT_BUTTON, self.getColumn)

        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.list_ctrl, 0, wx.ALL|wx.EXPAND, 5)
        sizer.Add(btn, 0, wx.ALL|wx.CENTER, 5)
        sizer.Add(btn2, 0, wx.ALL|wx.CENTER, 5)
        panel.SetSizer(sizer)

    #----------------------------------------------------------------------
    def add_line(self, event):
        line = "Line %s" % self.index
        #self.list_ctrl.InsertItem(self.index, line)
        #self.list_ctrl.SetItem(self.index, 1, "01/19/2010")
        #self.list_ctrl.SetItem(self.index, 2, "USA")
        self.list_ctrl.Append(("un", 'autre', 'ligne Append',1))
        self.list_ctrl.Append(['mon serveur', '', 'moi-meme', 1])
        self.index += 2

    #----------------------------------------------------------------------
    def getColumn(self, event):
        # probleme de terminologie : un item est une ligne dans la fonction Insert, mais un seul element dans les fonctions Set et Get
        # la fonction Append permet de remplir la ligne, je n'ai pas trouve une fonction inverse il faut boucler
        """"""
        count = self.list_ctrl.GetItemCount()
        cols = self.list_ctrl.GetColumnCount()
        for row in range(count):
            for col in range(cols):
                item = self.list_ctrl.GetItem(row, col)
                print(item.GetText())

#----------------------------------------------------------------------
# Run the program
if __name__ == "__main__":
    app = wx.App(False)
    frame = MyForm()
    frame.Show()
    app.MainLoop()
