# !/usr/bin/env python
# -*- coding: utf-8 -*-

#----------------------------------------------------------------------------
# Application :    Projet XPY, Panel contenant des objets de saisie et ctrl
# Auteurs:          Jacques BRUNEL
# Copyright:       (c) 2019-04     Cerfrance Provence, Matthania
# Licence:         Licence GNU GPL
#----------------------------------------------------------------------------

import wx
import os


class BoxPanel(wx.Panel):
    def __init__(self, parent, *args, lblbox="Box", **kwds):
        wx.Panel.__init__(self,parent,*args, **kwds)
        self.parent = parent

        self.btn1 = wx.Button(self, -1, lblbox, size=(60, 60))
        topbox = wx.BoxSizer(wx.HORIZONTAL)
        topbox.Add(self.btn1, 1, wx.ALL | wx.EXPAND, 4)
        self.SetSizerAndFit(topbox)

class TopPanel(wx.Panel):
    def __init__(self, parent, *args, lblbox="CadreTop", **kwds):
        wx.Panel.__init__(self,parent,*args, **kwds)
        self.parent = parent

        self.btn1 = wx.Button(self, -1, 'TopPanel', size=(60, 60))
        self.box1 = BoxPanel(self,-1,lblbox = "Box1")
        self.box2 = BoxPanel(self,-1,lblbox = "Box2")

        cadre_staticbox = wx.StaticBox(self,-1,label=lblbox)
        topbox = wx.StaticBoxSizer(cadre_staticbox,wx.HORIZONTAL)
        topbox.Add(self.btn1, 1, wx.ALL | wx.EXPAND, 4)
        topbox.Add(self.box1, 1, wx.ALL | wx.EXPAND, 4)
        topbox.Add(self.box2, 1, wx.ALL | wx.EXPAND, 4)
        self.SetSizerAndFit(topbox)


#************************   Pour Test  ou modèle  *******************************
class myFrame(wx.Frame):
    def __init__(self, *args, **kwds):
        listArbo=os.path.abspath(__file__).split("\\")
        titre = listArbo[-1:][0] + "/" + self.__class__.__name__
        wx.Frame.__init__(self,*args, title=titre, **kwds)

        self.topPnl = TopPanel(self,-1)
        self.btn0 = wx.Button(self, -1, "Frame")
        marge = 10
        sizer_1 = wx.BoxSizer(wx.VERTICAL)
        sizer_1.Add(self.btn0, 0, wx.LEFT|wx.ALIGN_TOP,marge)
        sizer_1.Add(self.topPnl, 0, wx.LEFT|wx.ALIGN_TOP,marge)
        self.SetSizer(sizer_1)
        #self.Layout()
        self.CentreOnScreen()

if __name__ == '__main__':
    app = wx.App(0)
    frame_1 = myFrame(None)
    #frame_1 = myFrame(None, )
    app.SetTopWindow(frame_1)
    frame_1.Show()
    app.MainLoop()
