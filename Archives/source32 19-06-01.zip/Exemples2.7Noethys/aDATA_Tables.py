#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-
#-----------------------------------------------------------
# Application :    Matthania
# Auteur:          Jacques BRUNEL
# Licence:         Licence GNU GPL
# Cr�ation des tables complementaires
#-----------------------------------------------------------

TABLES_IMPORTATION_OBLIGATOIRES = []


DB_DATA = {
        "matTarifs"   :    [
            ("trfCamp",   "varchar(50)",   u"noethys.activites.abrege"),
            ("trfGroupe",   "varchar(100)",   u"noethys.groupe.abrege"),
            ("trfCategorieTarif",   "varchar(200)",   u"noethys.categorie_tarifs.nom"),
            ("trfCodeTarif",   "varchar(16)",   u"matTarifsNoms.trnCodeTarif"),
            ],   # fin de     matTarifs
        "matTarifsNoms"   :    [
            ("trnCodeTarif",   "varchar(16)",   u"matTarifs.trfCodeTarif"),
            ("trnLibelle",   "varchar(128)",   u"Nom du tarif"),
            ],   # fin de     matTarifsNoms
        "matTarifsLignes"   :    [
            ("trlCodeTarif",   "varchar(16)",   u"Code tarif"),
            ("trlNoLigne",   "integer",   u"Ordre"),
            ("trlCodeArticle",   "varchar(16)",   u"R�f�rence article"),
            ],   # fin de     matTarifsLignes
        "matArticles"   :    [
            ("artCodeArticle",   "varchar(16)",   u"ID_Article"),
            ("artLibelle",   "varchar(128)",   u"Nom de l'article"),
            ("artConditions",   "varchar(16)",   u"Condition de blocage ou d'alerte"),
            ("artModeCalcul",   "varchar(16)",   u"Calcul pour g�n�rer des lignes, peut modifier le libell�, et propose une quantit� et un prix en fonction du context"),
            ("artPrix1",   "float",   u"Prix de base actualis� chaque ann�e"),
            ("artPrix2",   "float",   u"Pour les cas ou un deuxi�me prix est n�cessaire au calcul"),
            ("artCodeBlocFacture",   "varchar(16)",   u"matBlocsFactures.LFA_CodeBlocFacture      Pour Regroupement sur les lignes de facturation"),
            ("artCodeComptable",   "varchar(16)",   u"matPlanComptable.PCT_CodeComptable   Pour Regroupement dans la compta par l'interm�diaire d'une table naturecomptabl"),
            ],   # fin de     matArticles
        "matBlocsFactures"   :    [
            ("lfaCodeBlocFacture",   "varchar(16)",   u"Code du bloc regroupement sur ligne facture"),
            ("lfaTypeLigne",   "varchar(16)",   u"Comportement de la ligne"),
            ("lfaOrdre",   "integer",   u"Agencement des lignes sur la facture"),
            ("lfaLibelle",   "varchar(128)",   u"Libelle de la ligne sur la facture"),
            ("lfaFormat",   "varchar(16)",   u"Style de police"),
            ],   # fin de     matBlocsFactures
        "matPlanComptable"   :    [
            ("pctCodeComptable",   "varchar(16)",   u"Numero compte gescom"),
            ("pctLibelle",   "varchar(128)",   u"D�signation de la nature comptable"),
            ("pctCompte",   "varchar(16)",   u"Num�ro de compte dans la compa"),
            ],   # fin de     matPlanComptable
        "matPieces"   :    [
            ("pieIDnumPiece",   "integer primary key autoincrement",   u"Num�ro de pi�ce unique"),
            ("pieIDinscription",   "integer",   u"Ref inscription"),
            ("pieIDindividu",   "integer",   u"Participant"),
            ("pieIDfamille",   "integer",   u"Famille qui demande l'inscription"),
            ("pieIDcomptePayeur",   "integer",   u"Famille qui paye"),
            ("pieIDactivite",   "integer",   u"activit�"),
            ("pieIDgroupe",   "integer",   u"groupe"),
            ("pieIDcategorie_tarif",   "integer",   u"cat�gorie de tarification"),
            ("pieDateCreation",   "date",   u"Date de Premi�re action"),
            ("pieUtilisateurCreateur",   "varchar(16)",   u"Premier utilisateur"),
            ("pieDateModif",   "date",   u"Date de derni�re action"),
            ("pieUtilisateurModif",   "varchar(16)",   u"Dernier utilisateur"),
            ("pieNature",   "varchar(8)",   u"Nature devis reserv. Facture avoir"),
            ("pieEtat",   "varchar(8)",   u"Etat imprim�, transf�r� facture et avoir"),
            ("pieDateFacturation",   "date",   u"Date de la facture"),
            ("pieNoFacture",   "varchar(16)",   u"Num�ro de la facture"),
            ("pieDateEcheance",   "date",   u"date �ch�ance"),
            ("pieDateAvoir",   "date",   u"Date de l'annulation"),
            ("pieNoAvoir",   "varchar(16)",   u"Num�ro d'avoir"),
            ("pieCommentaire",   "blob",   u"Commentaire libre sur vie de la pi�ce"),
            ],   # fin de     matPieces
        "matPiecesLignes"   :    [
            ("ligIDnumLigne",   "integer primary key autoincrement",   u"Num�ro de ligne pi�ce unique"),
            ("ligIDnumPiece",   "integer",   u"r�f�rence de la pi�e"),
            ("ligDateCreaModif",   "date",   u"date de l'entr�e de la ligne"),
            ("ligUtilisateur",   "varchar(16)",   u"dernier utilisateur"),
            ("ligCodeArticle",   "varchar(16)",   u"article"),
            ("ligLibelle",   "varchar(128)",   u"libell� article modifi�"),
            ("ligQuantite",   "float",   u"quantit�"),
            ("ligPrixUnit",   "float",   u"prix unitaire"),
            ("ligMontant",   "float",   u"produit TTC"),
            ("ligCodeBlocFact",   "varchar(16)",   u"Regroupement sur ligne de facture"),
            ("ligCodeComptable",   "varchar(16)",   u"Regroupement comptable"),
            ],   # fin de     matPiecesLignes
        }

DB_PK = {
        "PK_matArticles_artCodeArticle"  :  {"table"  :  "matArticles",  "champ" : "artCodeArticle", },
        "PK_matBlocsFactures_lfaCodeBlocFacture"  :  {"table"  :  "matBlocsFactures",  "champ" : "lfaCodeBlocFacture", },
        "PK_matPlanComptable_pctCodeComptable"  :  {"table"  :  "matPlanComptable",  "champ" : "pctCodeComptable", },
        "PK_matTarifs_trfCamp"  :  {"table"  :  "matTarifs",  "champ" : "'trfCamp','trfGroupe','trfCategorieTarif'", },
        "PK_matTarifsLignes_trlCodeTarif"  :  {"table"  :  "matTarifsLignes",  "champ" : "trlCodeTarif", },
        "PK_matTarifsNoms_trnCodeTarif"  :  {"table"  :  "matTarifsNoms",  "champ" : "trnCodeTarif", },
        }
DB_INDEX = {
        "IX_matArticles_artCodeComptable"  :  {"table"  :  "matArticles",  "champ" : "artCodeComptable", },
        "IX_matArticles_artCodeBlocFacture"  :  {"table"  :  "matArticles",  "champ" : "artCodeBlocFacture", },
        "IX_matArticles_artConditions"  :  {"table"  :  "matArticles",  "champ" : "artConditions", },
        "IX_matArticles_artModeCalcul"  :  {"table"  :  "matArticles",  "champ" : "artModeCalcul", },
        "IX_matBlocsFactures_lfaTypeLigne"  :  {"table"  :  "matBlocsFactures",  "champ" : "lfaTypeLigne", },
        "IX_matBlocsFactures_lfaOrdre"  :  {"table"  :  "matBlocsFactures",  "champ" : "lfaOrdre", },
        "IX_matPieces_pieDateAvoir"  :  {"table"  :  "matPieces",  "champ" : "pieDateAvoir", },
        "IX_matPieces_pieDateEcheance"  :  {"table"  :  "matPieces",  "champ" : "pieDateEcheance", },
        "IX_matPieces_pieDateFacturation"  :  {"table"  :  "matPieces",  "champ" : "pieDateFacturation", },
        "IX_matPieces_pieDateModif"  :  {"table"  :  "matPieces",  "champ" : "pieDateModif", },
        "IX_matPieces_pieIDactivite"  :  {"table"  :  "matPieces",  "champ" : "pieIDactivite", },
        "IX_matPieces_pieIDcategorie_tarif"  :  {"table"  :  "matPieces",  "champ" : "pieIDcategorie_tarif", },
        "IX_matPieces_pieIDcomptePayeur"  :  {"table"  :  "matPieces",  "champ" : "pieIDcomptePayeur", },
        "IX_matPieces_pieIDfamille"  :  {"table"  :  "matPieces",  "champ" : "pieIDfamille", },
        "IX_matPieces_pieIDgroupe"  :  {"table"  :  "matPieces",  "champ" : "pieIDgroupe", },
        "IX_matPieces_pieIDindividu"  :  {"table"  :  "matPieces",  "champ" : "pieIDindividu", },
        "IX_matPieces_pieIDinscription"  :  {"table"  :  "matPieces",  "champ" : "pieIDinscription", },
        "IX_matPieces_pieNoAvoir"  :  {"table"  :  "matPieces",  "champ" : "pieNoAvoir", },
        "IX_matPieces_pieNoFacture"  :  {"table"  :  "matPieces",  "champ" : "pieNoFacture", },
        "IX_matPiecesLignes_ligCodeArticle"  :  {"table"  :  "matPiecesLignes",  "champ" : "ligCodeArticle", },
        "IX_matPiecesLignes_ligCodeBlocFacture"  :  {"table"  :  "matPiecesLignes",  "champ" : "ligCodeBlocFacture", },
        "IX_matPiecesLignes_ligCodeComptable"  :  {"table"  :  "matPiecesLignes",  "champ" : "ligCodeComptable", },
        "IX_matPiecesLignes_ligIDnumPiece"  :  {"table"  :  "matPiecesLignes",  "champ" : "ligIDnumPiece", },
        "IX_matTarifs_trfCodeTarif"  :  {"table"  :  "matTarifs",  "champ" : "trfCodeTarif", },
        "IX_matTarifsLignes_trlCodeArticle"  :  {"table"  :  "matTarifsLignes",  "champ" : "trlCodeArticle", },
        }

if __name__ == "__main__":
    """ Affichage de stats sur les tables """
    nbreChamps = 0
    for nomTable, listeChamps in DB_DATA.iteritems() :
        nbreChamps += len(listeChamps)
    print "Nbre de champs DATA =", nbreChamps
    print "Nbre de tables DATA =", len(DB_DATA.keys())
