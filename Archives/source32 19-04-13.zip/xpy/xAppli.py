# !/usr/bin/env python
# -*- coding: utf-8 -*-

#------------------------------------------------------------------------
# Application :    Projet XPY, atelier de développement
# Auteurs:          Jacques BRUNEL,
# Copyright:       (c) 2019-04     Cerfrance Provence, Matthania
# Licence:         Licence GNU GPL
#------------------------------------------------------------------------

import wx
import os
import sys

def CrashReport(fichierLog):
    # Crash report
    #UTILS_Rapport_bugs.Activer_rapport_erreurs(version=VERSION_APPLICATION)
    print('Bonjour CrashReport')

    # Supprime le journal.log si supérieur à 10 Mo
    if os.path.isfile(fichierLog):
        taille = os.path.getsize(fichierLog)
        if taille > 5000000:
            os.remove(fichierLog)

class MainFrame(wx.Frame):
    def __init__(self, *args, **kw):
        super().__init__(*args, **kw)
        # Vérifie le path xpy
        self.pathXpy = os.path.dirname(os.path.abspath(__file__))
        if not self.pathXpy in sys.path:
            sys.path = [self.pathXpy] + sys.path

    def xInit(self):
        print("Lancement %s"%self.dictAPPLI["NOM_APPLICATION"])
        nbModules = len(os.listdir(self.pathSrcAppli))
        if nbModules > 0:
            print('présence de %d fichiers dans %s'%(nbModules,self.pathSrcAppli))
        else:
            print('echec test de présence %s'%self.pathSrcAppli)

        # Vérifie l'existence des répertoires
        for rep in (self.pathSrcAppli+"\\Data", self.pathSrcAppli+"\\Temp"):
            if os.path.isdir(rep) == False:
                os.makedirs(rep)
                print("Creation du repertoire : ", rep)
        return wx.OK

    def MakeHello(self,message):
        self.topPanel = wx.Panel(self)
        self.topContenu = wx.StaticText(self.topPanel, label=message, pos=(25, 25))
        font = self.topContenu.GetFont()
        font.PointSize += 5
        font = font.Bold()
        self.topContenu.SetFont(font)

    def MakeMenuBar(self):
        """
        A menu bar is composed of menus, which are composed of menu items.
        This method builds a set of menus and binds handlers to be called
        when the menu item is selected.
        """
        try:
            from menu import MENU
            self.menuFile = MENU
            self.dictMenu = MENU.ParamMenu(self)
        except:
            print('echec ouverture menu.py')

        # Création du menu dernière branche
        def CreationItem(menuParent, item):
            id = wx.NewId()
            if "genre" in item.keys():
                genre = item["genre"]
            else :
                genre = wx.ITEM_NORMAL
            itemMenu = wx.MenuItem(parentMenu=menuParent, id = id, text = item["label"], helpString=item["infobulle"], kind = genre)
            if "actif" in item.keys() :
                itemMenu.Enable(item["actif"])
            if "image" in item.keys() :
                ptImage = (str(self.pathXpy) + "/" + str(item["image"])).replace("\\","/")
                itemMenu.SetBitmap(wx.Bitmap(ptImage, wx.BITMAP_TYPE_PNG))
            ctrl = menuParent.Append(itemMenu)

            self.Bind(wx.EVT_MENU, eval("self.menuFile.%s"%item["action"]), id=id)

            #self.Bind(wx.EVT_MENU, self.OnAction, id=id)
            self.dictInfosMenu[item["code"]] = {"id" : id, "ctrl" : ctrl}

        # Déroulé des branches du menu
        def CreationMenu(menuParent, item, sousmenu=False):
            menu = wx.Menu()
            id = wx.NewId()
            for sousitem in item["items"]:
                if sousitem == "-":
                    menu.AppendSeparator()
                elif "items" in sousitem.keys():
                    CreationMenu(menu, sousitem, sousmenu=True)
                else:
                    CreationItem(menu, sousitem)
            if sousmenu == True:
                ctrl = menuParent.AppendSubMenu( menu, item["label"])
            else:
                ctrl = menuParent.Append(menu, item["label"])
            self.dictInfosMenu[item["code"]] = {"id": id, "ctrl": ctrl}

        # Racine du menu
        self.menu = wx.MenuBar()
        self.dictInfosMenu = {}
        # Pour chaque colonne
        for item in self.dictMenu:
            CreationMenu(self.menu, item)

        # Give the menu bar to the frame
        self.SetMenuBar(self.menu)

#-----------------------------------------------------------
        """
        # The "\t..." syntax defines an accelerator key that also triggers
        # the same event
        fileMenu = wx.Menu()
        action11 = fileMenu.Append(-1, "&Action11\tCtrl-H",
                "L'action 11 produit un message Box!")
        action12 = fileMenu.Append(-1, "&Action12\tCtrl-A",
                "L'action 12 produit un message Box!")
        fileMenu.AppendSeparator()
        # When using a stock ID we don't need to specify the menu item's
        # label
        exitItem = fileMenu.Append(wx.ID_EXIT)

        # Now a help menu for the about item
        helpMenu = wx.Menu()
        aboutItem = helpMenu.Append(wx.ID_ABOUT)

        # Make the menu bar and add the two menus to it. The '&' defines
        # that the next letter is the "mnemonic" for the menu item. On the
        # platforms that support it those letters are underlined and can be
        # triggered from the keyboard.
        menuBar = wx.MenuBar()
        menuBar.Append(fileMenu, "&Fichier")
        menuBar.Append(helpMenu, "&Info")

        # Give the menu bar to the frame
        self.SetMenuBar(menuBar)

        # Finally, associate a handler function with the EVT_MENU event for
        # each of the menu items. That means that when that menu item is
        # activated then the associated handler function will be called.
        self.Bind(wx.EVT_MENU, self.OnAction11, action11)
        self.Bind(wx.EVT_MENU, self.OnAction12, action12)
        self.Bind(wx.EVT_MENU, self.OnExit,  exitItem)
        self.Bind(wx.EVT_MENU, self.OnAbout, aboutItem)
        """

    def OnExit(self, event):
        """Close the frame, terminating the application."""
        self.Close(True)

    def OnAction(self, event, clic):
        """Say Action11 to the user."""
        wx.MessageBox("Action from menu : %s"%clic)

    def OnAbout(self, event):
        """Display an About Dialog"""
        wx.MessageBox("This is a wxPython Action11 World sample",
                      "About Action11 World 2",
                      wx.OK|wx.ICON_INFORMATION)

class MyApp(wx.App):
    pass
    #def OnInit(self):

if __name__ == "__main__":
    # Lancement de l'application
    app = MyApp()
    frm = MainFrame(None, title='xPY morceaux choisis')
    frm.dictAPPLI = {
        'NOM_APPLICATION': "myAppli",
        'REP_SOURCES': "srcMyAppli",}
    frm.pathSrcAppli = 'c:/temp/'
    frm.xInit()
    frm.MakeHello("OK test")
    frm.Show()
    app.MainLoop()
