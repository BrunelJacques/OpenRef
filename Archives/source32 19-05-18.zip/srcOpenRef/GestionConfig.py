# !/usr/bin/env python
# -*- coding: utf-8 -*-

#----------------------------------------------------------------------------
# Application :    Projet OpenRef, gestion d'identification
# Auteurs:          Jacques BRUNEL
# Copyright:       (c) 2019-05     Cerfrance Provence
# Licence:         Licence GNU GPL
#----------------------------------------------------------------------------

import wx
import os
import xpy.xGestionConfig as xgc
import xpy.xUTILS_SaisieParams as xusp
import xpy.xUTILS_Config as xucfg
import xpy.xGestionDB as xdb

MATRICE_CHOIX = {
("choix_config","Choisissez votre configuration"):[
    {'name': 'config', 'genre': 'Enum', 'label': 'Localisation','value':'LCtraitements', 'values':['LCtraitements','La Crau','AlpesMed','Local'],
                        'help': "Le bouton de droite vous permet de créer une nouvelle configuration"},
    {'name': 'compta', 'genre': 'Enum', 'label': 'logiciel compta','value':'quadratus', 'values':['quadratus'],
                        'help': 'Type de comptabilité'},
    ]}

IMPLANTATIONS = {
        'LCtraitements':'//srvprint/qappli/quadra/datadouble',
        'La Crau':      '//srvprint/qappli/quadra/database',
        'AlpesMed':     '//srvtse/qappli$/quadra/database',
        'Local':        'c:/quadra/database'}

#************************   Gestion de l'identification initiale *****************

class DLG_implantation(wx.Dialog):
    # Ecran de saisie de paramètres en dialog
    def __init__(self, parent, *args, **kwds):
        listArbo=os.path.abspath(__file__).split("\\")
        titre = listArbo[-1:][0] + "/" + self.__class__.__name__
        wx.Dialog.__init__(self, parent, -1,title = titre,
                           style=wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER)
        self.parent = parent
        cadre_staticbox = wx.StaticBox(self, -1)
        topbox = wx.StaticBoxSizer(cadre_staticbox, wx.VERTICAL)
        self.btn = xusp.BTN_fermer(self)
        self.btn.Bind(wx.EVT_BUTTON, self.OnFermer)
        self.btnTest = xusp.BTN_action(self,help='Test de la connexion réseau',image=wx.Bitmap("xpy/Images/100x30/Bouton_tester.png"))
        self.btnTest.Bind(wx.EVT_BUTTON, self.OnTest)

        def Affiche():
            code,label,lignes = xgc.AppelLgnesMatrice(None, MATRICE_CHOIX)
            # le nom de la configuration c'est le premier champ décrit dans la matrice
            self.codeConfig = code + '.' + lignes[0]['name']

            # simple texte
            self.titre =wx.StaticText(self, -1, "Accès aux bases compta")

            # contrôle gérant la saisie des paramètres de config
            self.ctrlConfig = xusp.BoxPanel(self, -1, lblbox=label, code=code, lignes=lignes)

            # adressage dans le fichier par défaut dans profilUser
            cfg = xucfg.ParamUser()
            self.choix= cfg.GetDict(dictDemande=None, groupe='IMPLANTATIONS', close=False)

            self.ctrlConfig.SetValues(self.choix)

            topbox.Add(self.titre, 0, wx.LEFT, 60)
            topbox.Add((20,20), 0, wx.ALIGN_TOP, 0)
            topbox.Add(self.ctrlConfig, 0, wx.ALIGN_TOP, 0)
            topbox.Add((40,40), 0, wx.ALIGN_TOP, 0)
            piedbox = wx.BoxSizer(wx.HORIZONTAL)
            piedbox.Add(self.btnTest, 0, wx.ALIGN_RIGHT, 0)
            piedbox.Add(self.btn, 0, wx.RIGHT|wx.ALIGN_RIGHT, 11)
            topbox.Add(piedbox, 0, wx.ALIGN_RIGHT, 0)

        Affiche()
        self.SetSizerAndFit(topbox)

    def OnTest(self,event):
        self.OnEnter(None)
        config = {'typeDB':'access','nameDB':'qgi.mdb'}
        pathGI = IMPLANTATIONS[self.choix['config']]+ '/gi/0000/'
        config['serveur'] = pathGI
        DB = xdb.DB(config = config)
        style = wx.ICON_WARNING
        try:
            nomBase = DB.nomBase
            if DB.echec == 0: style = wx.ICON_INFORMATION
            retour = ['avec','sans'][DB.echec]
            mess = "L'accès à la base '%s' s'est réalisé %s succès"%(nomBase,retour)
        except: mess = "Désolé "
        wx.MessageBox(mess,style=style)

    def OnFermer(self,event):
        # enregistre les valeurs de l'utilisateur
        cfg = xucfg.ParamUser()
        dic = self.ctrlConfig.GetValues()
        cfg.SetDict(dic, groupe='IMPLANTATIONS')
        self.Destroy()

    def OnEnter(self,event):
        #action evènement Enter sur le contrôle combo, correspond à un changement de choix
        self.choix = self.ctrlConfig.GetValues()
        cfg = xucfg.ParamUser()
        cfg.SetDict(self.choix, groupe='IMPLANTATIONS')

#************************   Pour Test ou modèle  *********************************
if __name__ == '__main__':
    app = wx.App(0)
    os.chdir("..")
    frame_1 = DLG_implantation(None)
    frame_1.Position = (50,50)
    app.SetTopWindow(frame_1)
    frame_1.Show()
    app.MainLoop()

