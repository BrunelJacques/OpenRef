# !/usr/bin/env python
# -*- coding: utf-8 -*-

import wx

class Foo(object):
    def __init__(self, value1, value2, *args,**kwds) :
        # do something with the values
        print('2eme niveau les requis : ', value1, value2)
        for arg in args:
            print('2eme niveau en plus   : ', arg)
        for mot in kwds:
            print('2eme niveau des mots : ', mot)


class MyFoo(Foo):
    def __init__(self, *args, **kwds):
        # do something else, don't care about the args
        print('premier niveau : ',*args, kwds)

        self.kwds = kwds
        self.kwds['clandestin'] = "mot_clandestin"
        super(MyFoo, self).__init__(*args +('clandestin',), **self.kwds)


if __name__ == '__main__':
    app = wx.App()
    MyFoo('premier','dernier','surnombre', mot1 = 'premier_mot')
    app.MainLoop()