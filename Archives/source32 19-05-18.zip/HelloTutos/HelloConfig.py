# !/usr/bin/env python
# -*- coding: utf-8 -*-

# myconfig.py

import wx

class MyFrame(wx.Frame):
    def __init__(self, parent, id, title):
        pathCfg = '/reseau/'
        nomCfg = 'TestXPYConfig'

        """
        self.filehistory = wx.FileHistory(9) 
        self.fileConfig = wx.FileConfig(appName="ApplicationName", 
                                    vendorName="VendorName", 
                                    localFilename="file.cfg", 
                                    style=wx.CONFIG_USE_LOCAL_FILE) 
        self.filehistory.Load(self.fileConfig) 
        self.filehistory.UseMenu(file_menu) 
        self.filehistory.AddFilesToMenu()
        """


        wx.FileConfig(appName="", vendorName="",
                   localFilename="", globalFilename="",
                   style=wx.CONFIG_USE_LOCAL_FILE | wx.CONFIG_USE_GLOBAL_FILE)
        self.cfg = wx.FileConfig(nomCfg,localFilename="c:/temp/XPYConfig",style=wx.CONFIG_USE_LOCAL_FILE )
        self.cfg.SetPath(pathCfg)
        if self.cfg.Exists('TestXPYConfigwidth'):
            w, h = self.cfg.ReadInt('TestXPYConfigwidth'), self.cfg.ReadInt('TestXPYConfigheight')
        else:
            (w, h) = (250, 250)
        wx.Frame.__init__(self, parent, id, title, wx.DefaultPosition, wx.Size(w, h))

        wx.StaticText(self, -1, 'TestXPYConfigWidth:', (20, 20))
        wx.StaticText(self, -1, 'TestXPYConfigHeight:', (20, 70))
        self.sc1 = wx.SpinCtrl(self, -1, str(w), (140, 15), (60, -1), min=0, max=500)
        self.sc2 = wx.SpinCtrl(self, -1, str(h), (140, 65), (60, -1), min=0, max=500)
        wx.Button(self, 1, 'Save', (20, 120))

        self.Bind(wx.EVT_BUTTON, self.OnSave, id=1)
        self.statusbar = self.CreateStatusBar()
        self.Centre()
        self.statusbar.SetStatusText('Configuration saved in %s ' % nomCfg)

    def OnSave(self, event):
        self.cfg.Write("test string", "chaine")
        self.cfg.WriteInt("TestXPYConfigwidth", self.sc1.GetValue())
        self.cfg.WriteInt("TestXPYConfigheight", self.sc2.GetValue())
        self.statusbar.SetStatusText('Configuration saved')


class MyApp(wx.App):
    def OnInit(self):
        frame = MyFrame(None, -1, 'myconfig.py')
        frame.Show(True)
        self.SetTopWindow(frame)
        return True

app = MyApp(0)
app.MainLoop()
