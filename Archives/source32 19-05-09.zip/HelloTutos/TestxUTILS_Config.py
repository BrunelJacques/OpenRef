# !/usr/bin/env python
# -*- coding: iso-8859-15 -*-

#----------------------------------------------------------------------------
# Application :    Projet XPY, gestion des param�tres de configuration
# Auteurs:          Jacques BRUNEL,, d'apr�s Yvan LUCAS Noethys
# Copyright:       (c) 2019-04     Cerfrance Provence, Matthania
# Licence:         Licence GNU GPL
#----------------------------------------------------------------------------

import wx

class FichierConfig():
    def __init__(self, nomFichier = None):
        self.nomFichier = nomFichier

    def GetDictConfig(self):
        """ Recupere une copie du dictionnaire du fichier de config """
        import shelve
        db = shelve.open(self.nomFichier, "c")
        dictDonnees = {}
        for key in db.keys():
            dictDonnees[key] = db[key]
            #print key, db[key]
        db.close()
        return dictDonnees

    def SetDictConfig(self, dictConfig={} ):
        """ Remplace le fichier de config pr�sent sur le disque dur par le dict donn� """
        import shelve
        db = shelve.open(self.nomFichier, "n")
        for key in dictConfig.keys():
            db[key] = dictConfig[key]
        db.close()

    def GetItemConfig(self, key, defaut=None):
        """ R�cup�re une valeur du dictionnaire du fichier de config """
        import shelve
        db = shelve.open(self.nomFichier, "r")
        if key in db :
            valeur = db[key]
        else:
            valeur = defaut
        db.close()
        return valeur
    
    def SetItemConfig(self, key, valeur ):
        """ Remplace une valeur dans le fichier de config """
        import shelve
        db = shelve.open(self.nomFichier, "w")
        db[key] = valeur
        db.close()

    def DelItemConfig(self, key ):
        """ Supprime une valeur dans le fichier de config """
        import shelve
        db = shelve.open(self.nomFichier, "w")
        del db[key]
        db.close()

def GetParametre(nomParametre="", defaut=None):
    parametre = None
    try :
        topWindow = wx.GetApp().GetTopWindow()
        nomWindow = topWindow.GetName()
    except :
        nomWindow = None
    if nomWindow == "general" : 
        # Si la frame 'General' est charg�e, on y r�cup�re le dict de config
        if nomParametre in topWindow.userConfig:
            parametre = topWindow.userConfig[nomParametre]
        else :
            parametre = defaut
    else:
        # R�cup�ration du nom de la DB directement dans le fichier de config sur le disque dur
        nomFichierConfig = "C:/Noethys-master/source/Data/Config"
        cfg = FichierConfig(nomFichierConfig)
        parametre = cfg.GetItemConfig(nomParametre, defaut)
    return parametre

def SetParametre(nomParametre="", parametre=None):
    try :
        topWindow = wx.GetApp().GetTopWindow()
        nomWindow = topWindow.GetName()
    except :
        nomWindow = None
    if nomWindow == "general" : 
        # Si la frame 'General' est charg�e, on y r�cup�re le dict de config
        topWindow.userConfig[nomParametre] = parametre
    else:
        # Enregistrement du nom de la DB directement dans le fichier de config sur le disque dur
        nomFichierConfig = "C:/Noethys-master/source/Data/Config"
        cfg = FichierConfig(nomFichierConfig)
        cfg.SetItemConfig(nomParametre, parametre)

# --------------Traitement par lot ------------------------------------------------------------------------------------

def GetParametres(parametres=[]):
    """ dict parametres = {nom : valeur, nom: valeur...} """
    """ list ou tuple = [nom , nom] """
    """ l'absence de parametres veut dire : tous les possibles"""
    dictFinal = {}
    try :
        topWindow = wx.GetApp().GetTopWindow()
        nomWindow = topWindow.GetName()
    except :
        nomWindow = None
        
    # Cherche la sources des donn�es
    if nomWindow == "general" : 
        dictSource = topWindow.userConfig
    else :
        nomFichierConfig = "C:/Noethys-master/source/Data/Config"
        cfg = FichierConfig(nomFichierConfig)
        dictSource = cfg.GetDictConfig()
        
    # Lit les donn�es
    if isinstance(parametres, dict):
        lstNoms = parametres.keys()
    elif isinstance(parametres,(list, tuple)): lstNoms = parametres
    else: lstNoms = dictSource.keys()

    # l'absence de parametres veut dire tous les possibles
    if len(lstNoms) == 0 : lstNoms = dictSource.keys()

    for nom in lstNoms :
        if nom in dictSource:
            dictFinal[nom] = dictSource[nom]
        else:
            # par d�faut si la valeur demand�e n'�tait pas stock�e on retourne ce qui est arriv�
            if isinstance(parametres, dict): dictFinal[nom] = parametres[nom]
            else: dictFinal[nom] = None

    return dictFinal

def SetParametres(dictParametres={}):
    """ dictParametres = {nom : valeur, nom: valeur...} """
    try :
        topWindow = wx.GetApp().GetTopWindow()
        nomWindow = topWindow.GetName()
    except :
        nomWindow = None
    if nomWindow == "general" : 
        # Si la frame 'General' est charg�e, on y r�cup�re le dict de config
        for nom, valeur in dictParametres.items() :
            topWindow.userConfig[nom] = valeur
    else:
        # Enregistrement dans le fichier de config sur le disque dur
        nomFichierConfig = "C:/Noethys-master/source/Data/Config"
        cfg = FichierConfig(nomFichierConfig)
        cfg.SetDictConfig(dictParametres)
    return dictParametres

# --------------- TESTS -----------------------------------------------------------------------------------------------
if __name__ == u"__main__":
    from random import randrange
    #print("GET :", GetParametres({"test1" : None,"test3":'oubli�'} ))
    #print("SET :", SetParametres({"test11": randrange(0,100), "test12" : 125.77} ))
    print("GET :", GetParametres([]))

