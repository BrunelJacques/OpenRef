import wx
from wx import propgrid



class Page1(wx.Panel):
    def __init__(self, parent):
        wx.Panel.__init__(self, parent)

        self.panel = panel = wx.Panel(self, wx.ID_ANY)
        topsizer = wx.BoxSizer(wx.VERTICAL)

        self.pg = pg = propgrid.PropertyGrid(self,
                                             style=propgrid.PG_SPLITTER_AUTO_CENTER |
                                                   propgrid.PG_TOOLBAR)

        self.Bind(propgrid.EVT_PG_CHANGED, self.OnGridChangeEvent)

        vals1 = ['x', 'y', 'z']
        ix = range(len(vals1))
        pg.Append(propgrid.EnumProperty("Enum", 'enum', vals1, ix, 0))

        vals2 = ['a', 'b', 'c']
        self.pg_mcp = pg_mcp = propgrid.MultiChoiceProperty(label='MCP',
                                                            name='measurments',
                                                            choices=vals2, value=vals2)

        pg.Append(pg_mcp)

        topsizer.Add(pg, 1, wx.EXPAND, 5)

        self.SetSizer(topsizer)

    def OnGridChangeEvent(self, event):

        # grid = event.EventObject
        prop = event.GetProperty()
        if prop:

            print(prop.GetName())
            if (prop.GetName() == 'enum'):
                new_values = ['A', 'B', 'C']
                newChoices = propgrid.PGChoices(new_values)
                self.pg_mcp.SetChoices(newChoices)

                # Problem begins here ---PROBLEM BEGINS HERE

                # The following statements doesn't seem to do anything
                # ideally I want all the new_values to be set to the "selected"
                # state and appear as a list of items in the property grid
                # at the moment despite this call the text displayed
                # in the propperty grid for this item is blank
                # and when you click on the button of the MultiChoiceProperty
                # the new items are also not selected.  How to set the new items
                # to the selected state and have them appear in the text field of
                # the property grid corresponding to the MultiChoiceProperty?

                self.pg_mcp.SetChoiceSelection(1)

        return


class MainFrame(wx.Frame):
    def __init__(self, cfg=None, products=None, measurements=None):
        wx.Frame.__init__(self, None, title="")

        # Here we create a panel and a notebook on the panel
        p = wx.Panel(self)
        nb = wx.Notebook(p)

        # create the page windows as children of the notebook
        page1 = Page1(nb)

        # add the pages to the notebook with the label to show on the tab
        nb.AddPage(page1, "Input Datasets")
        sizer = wx.BoxSizer(wx.HORIZONTAL)
        sizer.Add(nb, 1, wx.EXPAND)

        p.SetSizer(sizer)
        self.Center()


class MyApp(wx.App):
    def OnInit(self):
        self.frame = MainFrame()
        self.frame.Show()
        return True


if __name__ == "__main__":
    app = MyApp(False)
    app.MainLoop()