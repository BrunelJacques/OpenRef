#!/usr/bin/env python
# -*- coding: utf8 -*-
import os

#afficher le répertoire de lancement de l'application
print("Répertoire courant : \t\t",os.getcwd())

# gérer des tabulations et des sauts de ligne
print("saut... \n\t\t\t ...de ligne")

# obtenir un nombre aléatoire
from random import randrange
print('mon alea du jour entre 0 et 99 c\'est : ', randrange(0,100))

# créer un chemin  pour y créer un fichier
chemin = 'c:/temp/cree/fichier'
chemin = chemin[0:2] + chemin[2:].replace('//', '/')
arboresc = chemin.split('/')
rep = ''
premier = True
for mot in arboresc[0:-1]:
    rep +=  mot +'/'
    # //serveur génère des '' dans la liste split et le nom du serveur ne doit pas être testé ni c:
    if mot != ''  :
        if not premier:
            if not os.path.exists(rep): os.makedirs(rep)
        premier = False
