
import win32com.client
"""Important: 32bit MS driver - 32bit python!"""
"""N'est pas compatible access 95, mais oui avec access 2002"""

db = 'c:/temp/test.mdb'
db = 'c:/quadra/database/gi/0000/qgi.mdb'
strsql = "select * from civilites;"

conn = win32com.client.Dispatch(r'ADODB.Connection')
DSN = ('PROVIDER = Microsoft.Jet.OLEDB.4.0;DATA SOURCE = ' + db +  ';')
conn.Open(DSN)

req0 = win32com.client.Dispatch(r'ADODB.Recordset')

#methode classique de déroulé d'un recordset
req0.Open(strsql, conn)
# le record Count ne fonctionne pas
print(req0.RecordCount)
while not req0.EOF:
    print(req0(0),"/",req0(1))
    req0.Move(1)
print('fin action1----------------------------')
req0.Close()

# utilisation de l'approche d'un accès par colonne
req0.Open(strsql, conn)
data = req0.GetRows()

recordset = []
for noLig in range(len(data[0])):
    record = []
    for noCol in range(len(data)):
        record.append(data[noCol][noLig])
    recordset.append(record)
for ligne in recordset:
    print(ligne)

conn.Close()

print('fin actiontest-------------------')




def Allocate_sub(self, event):
    import win32com
    import os
    pth = os.getcwd()
    myDb = pth + '\\myAccessDB.accdb'
    DRV = '{Microsoft Access Driver (*.mdb)}'
    PWD = 'pw'
    # connect to db
    con = win32com.client.Dispatch(r'ADODB.Connection')
    con.Open('DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=%s' % (myDb))
    cDataset = win32com.client.Dispatch(r'ADODB.Recordset')
    #cDataset.Open("Allocated_Subs", con, 3, 3, 1)
    cDataset.Open("Allocated_Subs", con, 3, 3, 1)
    cDataset.AddNew()
    cDataset.Fields.Item("Subject").Value = "abc"
    cDataset.Fields.Item("UniqueKey").Value = "xyzabc"
    cDataset.Update()
    cDataset.close()
    con.close()