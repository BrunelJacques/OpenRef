# !/usr/bin/env python
# -*- coding: utf-8 -*-

#----------------------------------------------------------------------------
# Application :    Projet XPY, gestion d'identification
# Auteurs:          Jacques BRUNEL
# Copyright:       (c) 2019-04     Cerfrance Provence, Matthania
# Licence:         Licence GNU GPL
#----------------------------------------------------------------------------

import wx
import os
import xpy.xUTILS_SaisieParams as xusp
import xpy.xUTILS_Config as xuconf


MATRICE_IDENT = {
("ident","Votre session"):[
    {'name': 'domaine', 'genre': 'String', 'label': 'Votre organisation', 'value': "NomDuPC",
                        'help': 'Ce préfixe à votre nom permet de vous identifier'},
    {'name': 'utilisateur', 'genre': 'String', 'label': 'Votre identifiant', 'value': "NomSession",
                        'help': 'Confirmez le nom de sesssion de l\'utilisateur'},
    ],
}
MATRICE_CHOIX = {
("choix_config","Choisissez votre configuration"):[
    {'name': 'config', 'genre': 'Enum', 'label': 'Configuration active',
                        'help': "Le bouton de droite vous permet de créer une nouvelle configuration",
                        'btnLabel':"...", 'btnHelp':"Cliquez pour gérer les configurations",
                        'btnAction' : 'OnBtnChoixConfig'},
    {'name': 'mpsql', 'genre': 'Mpass', 'label': 'Mot de Passe Serveur',
                        'help': 'C\'est le mot de passe connu par la base de donnée'},
    {'name': 'pseudo', 'genre': 'String', 'label': 'Votre Pseudo d\'accès',
                        'help': 'Par défaut c\'est votre Identifiant qui sera présenté'},
    {'name': 'mpuser', 'genre': 'Mpass', 'label': 'Mot de Passe Pseudo',
                        'help': 'C\'est le mot de passe connu par la base de donnée'},
    ]
}
MATRICE_CONFIGS = {
("bd_reseau","Base de donnée réseau"): [
    {'name': 'ID', 'genre': 'String', 'label': 'Désignation', 'value': 'config1',
                    'help': "Désignez de manière unique cette configuration"},
    {'name': 'port', 'genre': 'Int', 'label': 'Port ouvert', 'value': 3306,
                    'help': "Information disponible aurpès de l'administrateur système"},
    {'name': 'serveur', 'genre': 'String', 'label': 'Serveur Hôte', 'value':'',
                    'help': "Adresse IP ou nom du serveur "},
    {'name': 'typeBD', 'genre': 'Enum', 'label': 'Type de Base',
                    'help': "Le choix est limité par la programmation", 'value':0, 'values':['MySql','SqlServer'] },
    {'name': 'user', 'genre': 'String', 'label': 'Utilisateur BD',
                    'help': "Utilisateur ayant des droits d'accès à la base de donnée", 'value':'invite'},
    ],
("bd_locale", "Base de donnée locale"): [
        {'name': 'nom_local', 'genre': 'String', 'label': 'Nom de la  base locale'},
        {'name': 'typeBDloc', 'genre': 'Enum', 'label': 'Type de Base de donnée',
                        'help': "Le choix est limité par la programmation", 'value': 0, 'values': ['SqLite', 'Access']},
    ]
}

COLONNES_CONFIGS = {
    "bd_reseau": ['ID','serveur','typeBD','user'],
    "bd_locale": ['nom_local', 'typeBDloc'],
}

def AppelLgnesMatrice(categ=None, possibles={}):
    # retourne les lignes de la  matrice du code categ demandé
    # ou la première catégorie si not code
    label = ''
    lignes = {}
    if possibles:
        for code, labelCategorie in possibles:
            if isinstance(code, str):
                if categ:
                    if categ == code:
                        label = labelCategorie
                        lignes = possibles[(code, labelCategorie)]
                else:
                    label = labelCategorie, possibles
                    lignes = possibles[(code, labelCategorie)]
                    break
    return code, label, lignes

#************************   Gestion de l'identification initiale *****************

class DLG_identification(wx.Dialog):
    # Ecran de saisie de paramètres en dialog
    def __init__(self, parent, *args, **kwds):
        listArbo=os.path.abspath(__file__).split("\\")
        titre = listArbo[-1:][0] + "/" + self.__class__.__name__
        wx.Dialog.__init__(self, parent, -1,title = titre,
                           style=wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER)
        self.parent = parent
        try:
            self.dictAPPLI = parent.dictAPPLI
        except:
            # pour test on récupère la déclaration en fin de ce module
            self.dictAPPLI = dictAPPLI
        cadre_staticbox = wx.StaticBox(self, -1, label='identification')
        topbox = wx.StaticBoxSizer(cadre_staticbox, wx.VERTICAL)
        self.btn = xusp.BTN_fermer(self)
        self.btn.Bind(wx.EVT_BUTTON, self.OnFermer)
        self.btnTest = xusp.BTN_action(self,help='Test de la connexion réseau',image=wx.Bitmap("xpy/Images/100x30/Bouton_tester.png"))
        self.btnTest.Bind(wx.EVT_BUTTON, self.OnTest)

        def AffichID():
            #Affichage de l'identification IDENT partie grisée, et dernière CHOIX_CONFIG (non grisée)
            self.ctrlID = xusp.CTRL_property(self, matrice=MATRICE_IDENT, enable=False)
            # précharge les dernières valeurs de l'utilisateurs de toutes les clé du groupe IDENT
            ddDonnees = {}
            valeurs = {}
            ident = None
            for (code,label), lignes in MATRICE_IDENT.items():
                for ligne in  lignes:
                    if ligne['name'].lower() in ('utilisateur', 'user'):
                        valeurs[ligne['name']] = os.environ['USERNAME']
                        ident = code
                    if ligne['name'].lower() in ('domaine', 'workgroup'):
                        try:
                            valeurs[ligne['name']] = os.environ['USERDOMAIN']
                        except:
                            import platform
                            valeurs[ligne['name']] = platform.node()
            if ident:
                ddDonnees[ident] = valeurs
                self.ctrlID.SetValeurs(ddDonnees=ddDonnees)

            code,label,lignes = AppelLgnesMatrice(None, MATRICE_CHOIX)

            # le nom de la configuration c'est le premier champ décrit dans la matrice
            self.codeConfig = code + '.' + lignes[0]['name']
            # contrôle gérant la saisie des paramètres de config
            self.ctrlConfig = xusp.BoxPanel(self, -1, lblbox=label, code=code, lignes=lignes)
            # choix de la configuration prise dans paramUser
            cfg = xuconf.ParamFile()
            self.configs= cfg.GetDict(dictDemande={'lstConfigs':None}, groupe='CONFIGS')
            if self.configs:
                if self.configs['lstConfigs']:
                    self.ctrlConfig.SetOneValues(self.codeConfig, self.configs['lstConfigs'])
            # adressage dans le fichier par défaut dans profilUser
            cfg = xuconf.ParamUser()
            self.config= cfg.GetDict(dictDemande=None, groupe='CHOIX')
            self.ctrlConfig.SetValues(self.config)

            topbox.Add(self.ctrlID, 0,wx.ALL | wx.EXPAND, 5)
            topbox.Add((20,20), 0, wx.ALIGN_TOP, 0)
            topbox.Add(self.ctrlConfig, 0, wx.ALIGN_TOP, 0)
            topbox.Add((40,40), 0, wx.ALIGN_TOP, 0)
            piedbox = wx.BoxSizer(wx.HORIZONTAL)
            piedbox.Add(self.btnTest, 0, wx.ALIGN_RIGHT, 0)
            piedbox.Add(self.btn, 0, wx.ALIGN_RIGHT, 0)
            topbox.Add(piedbox, 0, wx.ALIGN_RIGHT, 0)

        AffichID()
        self.SetSizerAndFit(topbox)

    def OnTest(self,event):
        print('test')

    def OnBtnChoixConfig(self,event):
        # sur clic du bouton pour élargir le choix de la combo
        sc = DLG_saisieConfig(self)
        rc = sc.ShowModal()
        cfg = xuconf.ParamFile()
        dicvalues = cfg.GetDict({'lstConfigs':None}, 'CONFIGS')
        if dicvalues['lstConfigs']:
            self.ctrlConfig.SetOneValues(self.codeConfig, dicvalues['lstConfigs'])
        value = sc.GetChoix(idxColonne=0)
        self.ctrlConfig.SetOneValue(self.codeConfig,value)
        #self.ctrlConfig.SetValues(self.config)

    def OnFermer(self,event):
        # enregistre les valeurs de l'utilisateur
        cfg = xuconf.ParamUser()
        dic = self.ctrlConfig.GetValues()
        cfg.SetDict(dic, groupe='CHOIX',close=False)
        dic = self.ctrlID.GetValues()
        cfg.SetDict(dic, groupe='IDENT')
        self.Destroy()

    def OnEnter(self,event):
        #action evènement Enter sur le contrôle combo, correspond à un changement de choix
        print('Clic sans objet! reçu chez DLG_identification.OnEnter')
        print('provenance : ', event.__dir__())

class DLG_saisieConfig(xusp.DLG_listCtrl):
    # Ecran de saisie de paramètres en dialog
    def __init__(self, parent, *args, **kwds):
        super().__init__(parent, *args, **kwds)
        self.parent = parent
        self.dlColonnes = {}
        self.lddDonnees = []
        self.dldMatrice = {}
        # composition des paramètres
        # seuls les paragraphes option choisis par l'appli et présents dans MATRICE_CONFIGS seront appelés.
        if 'CONFIGS' in self.parent.dictAPPLI:
            for option in self.parent.dictAPPLI['CONFIGS']:
                for code,chapitre in MATRICE_CONFIGS:
                    if option == code:
                        self.dldMatrice[(code,chapitre)] = MATRICE_CONFIGS[(code,chapitre)]
                        if code in COLONNES_CONFIGS:
                            self.dlColonnes[code] = COLONNES_CONFIGS[code]
            cfg = xuconf.ParamFile()
            dic= cfg.GetDict(None,'CONFIGS')
            if 'donnees' in dic:
                if dic['donnees']:self.lddDonnees += dic['donnees']
            # paramètres pour self.pnl contenu principal de l'écran
            self.kwds['lblbox'] = 'Configuations disponibles'
            self.MinSize = (400,300)
        self.gestionProperty = False
        self.Init()

    def OnFermer(self, event):
        configs = []
        #constitution de la liste des noms de configs (première colonne)
        for ligne in self.lddDonnees:
            for cle, valeurs  in ligne.items():
                if 'ID' in valeurs.keys():
                   conf = valeurs['ID']
            configs.append(conf)
        cfg = xuconf.ParamFile()
        cfg.SetDict({'lstConfigs': configs}, 'CONFIGS', close=False )
        cfg.SetDict({'donnees':self.lddDonnees}, 'CONFIGS')
        return self.Close()

    def GetChoix(self, idxColonne = 0):
        c = self.pnl.ctrl
        idxLigne = c.GetFirstSelected()
        if idxLigne == -1: idxLigne = 0
        # le nom de la config est dans la colonne pointée par l'index fourni
        cell = c.GetItem(idxLigne,idxColonne)
        choix = cell.GetText()
        return choix

        return self.Close()


#************************   Pour Test ou modèle  *********************************

dictAPPLI = {'NOM_APPLICATION': 'myAppli', 'REP_SOURCES': 'srcMyAppli', 'NOM_FICHIER_LOG': 'testLOG', 'CONFIGS': ['bd_reseau', 'bd_locale']}

if __name__ == '__main__':
    app = wx.App(0)
    os.chdir("..")
    frame_1 = DLG_identification(None)
    frame_1.Position = (50,50)
    app.SetTopWindow(frame_1)
    frame_1.Show()
    app.MainLoop()

