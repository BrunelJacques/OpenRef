# !/usr/bin/env python
# -*- coding: utf-8 -*-

#----------------------------------------------------------------------------
# Application :    Projet XPY, gestion des paramètres de configuration
#                  soit dans un fichier user soit dans un repertoire partagé
# Licence:         Licence GNU GPL
#----------------------------------------------------------------------------

import wx
import os
import shelve

def ListToDict(lstCles,lstValeurs):
    dict = {}
    if isinstance(lstCles,list):
        for cle in lstCles:
            idx = lstCles.index(cle)
            dict[cle] = None
            if isinstance(lstValeurs, list) and len(lstValeurs) >= idx:
                dict[cle] = lstValeurs[idx]
    return dict

def DictToList(dic):
    lstCles = []
    lstValeurs = []
    if isinstance(dic,dict):
        for cle,valeur in dic.items():
            lstCles.append(cle)
            lstValeurs.append(valeur)
    return lstCles,lstValeurs

class ParamFile():
    # Gestion des paramètres dans un fichier via Shelve
    def __init__(self, nomFichier='xConfig', path=''):
        # recherche des configs dans la frame de lancement
        # le fichier est vu comme un quasi-dictionnaire il contient le dictionnaire du groupe de paramètres
        self.topWin = False
        self.dictMem= {}
        try :
            topWindow = wx.GetApp().GetTopWindow()
            nomWindow = topWindow.GetName()
        except :
            nomWindow = None
        if nomWindow == "general" :
            # Si la frame 'General' est chargée, on y récupère le dict userConfig qui gère en priorité un double de tout
            self.dictMem = topWindow.userConfig
            self.topWin = True
            if path == '':
                try:
                    path = topWindow.pathSrcAppli + '/Data/'
                except:
                    pass
        if path == '':
            path = 'xpy/Data/'

        # ouvre le fichier et le crée si nécessaire
        # création du chemin et de tous les répertoires nécessaires
        self.dictFic = {}
        if not path: path = '/'
        if not (path[-1:] in ['/','\\'] ): path +='/'
        chemin = path+nomFichier
        chemin = chemin.replace('\\','/')
        chemin = chemin[0:2]+chemin[2:].replace('//','/')
        arboresc = chemin.split('/')
        rep = ''
        premier = True
        for mot in arboresc[0:-1]:
            rep += mot + '/'
            if mot != '':
                # le premier mot de l'arborescence est sensé exister
                if not premier:
                    if not os.path.exists(rep): os.makedirs(rep)
                premier = False
        self.dictFic = shelve.open(chemin, "c")
        if self.dictMem == {}:
            for cle, valeur in self.dictFic.items():
                self.dictMem[cle] = valeur

    def GetDict(self,dictDemande,groupe, close=True):
        """ Recupere une copie du dictionnaire demandé ds le fichier de config
            Si dictDemande est None c'est l'ensemble du groupe,
            Si groupe est None : recherché dans l'ensemble des groupes"""
        dictDonnees = {}
        if dictDemande == {} : dictDemande = None
        if groupe and (not (groupe in self.dictMem.keys())):
            if groupe in self.dictFic.keys():
                self.dictMem[groupe] = self.dictFic[groupe]

        def GetListKey(groupe):
            # liste des clés à Synchroniser
            # si présence d'un dictionnaire en entrée, on le met à jour sinon c'est tout le groupe
            if dictDemande:
                for key in dictDemande.keys(): self.dicKeys[key] = 0
            else :
                if groupe in self.dictMem.keys():
                    for key in self.dictMem[groupe].keys(): self.dicKeys[key] = 0
                elif groupe in self.dictFic.keys():
                    for key in self.dictFic[groupe].keys(): self.dicKeys[key] = 0

        def GetDictGroupe(groupe):
            # les données peuvent être à différents endroits : priorité au premier dictionnaire pointé
            for key in self.dicKeys:
                #recherche par priorité inversée
                if self.dicKeys[key]==0:
                    dictDonnees[key] = None
                    # valeur par défaut si non présente
                    if dictDemande:
                        if key in dictDemande.keys():
                            dictDonnees[key] = dictDemande[key]
                    self.dicKeys[key] = 1
                if self.dicKeys[key] < 2:
                    # recherche dans le deuxième dictionnaire
                    if groupe in self.dictFic:
                        #if isinstance(groupe,dict):
                            if key in self.dictFic[groupe]:
                                dictDonnees[key] = self.dictFic[groupe][key]
                                self.dicKeys[key] = 2
                if self.dicKeys[key] < 3:
                    # recherche dans le premier dictionnaire
                    if groupe in self.dictMem.keys():
                        if isinstance(self.dictMem[groupe],dict):
                            if key in self.dictMem[groupe].keys():
                                dictDonnees[key] = self.dictMem[groupe][key]
                                self.dicKeys[key] = 3

        self.dicKeys = {}
        if groupe :
            GetListKey(groupe)
            GetDictGroupe(groupe)
        else :
            for groupe in self.dictMem.keys():
                GetListKey(groupe)
                GetDictGroupe(groupe)

        if self.topWin and close : self.dictFic.close()
        return dictDonnees

    def SetDict(self,dictEnvoi,groupe, close=True):
        """ Ajoute ou met à jour les clés du dictionnaire ds le fichier de config
            par défaut ce sera le groupe param si groupe est None"""
        if groupe and (not (groupe in self.dictMem.keys())):
            if groupe in self.dictFic:
                self.dictMem[groupe] = self.dictFic[groupe]

        def SetDictGroupe(groupe, dic):
            dictTemp = {}
            # précharge les clés qui ne seront pas dans l'envoi, pour ne pas les perdre
            if groupe in dic:
                for key in dic[groupe]:
                    dictTemp[key] = dic[groupe][key]
            for key in dictEnvoi.keys():
                dictTemp[key] = dictEnvoi[key]
            return dictTemp

        if not groupe: groupe = 'param'
        dictTemp = SetDictGroupe(groupe, self.dictMem)
        self.dictMem[groupe] = dictTemp
        # double enregistrement
        dictTemp = SetDictGroupe(groupe, self.dictFic)
        self.dictFic[groupe] = dictTemp

        if close:
            self.dictFic.close()
        return

    def DelDictConfig(self, groupe, close=True):
        """ Supprime le dict du fichier de config présent sur le disque """
        if groupe in self.dictMem:
                del self.dictMem[groupe]
        if self.topWin:
            #double enregistrement
            if groupe in self.dictFic:
                del self.dictFic[groupe]
            if close:
                self.dictFic.close()
        return

class ParamUser(ParamFile):
    # Gestion des paramètres dans un fichier créé dans USERPROFILE
    def __init__(self, nomFichier = 'UserConfig'):
        pathUser = os.environ['USERPROFILE']
        if (not pathUser ) or (len(pathUser)<2): pathUser = '\\'
        pathUser = pathUser.replace('\\','/')
        ParamFile.__init__(self,nomFichier,pathUser+'/')

# --------------- TESTS ----------------------------------------------------------
if __name__ == u"__main__":
    app = wx.App(0)
    os.chdir("..")
    cfg = ParamFile('xConfig')
    for key,valeur in cfg.dictFic.items():
        print(key, ' : ', valeur)
    cfg.dictFic.close()
    """
    """
    from random import randrange
    cfg = ParamUser(nomFichier='Data/test')
    print("GET :", cfg.GetDict({"test1" : None,"test3":'oublié'},groupe='mongroupe'))
    cfg = ParamUser(nomFichier='Data/test')
    args =({"test1": randrange(0,100), "test2" : 125.77, "test4":{1:10,2:20,3:30}})
    cfg.SetDict(args,groupe='mongroupe')
    print("SET :", args)
    cfg = ParamUser(nomFichier='Data/test')
    print("GET :", cfg.GetDict({"test1": randrange(0,100)},groupe='mongroupe'))
    cfg = ParamUser(nomFichier='Data/test')
    print("GET :", cfg.GetDict(None, None))

    app.MainLoop()
