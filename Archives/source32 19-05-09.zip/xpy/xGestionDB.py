#!/usr/bin/env python
# -*- coding: utf8 -*-

#------------------------------------------------------------------------
# Application :    xPY
# Auteur:          Jacques Brunel, d'après Yvan LUCAS Noethys
# Licence:         Licence GNU GPL
# Gestion des bases de données
#------------------------------------------------------------------------

import os
import wx
import random
DICT_CONNEXIONS = {}

class DB():
    def __init__(self, nomFichier="", isNetwork=False, modeCreation=False, IDconnexion=None):
        self.nomFichier = nomFichier
        self.modeCreation = modeCreation
        self.isNetwork = isNetwork
        self.lstIndex = []

        # Mémorisation de l'ouverture de la connexion et des requêtes
        if IDconnexion == None:
            self.IDconnexion = random.randint(0, 1000000)
        else:
            self.IDconnexion = IDconnexion
        DICT_CONNEXIONS[self.IDconnexion] = []

        # Si aucun nom de fichier n'est spécifié, on recherche celui par défaut dans le Config.dat
        if self.nomFichier == "":
            self.nomFichier = self.GetNomFichierDefaut()


        # Ouverture de la base de données
        if self.isNetwork == True:
            self.OuvertureFichierReseau(self.nomFichier)
        else:
            self.OuvertureFichierLocal(self.nomFichier)

    def GetNomFichierDefaut(self):
        nomFichier = ""
        try :
            topWindow = wx.GetApp().GetTopWindow()
            nomWindow = topWindow.GetName()
        except :
            nomWindow = None

        if nomWindow == "general" :
            # Si la frame 'General' est chargée, on y récupère le dict de config
            nomFichier = topWindow.userConfig["nomFichier"]
        else:
            # Récupération du nom de la DB directement dans le fichier de config sur le disque dur
            import xUTILS_Config
            cfg = xUTILS_Config.ParamFile(nomFichier='Config')
            nomFichier = cfg.GetDict({"nomFichier": None}, groupe='database')
        return nomFichier

    def OuvertureFichierLocal(self, nomFichier):
        """ Version LOCALE avec SQLITE """
        #nécessite : pip install pysqlite
        import sqlite3
        # Vérifie que le fichier sqlite existe bien
        if self.modeCreation == False:
            if os.path.isfile(nomFichier) == False:
                # print "Le fichier SQLITE demande n'est pas present sur le disque dur."
                self.echec = 1
                return
        # Initialisation de la connexion
        try:
            self.connexion = sqlite3.connect(nomFichier.encode('utf-8'))
            self.cursor = self.connexion.cursor()
        except Exception as err:
            print("La connexion avec la base de donnees SQLITE a echouee : \nErreur detectee :%s" % err)
            self.erreur = err
            self.echec = 1
        else:
            self.echec = 0

    def MaFonctionInconnue(self):
        import pyodbc
        """Important: 32bit MS driver - 32bit python!"""
        """N'est pas compatible access 95, mais oui avec access 2002"""
        cnxn = pyodbc.connect('DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=c:/temp/test.mdb;')
        cursor = cnxn.cursor()

        cursor.execute("select * from table1")
        for row in cursor.fetchall():
            print(row)

        csr = cnxn.cursor()
        csr.close()
        del csr
        cnxn.close()

        import mysql
        cnx = mysql.connector.connect(host='192.168.1.43', user='root', database='matthania_data',password='pr0V1522')
        cursor = cnx.cursor()

        query = ("SELECT * FROM caisses")

        cursor.execute(query)

        for ligne in cursor:
          print(ligne)

        cursor.close()
        cnx.close()



        import pymysql.cursors

        # Connect to the database
        connection = pymysql.connect(host='192.168.1.43',
                                     user='root',
                                     password='pr0V1522',
                                     db='matthania_data',
                                     charset='utf8mb4',
                                     cursorclass=pymysql.cursors.DictCursor)

        try:
            with connection.cursor() as cursor:
                # Read a single record
                sql = "SELECT * FROM `caisses` "
                cursor.execute(sql,)
                for ligne in cursor:
                    print(ligne)

                result = cursor.fetchmany(size=2)
                print(result)


            with connection.cursor() as cursor:
                # Create a new record
                sql = "SELECT IDcaisse FROM caisses;"
                cursor.execute(sql, ('IDcaisse',))
                result = cursor.fetchone()
                print(result)

            # connection is not autocommit by default. So you must commit to save
            # your changes.
            connection.commit()

            with connection.cursor() as cursor:
                # Read a single record
                sql = "SELECT `id`, `password` FROM `users` WHERE `email`=%s"
                cursor.execute(sql, ('webmaster@python.org',))
                result = cursor.fetchone()
                print(result)

        finally:
            connection.close()


if __name__ == "__main__":
    app = wx.App()
    """
    f = maFonction()
    print(f)
    """
    DB1 = DB()
    DB1.Close()
