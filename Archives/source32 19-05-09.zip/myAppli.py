# !/usr/bin/env python
# -*- coding: utf-8 -*-

# myXappli.py : Exemple de lanceur d'une application standard

import sys
import os
import wx
import xpy.xAppli as xAppli

# Variables incontournables pour xpy
dictAPPLI = {
            'NOM_APPLICATION'       : "myAppli",
            'REP_SOURCES'           : "srcMyAppli",
            'NOM_FICHIER_LOG'       : "logsMyAppli.log",
            'CONFIGS': ["bd_reseau","Mémorisation", "Autres éléments"],
}

class MyFrame(xAppli.MainFrame):
    def __init__(self, *args, **kw):
        super().__init__( *args, **kw)

        #dictionnaire propre à l'appli
        self.dictAPPLI = dictAPPLI

        # Ajoute le path des modules spécifiques pour les imports
        pathCourant = os.path.dirname(os.path.abspath(__file__))
        self.pathSrcAppli = pathCourant + "\\%s"%self.dictAPPLI['REP_SOURCES']
        if not self.pathSrcAppli in sys.path:
            sys.path = [self.pathSrcAppli] + sys.path

        # Intialise et Teste la présence de fichiers dans le répertoire sources
        self.xInit()
        # Crée 'topPanel' et 'topContenu' destroyables
        self.MakeHello("TopPanel de " + self.dictAPPLI['NOM_APPLICATION'])
        # Activer le menu décrit dans  PATH_SOURCES/menu.py
        self.MakeMenuBar()
        # Crée un message initial de bas de fenêtre status bar
        self.CreateStatusBar()
        self.SetStatusText("xPY roule pour vous!")
        self.Show()
        self.SaisieConfig()
        #self.ConnexionReseau()
        #self.ConnexionLocal()
        #self.SuiviActivite()

class MyApp(wx.App):
    def OnInit(self):
        xAppli.CrashReport(dictAPPLI)
        # Création de la frame principale
        myframe = MyFrame(None)
        self.SetTopWindow(myframe)
        return True

if __name__ == "__main__":
    # Lancement de l'application
    app = MyApp(redirect=False)
    app.MainLoop()

