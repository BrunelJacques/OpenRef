# !/usr/bin/env python
# -*- coding: utf-8 -*-

#------------------------------------------------------------------------
# Application :    Projet XPY, atelier de développement
# Auteurs:          Jacques BRUNEL,
# Copyright:       (c) 2019-04     Cerfrance Provence, Matthania
# Licence:         Licence GNU GPL
#------------------------------------------------------------------------

import wx
""" Paramétrage de la construction de la barre de menus """
class MENU():
    def ParamMenu(self):
        """ appelé pour Construire la barre de menus """
        # The "\t..." syntax defines an accelerator key that also triggers
        menu = [
            # Première colonne
            {"code": "&menu_fichier\tCtrl-F", "label": (u"Fichier"), "items": [
                {"code": "nouveau_fichier", "label": (u"&Créer un nouveau fichier\tCtrl-N"),
                 "infobulle": (u"Créer un nouveau fichier"), "image": "Images/16x16/Fichier_nouveau.png",
                 "action": "On_fichier_Nouveau", "genre": wx.ITEM_NORMAL},            ],
             },
        ]
        return menu

    def On_fichier_Nouveau(self, event):
        """ Créé une nouvelle base de données """
        if event == None:
            print('Bonjour On_fichier_Nouveau')

    def On_fichier_Ouvrir(self, event):
        if event == None:
            print('Bonjour On_fichier_Ouvrir')

    def On_fichier_Fermer(self, event):
        if event == None:
            print('Bonjour On_fichier_Fermer')

    def On_fichier_Informations(self, event):
        if event == None:
            print('Bonjour On_fichier_Informations')

    def On_fichier_Sauvegarder(self, event):
        if event == None:
            print('Bonjour On_fichier_Sauvegarder')

    def On_fichier_Restaurer(self, event):
        if event == None:
            print('Bonjour On_fichier_Restaurer')

    def On_fichier_Quitter(self, event):
        if event == None:
            print('Bonjour On_fichier_Quitter')

    def On_param_preferences(self, event):
        if event == None:
            print('Bonjour On_param_preferences')

    def On_param_utilisateurs(self, event):
        if event == None:
            print('Bonjour On_param_utilisateurs')
    

if __name__ == "__main__":
    """ Affichage du menu"""
    menu = MENU().ParamMenu()
    for dictColonne in menu:
        print(dictColonne['code'], dictColonne['label'])
        for ligne in dictColonne['items']:
            print('\t',end='')
            if isinstance(ligne,str):
                print(ligne)
            elif isinstance(ligne,dict):
                print(ligne['code'],"\t", ligne['label'],"\n\t\t",ligne.keys())
            else: print("problème!!!!!!!!!!!")
    for dictColonne in menu:
        for dictligne in dictColonne['items']:
            if 'action' in dictligne:
                #print("action", dictligne['code'])
                act = "MENU."+dictligne['action']+"(None,None)"
                print(act + "\t action >>\t", end='')
                eval(act)
