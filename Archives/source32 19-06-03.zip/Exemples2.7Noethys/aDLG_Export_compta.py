#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-
#------------------------------------------------------------------------
# Application :    Noethys, gestion multi-activit�s, Exports Compta Matthania, fa�on EBP_COMPTA
# Site internet :  www.noethys.com
# Auteur:           Ivan LUCAS, Jacques BRUNEL
# Copyright:       (c) 2010-14 Ivan LUCAS
# Licence:         Licence GNU GPL
#------------------------------------------------------------------------


from UTILS_Traduction import _
import wx
import CTRL_Bouton_image
import os
import datetime
import copy
import aGestionDB
import CTRL_Bandeau
import CTRL_Saisie_date
import aGestionInscription
import UTILS_Titulaires
from UTILS_Decimal import FloatToDecimal as FloatToDecimal
import FonctionsPerso
import UTILS_Config
import UTILS_Parametres
import wx.lib.agw.pybusyinfo as PBI
import wx.propgrid as wxpg
import CTRL_Propertygrid
# installer par commande dos 'pip install unidecode'
if 'phoenix' in wx.PlatformInfo:
    from wx.adv import BitmapComboBox
else :
    from wx.combo import BitmapComboBox

SYMBOLE = UTILS_Config.GetParametre("monnaie_symbole", u"�")

def DateEngEnDateDD(dateEng):
    return datetime.date(int(dateEng[:4]), int(dateEng[5:7]), int(dateEng[8:10]))

def DateDDenEng(dateDD):
    if dateDD == None: return None
    return dateDD.strftime("%Y-%m-%d")


def Nz(valeur):
    if valeur == None:
        valeur = 0
    return valeur

def Decod(valeur):
    return aGestionDB.Decod(valeur)

def FormateDate(dateDD=None, format="%d/%m/%y") :
    if dateDD == None or dateDD == "" :
        return ""
    else :
        return dateDD.strftime(format)
    
def FormateLibelle(texte="", valeurs=[]):
    for motcle, valeur in valeurs :
        texte = texte.replace(motcle, valeur)
    return texte

def GetKeysDictTries(dictValeurs={}, key=""):
    """ Renvoie une liste de keys de dictionnaire tri�s selon la sous key indiqu�e """
    listeKeys = []
    for ID, dictTemp in dictValeurs.iteritems() :
        listeKeys.append((dictTemp[key], ID))
    listeKeys.sort()
    listeResultats = []
    for keyTemp, ID in listeKeys() :
        listeResultats.append(ID)
    return listeResultats

def GetSens(montant, sens):
    # suppression de tout signe n�gatif
    if montant < FloatToDecimal(0.0) :
        montant = -montant
        if sens == "D" :
            sens = "C"
        else :
            sens = "D"
    return montant, sens

class DataType(object):
    #Classe permetant la conversion facile vers le format souhait� (nombre de caract�res, alignement, d�cimales)

    def __init__(self,type=int,length=1,align="<",precision=2):
        """
        initialise l'objet avec les param�tres souhait�
        """
        self.type = type
        self.length = length
        self.align = align
        self.precision = precision

    def Convert(self,data):
        # format souhait�
        ret_val = ""
        if data == None:
            data = ""
        if type(data) is str:                       #s'assure que la donn�e soit bien en unicode
            data=unicode(data.decode("iso-8859-15"))

        if self.type == int:                        #si l'on veux des entier
            if data!="":
                try:                                #on v�rifie qu'il s'agit bien d'un nombre
                    data=int(data)
                except ValueError as e:
                    print("/!\ Erreur de format, impossible de convertir en int /!\\")
                    print(e)
                    data=0
                ret_val = u"{0: {align}0{length}d}".format(data,align=self.align,length=self.length)
            else:
                ret_val = u"{0: {align}0{length}s}".format(data,align=self.align,length=self.length)
        elif self.type == str:                      #si l'on veux des chaines de caract�res
            for a in ['\\',';',',']:
                data = data.replace(a,'')
            ret_val = u"{0: {align}0{length}s}".format(data,align=self.align,length=self.length)

        elif self.type == 'strdt':                      #si l'on veux des chaines de caract�res
            for a in ['/','-',' ']:
                data = data.replace(a,'')
            data = data.replace("-/","")
            ret_val = u"{0: {align}0{length}s}".format(data,align=self.align,length=self.length)

        elif self.type == float:                    #si l'on veux un nombre a virgule
            if data!="":
                try:
                    data=float(data)                #on v�rifie qu'il s'agit bien d'un nombre
                except ValueError as e:
                    print("/!\ Erreur de format, impossible de convertir en float /!\\")
                    print(e)
                    data=0
                ret_val = u"{0: {align}0{length}.{precision}f}".format(data,align=self.align,length=self.length,precision=self.precision)
            else:
                ret_val = u"{0: {align}0{length}s}".format(data,align=self.align,length=self.length)

        if len(ret_val)>self.length:                #on tronc si la chaine est trop longue
            ret_val=ret_val[:self.length]
        return ret_val
        #fin Convert
    #fin class DataType

# utilis� pour le format � largeur fixe mais aussi pour le formatage nombre ou dates
dataTypes = {"compte":[DataType(int,7,"<"),"@"],
             "libCompte":[DataType(str,25,"<"),"A"],
             "date":[DataType('strdt',8,">"),"B"],
             "journal":[DataType(str,2,"<"),"C"],
             "noPiece":[DataType(int,6,">"),"D"],
             "reference":[DataType(str,7,"<"),"E"],
             "pointage":[DataType(str,8,"<"),"F"],
             "libEcriture":[DataType(str,25,"<"),"G"],
             "montant":[DataType(float,13,">"),"H"],
             "sens":[DataType(str,1,"<"),"I"],
             "ecart":[DataType(float,10,">"),"J"],
             "jx":[DataType(str,1,">"),"K"],
             "gl":[DataType(str,1,">"),"L"],
             "mod":[DataType(str,1,">"),"M"]
             }

#             "compte":[DataType(str,13,"<"),"F"],
#             "echeance":[DataType('strdt',8,">"),"D"],
#             "analytique":[DataType(str,13,"<"),"K"],
#             "libCompte":[DataType(str,35,"<"),"L"],
#             "devise":[DataType(str,1,"<"),"M"]
# ----------------------------------------------------------------------------------------------------------------------------------

class XImportLine(object):
    """
    import� de UTILS_XImport
    ligne telle que format� dans un fichier XImport
    """
    def __init__(self,ligne,num_ligne):
        """
        R�cup�re les donn�e utiles fournis en param�tres, les convertis et les enregistre
        """
        if ligne == None:
            listeEntete = {}
            self.entete = ""
            for key in dataTypes.keys():
                listeEntete[dataTypes[key][1]]= key[:dataTypes[(key)][0].length] + " "*(dataTypes[(key)][0].length-len(key))
            for key in sorted(listeEntete.keys()):
                self.entete += listeEntete[key]
            return

        values = dict()         #contient les valeurs fournies et non converties
        self.values = dict()    #contiendra les valeurs convertie

        for key in ligne.keys():
            values[key] = ligne[key]
        values["numLigne"]=num_ligne #le num�ro de mouvement est le num�ro de la ligne ?

        for i in dataTypes.keys():  #Convertie toutes les donn�e
            if i in values:
                # Si la donn�e a bien �t� fournie, on la converti
                self.values[i]=dataTypes[i][0].Convert(values[i])
            else:                   #Sinon on remplis de blanc, pour respecter la largeur des colones
                self.values[i]=dataTypes[i][0].Convert("")


    def __getattr__(self,name):
        """
        g�re l'acces aux attributs, pour plus de souplesse, les attributs inconnus renvoient None
        """
        if name in self.values:
            return self.values[name]
        else:
            return None

    def __str__(self):
        """
        Renvois la liste des donn�e et leur valeur (appel� lors d'un print ou d'une convertion str)
        """
        ligneTemp = "LigneXImport : \n"+\
               "compte :"+unicode(self.compte)+"\n"+\
               "libCompte :"+unicode(self.libCompte)+"\n"+\
               "date :"+unicode(self.date)+"\n"+\
               "journal :"+unicode(self.journal)+"\n"+\
               "noPiece :"+unicode(self.noPiece)+"\n"+\
               "reference"+unicode(self.reference)+"\n"+\
               "pointage "+unicode("        ")+"\n"+\
               "libEcriture :"+unicode(self.libEcriture)+"\n"+\
               "montant :"+unicode(self.montant)+"\n"+\
               "sens :"+unicode(self.sens)+"\n"+\
               "ecart "+unicode("      0.00")+"\n"+\
                "jx " + unicode("F")+"\n"+\
                "gl " + unicode("F")+"\n"+\
                "mod" + unicode(" ")+"\n"

#               "analytique :"+unicode(self.analytique)+"\n"+\
#               "libCompte :"+unicode(self.libCompte)+"\n"+\
#               "devise :"+unicode(self.devise)+"\n"+\
#               "numLigne :"+unicode(self.numLigne)+"\n"+\
#               "echeance :"+unicode(self.echeance)+"\n"+\
        return ligneTemp


    def getData(self):
        """
        Retourne la ligne telle qu'elle doit �tre enregistr� dans le fichier XImport
        """
        return  unicode(self.compte)+\
                unicode(self.libCompte)+\
                unicode(self.date)+\
                unicode(self.journal)+\
                unicode(self.noPiece)+\
                unicode(self.reference)+\
                unicode("        ")+\
                unicode(self.libEcriture)+\
                unicode(self.montant)+\
                unicode(self.sens)+\
                unicode("      0.00")+\
                unicode("F")+\
                unicode("F")+\
                unicode(" ")

        """        unicode(self.pointage)+\
                unicode(self.analytique)+\
                unicode(self.libCompte)+\
                unicode(self.devise)+\
                unicode(self.numLigne)+\
                unicode(self.echeance)+\
        """


def Export_compta_matt_delimite(ligne):
    """ Formate les lignes au format Matthania pseudo EBP Compta """
    separateur = ","
    if ligne == None:
        entete = "compte;date;journal;noPiece;reference;pointage;libelleEcriture;montant;sens;ecart;jx;gl;mod".replace(";",separateur)
        return entete
    montant = ligne["montant"]
    sens = ligne["sens"]
    montant=(dataTypes["montant"][0].Convert(montant)).strip()
    date = dataTypes["date"][0].Convert(ligne["date"])
    libEcriture = dataTypes["libEcriture"][0].Convert(ligne["libEcriture"]).strip()
    libCompte = dataTypes["libCompte"][0].Convert(ligne["libCompte"]).strip()
    #libCompte = dataTypes["libCompte"][0].Convert(ligne["libCompte"]).strip()

    # fixation du guillemet pour encadrer le texte
    g = chr(34)
    ligneTemp = [
        g+ligne["compte"][:7]+g,
        g+libCompte[:25]+g,
        g+date+g,
        ligne["journal"][:2],
        str(ligne["noPiece"])[:6],
        g+ligne["reference"][:7]+g,
        "",
        g+libEcriture[:25]+g,
        str(montant).replace('.','.')[-13:],
        g+sens+g,
        "0.00",
        "F",
        "F",
        g+g
        ]
    retour = separateur.join(ligneTemp)
    return retour

def Export_compta_EBP(ligne, numLigne):
    """ Formate les lignes au format EBP Compta """
    separateur = ";"
    if ligne == None:
        #retour des champs entete
        entete = "noLigne;date;journal;compte;libelleCompte;libelleEcriture;noPiece;montant;sens;echeance;devise;reference;analytique".replace(";",separateur)
        return entete
    montant = ligne["montant"]
    sens = ligne["sens"]
    montant=(dataTypes["montant"][0].Convert(montant)).strip()
    date = dataTypes["date"][0].Convert(ligne["date"])
    echeance = dataTypes["echeance"][0].Convert(ligne["echeance"]).strip()
    libEcriture = dataTypes["date"][0].Convert(ligne["libEcriture"]).strip()
    libCompte = dataTypes["date"][0].Convert(ligne["libCompte"]).strip()

    ligneTemp = [
        str(numLigne),
        date,
        ligne["journal"],
        ligne["compte"],
        libCompte,
        libEcriture,
        str(ligne["noPiece"]),
        str(montant),
        sens,
        echeance,
        "EUR",
        ligne["reference"],
        ligne["analytique"],
        ]
    return separateur.join(ligneTemp)

class Donnees():
    def __init__(self, dictParametres={}):
        self.date_debut = dictParametres["date_debut"]
        self.date_fin =dictParametres["date_fin"]
        self.dictParametres = dictParametres
        self.dictTitulaires = UTILS_Titulaires.GetTitulaires()
        coherVte = True
        if dictParametres["export_ventes"] == True :
            coherVte = self.CoherenceVentes()
        coherBqe = True
        if dictParametres["export_reglements"] == True :
            coherBqe = self.CoherenceBanques()
        self.coherent = coherVte and coherBqe
        self.nbreAttente = 0
        self.nbreDifferes = 0
        # fin __init__

    def CoherenceVentes(self):
        DB = aGestionDB.DB()
        if not self.dictParametres["retransfert"] :
            condTransfert = " AND ( prestations.compta IS NULL )"
        else : condTransfert = ""

        condition  = " (NOT (prestations.categorie = 'import')) AND (prestations.montant <> 0) AND ((prestations.date >= '%s'  AND prestations.date <= '%s' AND (prestations.IDfacture IS NULL)) OR (factures.date_edition >= '%s'  AND factures.date_edition <= '%s' AND ( NOT prestations.IDfacture IS NULL))) %s " %(self.date_debut, self.date_fin, self.date_debut, self.date_fin, condTransfert)

        #requ�te d'apr�s celle qui appelle les prestations dans GetPrestations, doit r�cup�rer les m�mes lignes
        req = """
            SELECT  prestations.IDprestation, matPieces.pieIDprestation, prestations.IDfamille, matPieces.pieIDfamille, prestations.IDfacture,
            prestations.IDcontrat, prestations.categorie, matPieces.pieNature, prestations.date, pieDateFacturation, pieDateAvoir, factures.date_edition,
            prestations.montant, prestations.label, prestations.code_compta, activites.abrege, types_groupes_activites.observations, 
            types_groupes_activites.anaTransports, MAX(individus_1.nom), factures.numero, matGroupes.grpAnalytique, pieIDnumPiece, pieNoFacture, pieNoAvoir
            FROM (((((((prestations
            LEFT JOIN ((inscriptions
                LEFT JOIN groupes ON inscriptions.IDgroupe = groupes.IDgroupe)
                LEFT JOIN matGroupes ON groupes.IDgroupe = matGroupes.grpIDgroupe)
            ON (prestations.IDactivite = inscriptions.IDactivite) AND (prestations.IDindividu = inscriptions.IDindividu))
            LEFT JOIN (activites
                    LEFT JOIN groupes_activites ON activites.IDactivite = groupes_activites.IDactivite)
            ON prestations.IDactivite = activites.IDactivite)
            LEFT JOIN types_groupes_activites ON groupes_activites.IDtype_groupe_activite = types_groupes_activites.IDtype_groupe_activite))
            LEFT JOIN rattachements ON prestations.IDfamille = rattachements.IDfamille)
            LEFT JOIN individus AS individus_1 ON rattachements.IDindividu = individus_1.IDindividu)
            LEFT JOIN factures ON factures.IDfacture = prestations.IDfacture
            LEFT JOIN matPieces ON (matPieces.pieIDprestation = prestations.IDprestation OR matPieces.pieIDnumPiece = prestations.IDcontrat))
            WHERE %s
            GROUP BY prestations.IDprestation
            ;""" % (condition)
        retour = DB.ExecuterReq(req)
        if retour != "ok" :
            aGestionDB.MessageBox(None,retour)
            DB.Close()
            return False
        listeDonnees = DB.ResultatReq()
        texte = u"\n"
        """
        prestations.IDprestation, matPieces.pieIDprestation, prestations.IDfamille, matPieces.pieIDfamille, prestations.IDfacture,
        prestations.IDcontrat, prestations.categorie, matPieces.pieNature, prestations.date, pieDateFacturation, pieDateAvoir, factures.date_edition,
        prestations.montant, prestations.label, prestations.code_compta, activites.abrege, types_groupes_activites.observations,
        types_groupes_activites.anaTransports, MAX(individus_1.nom), factures.numero, matGroupes.grpAnalytique, pieIDnumPiece, pieNoFacture, pieNoAvoir"""

        for IDprestation, pieIDprestation, IDfamille, pieIDfamille , IDfacture,\
            IDcontrat, categorie, nature, datePrestation, dateFacturation, dateAvoir, dateFacture,\
            montant, label, codeComptaPrestation, abregeActivite, actAnalytique, \
            actAnalyTransp, nomFamille, numero, grpAnalytique, pieIDnumPiece, noFacture, noAvoir in listeDonnees :
            #analyse des consos
            if categorie.startswith("conso"):
                #prestation factur�e
                if IDfacture != None:
                    #coh�rence noFacture dans matPieces
                    if noFacture == None and noAvoir == None:
                        # perte du lien prestation-facture-piece pour une conso
                        texte += u"Famille %d %s: IDfacture %d en prestation %d, mais pas de pi�ce factur�e!\n" % (IDfamille,nomFamille,IDfacture,IDprestation,)
                    if noFacture != numero and noAvoir != numero:
                        texte += u"Famille %d %s: facture %d en prestation %d, mais pas dans une pi�ce via factures!\n" % (IDfamille,nomFamille,numero,IDprestation,)
                        continue
                    if not nature in ['FAC','AVO']:
                        texte += u"Famille %d %s: noFacture %d dans une pi�ce de nature %s\n" % (IDfamille,nomFamille,noFacture,nature)
                    if noFacture !=None:
                        # noFacture sur mauvaise pi�ce
                        if IDfamille != pieIDfamille:
                            texte += u"Famille %d %s: noFacture %d dans une pi�ce de la famille %d\n" % (IDfamille,nomFamille,noFacture,pieIDfamille)
                        if dateFacture != dateFacturation and IDprestation == pieIDprestation:
                            texte += u"Famille %d %s: dateFacture %s diff�re de date Facturation %s de la pi�ce %d\n" % (IDfamille,nomFamille,dateFacture,dateFacturation,pieIDnumPiece)
                        if noFacture == numero:
                            if IDprestation != pieIDprestation:
                                texte += u"Famille %d %s: IDprestation %d diff�re de pieIDprestation %d de la pi�ce %d\n" % (IDfamille,nomFamille,IDprestation,pieIDprestation,pieIDnumPiece)
                    if noAvoir !=None:
                        # noAvoir sur mauvaise pi�ce
                        if IDfamille != pieIDfamille:
                            texte += u"Famille %d %s: noAvoir %d dans une pi�ce de la famille %d\n" % (IDfamille,nomFamille,noAvoir,pieIDfamille)
                        if dateFacture != dateAvoir and IDcontrat == pieIDprestation:
                            texte += u"Famille %d %s: dateFacture de l'avoir %s diff�re de dateAvoir %s de la pi�ce %d\n" % (IDfamille,nomFamille,dateFacture,dateAvoir, pieIDnumPiece)
                        if noAvoir == numero:
                            if IDcontrat != pieIDnumPiece:
                                texte += u"Famille %d %s: IDcontrat %d diff�re de pieIDprestation %d de la pi�ce %d\n" % (IDfamille,nomFamille,IDcontrat,pieIDprestation,pieIDnumPiece)

                #prestation conso non factur�e
                else:
                    if nature != 'COM':
                        texte += u"Famille %d %s: prestation %s no: %d pas factur�e par pi�ce %s %d\n" % (IDfamille,nomFamille,categorie,IDprestation,nature,pieIDnumPiece)

            #analyse des prestations non consos � ne pas facturer
            else:
                if IDfacture != None:
                    texte += u"Famille %d %s: prestation %s no:%d factur�e par IDfacture %d de no %d \n" % (IDfamille,nomFamille,categorie,IDprestation, IDfacture,numero)
                if pieIDnumPiece != None:
                    texte += u"Famille %d %s: prestation %s no:%d pointe la pi�ce %s %d \n" % (IDfamille,nomFamille,categorie,IDprestation,nature,pieIDnumPiece)

        #nouvelle requ�te si d�tail des ventes pour v�rif des comptes
        if self.dictParametres["option_ventes"] == 0 :
            if not self.dictParametres["retransfert"] :
                condTransfert = " AND ( pieComptaFac IS NULL )"
            else : condTransfert = ""
            condition  = "(matPlanComptable.pctCompte Is Null) AND (ligMontant <> 0) AND ((pieDateFacturation >= '%s' AND pieDateFacturation <= '%s' ) OR (pieDateAvoir >= '%s' AND pieDateAvoir <= '%s' )) %s " %(self.date_debut, self.date_fin,self.date_debut, self.date_fin, condTransfert)

            req = """
                    SELECT matPiecesLignes.ligCodeArticle, matArticles.artLibelle
                    FROM ((matPieces
                    LEFT JOIN matPiecesLignes ON matPieces.pieIDnumPiece = matPiecesLignes.ligIDnumPiece)
                    LEFT JOIN matArticles ON matPiecesLignes.ligCodeArticle = matArticles.artCodeArticle)
                    LEFT JOIN matPlanComptable ON matArticles.artCodeComptable = matPlanComptable.pctCodeComptable
                    WHERE  %s
                    GROUP BY matPiecesLignes.ligCodeArticle
                ;""" % condition
            retour = DB.ExecuterReq(req)
            if retour != "ok" :
                aGestionDB.MessageBox(None,retour)
                DB.Close()
                return False
            comptesNull = DB.ResultatReq()
            self.dictArticles={}
            for codeArticle, libelle in comptesNull:
                if not codeArticle in self.dictArticles:
                    ok = False
                    # recherche sur le radical, utile pour les RED-FAMILL
                    for i in range(len(codeArticle),3,-1):
                        code = codeArticle[:i].upper()
                        req = """
                            SELECT matPlanComptable.pctCompte, matPlanComptable.pctLibelle
                            FROM matArticles LEFT JOIN matPlanComptable ON matArticles.artCodeComptable = matPlanComptable.pctCodeComptable
                            WHERE matArticles.artCodeArticle = '%s'
                            ;""" % code
                        ret = DB.ExecuterReq(req,MsgBox=req)
                        if ret == "ok" :
                            recordset = DB.ResultatReq()
                            for record in recordset:
                                compte = record[0]
                                if compte != None:
                                    if len(compte) > 0 :
                                        ok = True
                        if ok:
                            self.dictArticles[codeArticle] = compte
                            continue
                    if not ok:
                        texte += u"Pas de no de compte pour l'article %s\n" % codeArticle

            #requ�te de v�rification d'enregistrements disparus
            condition  = "((pieDateFacturation >= '%s' AND pieDateFacturation <= '%s' ) OR (pieDateAvoir >= '%s' AND pieDateAvoir <= '%s' )) " %(self.date_debut, self.date_fin,self.date_debut, self.date_fin)
            # famille perdue
            req = """
                SELECT matPieces.pieIDnumPiece, matPieces.pieIDfamille, familles.IDfamille
                FROM matPieces
                     LEFT JOIN familles ON matPieces.pieIDfamille = familles.IDfamille
                WHERE   %s
                        AND ( familles.IDfamille IS NULL )
                GROUP BY matPieces.pieIDnumPiece, matPieces.pieIDfamille ;
                """ % condition
            retour = DB.ExecuterReq(req)
            if retour != "ok" :
                aGestionDB.MessageBox(None,retour)
                DB.Close()
                return False
            orphelines = DB.ResultatReq()
            for IDnumPiece, IDfamille, famille in orphelines:
                texte += u"Pour la famille no %d la pi�ce %d ne trouve rien dans la table famille,\n " % (IDfamille,IDnumPiece)

            # prestation perdue
            req = """
                SELECT matPieces.pieIDnumPiece, matPieces.pieIDfamille, prestations.IDprestation
                FROM matPieces
                    LEFT JOIN prestations ON matPieces.pieIDprestation = prestations.IDprestation
                WHERE   %s
                        AND ( prestations.IDprestation IS NULL ) AND ( matPieces.pieNature = 'FAC')
                GROUP BY matPieces.pieIDnumPiece, matPieces.pieIDfamille ;
                """ % condition
            retour = DB.ExecuterReq(req)
            if retour != "ok" :
                aGestionDB.MessageBox(None,retour)
                DB.Close()
                return False
            orphelines = DB.ResultatReq()
            for IDnumPiece, IDfamille, prestation in orphelines:
                texte += u"Pour la famille no %d la pi�ce %d ne trouve pas la prestation associ�e,\n " % (IDfamille,IDnumPiece)
            # individu rattach�
            req = """
                SELECT matPieces.pieIDnumPiece, matPieces.pieIDfamille, rattachements.IDindividu
                FROM matPieces
                LEFT JOIN (rattachements
                            LEFT JOIN individus ON rattachements.IDindividu = individus.IDindividu) ON matPieces.pieIDfamille = rattachements.IDfamille
                WHERE   %s
                        AND ( rattachements.IDindividu IS NULL )
                GROUP BY matPieces.pieIDnumPiece,matPieces.pieIDfamille, rattachements.IDindividu;
                """ % condition
            retour = DB.ExecuterReq(req)
            if retour != "ok" :
                aGestionDB.MessageBox(None,retour)
                DB.Close()
                return False
            orphelines = DB.ResultatReq()
            for IDnumPiece, IDfamille, Nom in orphelines:
                texte += u"Pour la famille no %d la pi�ce %d ne trouve aucun individu rattach�,\n " % (IDfamille,IDnumPiece)

        DB.Close()
        if texte != u"\n":
            # Avertissement et bloquage du process
            msg = aGestionDB.Messages()
            msg.Box(message= _(u"V�rifiez la facturation des familles suivantes !%s")%texte,titre= u"Incoh�rence � r�duire avant transfert")
            msg.Destroy()
            return False
        return True
        #fin CoherenceVentes

    def CoherenceBanques(self):
        # v�rifie la coh�rence des r�glements
        DB = aGestionDB.DB()
        texte = "\n"
        if not self.dictParametres["retransfert"] :
            condTransfert = " AND ( reglements.compta IS NULL )"
        else : condTransfert = ""
        condition = "reglements.date>='%s' AND reglements.date<='%s' " % (self.date_debut, self.date_fin)
        condition += condTransfert

        # r�glements orphelins de leur d�pot, car ils seront ignor�s des transferts
        req = """SELECT reglements.IDcompte_payeur, reglements.date, reglements.montant
                FROM reglements
                LEFT JOIN depots ON depots.IDdepot = reglements.IDdepot
                WHERE (depots.IDdepot Is Null) AND (reglements.IDdepot Is Not Null) AND %s
        ;""" % condition
        retour = DB.ExecuterReq(req)
        if retour != "ok" :
            aGestionDB.MessageBox(None,retour)
            DB.Close()
            return False
        comptesNull = DB.ResultatReq()
        for IDcomptePayeur, date, montant in comptesNull:
            texte += u"Famille %d : Le depot du r�glement de %s du %s n'est plus accessible !\n" % (IDcomptePayeur,str(montant),str(date))

        # D�pot sur une banque sans code comptable
        if self.dictParametres["option_reglements"] == 0 :
            condition = "reglements.IDdepot IS NOT NULL AND depots.date IS NOT NULL AND depots.date>='%s' AND depots.date<='%s'" % (self.date_debut, self.date_fin)
        else :
            condition = "reglements.date_saisie>='%s' AND reglements.date_saisie<='%s' " % (self.date_debut, self.date_fin)
        condition += condTransfert
        req = """SELECT comptes_bancaires.nom, modes_reglements.label
                FROM ((reglements
                INNER JOIN depots ON reglements.IDdepot = depots.IDdepot)
                LEFT JOIN comptes_bancaires ON depots.IDcompte = comptes_bancaires.IDcompte)
                LEFT JOIN modes_reglements ON reglements.IDmode = modes_reglements.IDmode
                WHERE (comptes_bancaires.code_NNE IS NULL)
                    AND (modes_reglements.code_compta Is Null)
                    AND (depots.code_compta Is Null)
                    AND %s
                GROUP BY comptes_bancaires.nom,modes_reglements.label
                ;""" % condition

        retour = DB.ExecuterReq(req)
        if retour != "ok" :
            aGestionDB.MessageBox(None,retour)
            DB.Close()
            return []
        comptesNull = DB.ResultatReq()
        for nomBanque, nomEmetteur in comptesNull:
            texte += u"Le couple banque %s et emetteur %s est sans compte bancaire associ�!\n" % (nomBanque,nomEmetteur)

        DB.Close()
        if texte != u"\n":
            # Avertissement et bloquage du process
            msg = aGestionDB.Messages()
            msg.Box(message= _(u"V�rifiez les anomalies sur les r�glements :%s")%texte,titre= u"Incoh�rence � r�duire avant transfert")
            msg.Destroy()
            return False
        return True
        #fin CoherenceBanque

    def DictEcritureComplete(self,type,date,journal,compte,libCompte,libEcriture,noPiece,montant,sens,reference=" ",echeance=" ",pointage=" ",analytique=" ",):
        # le champ 'echeance' de EBP est remplac� par la notion de 'reference' qui est un compl�ment au num�ro de pi�ce
        dictEcriture = {}
        dictEcriture["type"] = type
        dictEcriture["date"] = date
        dictEcriture["journal"] = journal
        dictEcriture["compte"] = compte
        dictEcriture["libCompte"] = libCompte
        dictEcriture["libEcriture"] = libEcriture
        dictEcriture["noPiece"] = noPiece
        dictEcriture["montant"] = montant
        dictEcriture["sens"] = sens
        dictEcriture["reference"] = reference
        dictEcriture["echeance"] = echeance
        dictEcriture["pointage"] = pointage
        dictEcriture["analytique"] = analytique
        return dictEcriture
        #fin DictEcritureComplete

    def SetPointeursPieces(self,DB,listeNoPiecesFac,listeNoPiecesAvo):
        dtTransfert = datetime.date.today().year*10000 + datetime.date.today().month*100 + datetime.date.today().day
        fGest = aGestionInscription.Forfaits(self)
        if len(listeNoPiecesFac) > 0 :
            listeSQL = "( " +str(listeNoPiecesFac)[1:-1] + " )"
            req = """SELECT  pieIDnumPiece, pieEtat, pieCommentaire,pieNature
                    FROM matPieces
                    WHERE pieIDnumPiece IN %s ;""" % (str(listeSQL))
            DB.ExecuterReq(req,MsgBox=u"aDLG_Exportcompta.SetPointeursPieces1")
            listePieces = DB.ResultatReq()
            #date du transfert dans le memo commentaire et dans la zone pieComptaFac de la pi�ce
            for IDnumPiece, etat, commentaire, nature in listePieces:
                ligneComm = u"Facture transf�r�e en compta"
                etat = etat + '      '
                etat = etat[:5]+'4'
                commentaire = u"%s : %s \n%s"  %(aGestionInscription.DateIntToString(dtTransfert),ligneComm, DataType(commentaire))
                DB.ReqMAJ('matPieces',[('pieCommentaire',commentaire),('pieEtat',etat),('pieComptaFac',dtTransfert)],'pieIDnumPiece',IDnumPiece,MsgBox = 'aDLG_Export_compta.SetPointeursPieces11')
            action = "TransfertCompta"
            ligneComm = u"%d Pieces Fac transf�r�es" % len(listeNoPiecesFac)
            fGest.Historise(None,None,action,ligneComm)

        if len(listeNoPiecesAvo) > 0 :
            listeSQL = "( " +str(listeNoPiecesAvo)[1:-1] + " )"
            req = """SELECT  pieIDnumPiece, pieEtat, pieCommentaire
                    FROM matPieces
                    WHERE pieIDnumPiece IN %s ;""" % (str(listeSQL))
            DB.ExecuterReq(req,MsgBox=u"aDLG_Exportcompta.SetPointeursPieces2")
            listePieces = DB.ResultatReq()
            #date du transfert dans le memo commentaire et dans la zone pieComptaAvo de la pi�ce
            for IDnumPiece, etat, commentaire in listePieces:
                action = "TransfertCompta"
                ligneComm = u"Avoir transf�r� en compta"
                etat = etat + '      '
                etat = etat[:5]+'4'
                commentaire = u"%s : %s \n%s"  %(aGestionInscription.DateIntToString(dtTransfert),ligneComm,Decod(commentaire))
                DB.ReqMAJ('matPieces',[('pieCommentaire',commentaire),('pieEtat',etat),('pieComptaAvo',dtTransfert)],'pieIDnumPiece',IDnumPiece,MsgBox = 'aDLG_Export_compta.SetPointeursPieces21')
            action = "TransfertCompta"
            ligneComm = u"%d Pieces Fac transf�r�es" % len(listeNoPiecesAvo)
            fGest.Historise(None,None,action,ligneComm)
        del fGest
        DB.Close()
        return
        #fin SetPointeursPieces

    def SetPointeursPrestations(self,DB,listeIDprestations,listeIDcontrats):
        dtTransfert = datetime.date.today().year*10000 + datetime.date.today().month*100 + datetime.date.today().day
        if len(listeIDprestations) > 0:
            listeSQL = "( " +str(listeIDprestations)[1:-1] + " )"
            req = """UPDATE prestations
                    SET  compta = %d
                    WHERE IDprestation IN %s ;""" % (dtTransfert,str(listeSQL))
            DB.ExecuterReq(req,MsgBox=u"aDLG_Exportcompta.SetPointeursPrestations1")

        if len(listeIDcontrats) > 0:
            listeContratsSQL = "( " +str(listeIDcontrats)[1:-1] + " )"
            req = """UPDATE prestations
                    SET  compta = %d
                    WHERE compta IS NULL AND IDcontrat IN %s ;""" % (dtTransfert,str(listeContratsSQL))
            DB.ExecuterReq(req,MsgBox=u"aDLG_Exportcompta.SetPointeursPrestations2")
        return

    def SetPointeursReglements(self,DB,listeNoReglements):
        dtTransfert = datetime.date.today().year*10000 + datetime.date.today().month*100 + datetime.date.today().day
        if len(listeNoReglements) > 0 :
            listeSQL = "( " +str(listeNoReglements)[1:-1] + " )"
            req = """UPDATE reglements
                    SET  compta = %d
                    WHERE IDreglement IN %s ;""" % (dtTransfert,str(listeSQL))
            DB.ExecuterReq(req,MsgBox=u"aDLG_Exportcompta.SetPointeursReglements")
        DB.Close()
        return

    def GetPrestations(self,datePrestPourConsos=False):
        listeDictLignes = []
        # R�cup�ration des prestations de type OD
        DB = aGestionDB.DB()
        code_clients = (self.dictParametres["code_clients"])
        if code_clients == None : code_clients = "4"
        code_ventes = (self.dictParametres["code_ventes"]+"000")[:3]

        if not self.dictParametres["retransfert"] :
            condTransfert = " AND ( prestations.compta IS NULL )"
        else : condTransfert = ""
        if datePrestPourConsos:
            # pr�pare le regroupement dans les clients par No Piece
            # On ignore la date de la pi�ce pour ne retenir que la date de la prestation
            journal = ("00"+self.dictParametres["journal_ventes"])[-2:]
            complChamp = ", pieNoFacture, pieNoAvoir, factures.date_edition  "
            complJoin = " LEFT JOIN factures ON factures.IDfacture = prestations.IDfacture LEFT JOIN matPieces ON (matPieces.pieIDprestation = prestations.IDprestation OR matPieces.pieIDnumPiece = prestations.IDcontrat )"
            condition  = " (NOT prestations.IDfacture IS NULL ) AND (prestations.categorie LIKE 'conso%%') AND (prestations.montant <> 0) AND (factures.date_edition >= '%s' ) AND (factures.date_edition <= '%s' ) %s " %(self.date_debut, self.date_fin, condTransfert)
        else:
            # regroupement dans les clients par No prestation
            journal = ("00"+self.dictParametres["journal_od_ventes"])[-2:]
            complChamp = ", NULL, NULL, NULL "
            complJoin = ""
            condition  = " (NOT (prestations.categorie LIKE 'conso%%')) AND (NOT (prestations.categorie = 'import')) AND (prestations.montant <> 0) AND (prestations.date >= '%s' ) AND (prestations.date <= '%s' ) %s " %(self.date_debut, self.date_fin, condTransfert)

        req = """
            SELECT  prestations.IDprestation, prestations.IDfamille, prestations.categorie, prestations.date, prestations.montant, prestations.label, prestations.code_compta,
            activites.abrege, types_groupes_activites.observations, types_groupes_activites.anaTransports, nomsFamille.nom,nomsFamille.prenom, individus.nom, individus.prenom, matGroupes.grpAnalytique
            %s
            FROM (((((prestations
            LEFT JOIN ((inscriptions
                LEFT JOIN groupes ON inscriptions.IDgroupe = groupes.IDgroupe)
                LEFT JOIN matGroupes ON groupes.IDgroupe = matGroupes.grpIDgroupe)
            ON (prestations.IDactivite = inscriptions.IDactivite) AND (prestations.IDindividu = inscriptions.IDindividu))
            LEFT JOIN (activites
                    LEFT JOIN groupes_activites ON activites.IDactivite = groupes_activites.IDactivite)
            ON prestations.IDactivite = activites.IDactivite)
            LEFT JOIN types_groupes_activites ON groupes_activites.IDtype_groupe_activite = types_groupes_activites.IDtype_groupe_activite)
            LEFT JOIN individus ON prestations.IDindividu = individus.IDindividu)
            LEFT JOIN
                (
                SELECT titulaires.IDfamille, individus.IDindividu, individus.nom, individus.prenom
                FROM (
                    SELECT rattachements.IDfamille, rattachements.titulaire, Min(rattachements.IDindividu) AS MinDeIDindividu
                    FROM rattachements
                    GROUP BY rattachements.IDfamille, rattachements.titulaire
                    HAVING rattachements.titulaire = 1
                     ) as titulaires
				INNER JOIN individus ON titulaires.MinDeIDindividu = individus.IDindividu
				) as nomsFamille
			ON prestations.IDfamille = nomsFamille.IDfamille)
			%s
            WHERE %s
            GROUP BY prestations.IDprestation
            ;""" % (complChamp, complJoin, condition)

        retour = DB.ExecuterReq(req,MsgBox = u"ReqPrestations")
        if retour != "ok" :
            aGestionDB.MessageBox(None,retour)
            DB.Close()
            return False
        listeDonnees = DB.ResultatReq()
        if datePrestPourConsos : type = "consos"
        else: type = "od"
        dlgAttente = PBI.PyBusyInfo(_(u"Traitement de  %d prestations de type %s pour transfert compta...")%(len(listeDonnees),type), parent=None, title=_(u"Veuillez patienter..."), icon=wx.Bitmap("Images/16x16/Logo.png", wx.BITMAP_TYPE_ANY))
        wx.Yield()

        listeIDprestations = []
        for IDprestation, IDfamille, categorie, datePrestation, montant, label, codeComptaPrestation, abregeActivite, actAnalytique, actAnalyTransp, nomFamille, prenomFamille, nomIndividu, prenomIndividu, grpAnalytique, noFacture, noAvoir, dateFacture in listeDonnees :
            ok = True
            if datePrestPourConsos:
                if noFacture == None and noAvoir == None:
                    # perte du lien prestation-facture-piece pour une conso : on ne transf�re pas une anomalie
                    ok = False
            if ok:
                listeIDprestations.append(IDprestation)
                if Nz(montant) != FloatToDecimal(0.0) :
                    if datePrestPourConsos:
                        date = dateFacture
                    else: date = datePrestation
                    if label == None : label = "prest: " + str(IDprestation)
                    if nomFamille == None : nomFamille = u"fam: %s" % str(IDfamille)
                    if prenomFamille == None : prenomFamille = u" "
                    nomFamille = nomFamille[:18] + u" " + prenomFamille
                    if abregeActivite == None : reference = categorie.replace('import','Imp')
                    else: reference = abregeActivite

                    if codeComptaPrestation == None: codeComptaPrestation = ""
                    if codeComptaPrestation == "":
                        if categorie == "don":
                            codeComptaPrestation = self.dictParametres["dons"]
                        elif categorie == "debour":
                            codeComptaPrestation = self.dictParametres["debours"]
                        elif categorie in ["importOD","importAnnul]"]:
                            codeComptaPrestation = code_ventes
                        else: codeComptaPrestation = self.dictParametres["autres"]
                    if actAnalytique == None: actAnalytique = "00"
                    if grpAnalytique == None: grpAnalytique = ""
                    code_compta = codeComptaPrestation
                    analytique = ("00" + actAnalytique)[-2:]
                    if grpAnalytique != None :
                        if analytique == "00": analytique = ("00" + grpAnalytique)[-2:]
                    if analytique != "00" and len(analytique) == 2:
                        code_compta = code_compta[:3] + analytique
                        analytique = ''
                    libCompte = categorie
                    noPiece= IDprestation
                    libEcriture = categorie +"-"+label

                    # -------------- Ventes cr�dit : Ventilation par prestation sans regroupement ---------------
                    dictLigne = self.DictEcritureComplete("ODprestation",str(date),journal,code_compta,libCompte,libEcriture ,noPiece,
                                                          FloatToDecimal(montant),"C",reference=str(IDfamille),analytique=analytique)
                    listeDictLignes.append((noPiece,dictLigne))
                    # -------------- Ventes d�bit : Ventilation par prestation sans regroupement ---------------
                    dictLigne2 = copy.deepcopy(dictLigne)
                    dictLigne2["sens"] = "D"
                    dictLigne2["compte"] = code_clients + ("00000" + str(IDfamille))[-4:]
                    dictLigne2["libCompte"] = nomFamille
                    dictLigne2["libEcriture"] = label
                    dictLigne2["reference"] = reference
                    listeDictLignes.append((noPiece,dictLigne2))
        # Modif des pointeurs de transferts
        self.SetPointeursPrestations(DB,listeIDprestations,[])

        if len(listeIDprestations) > 0 :
            listeSQL = "( " +str(listeIDprestations)[1:-1] + " )"
            req = """SELECT matPieces.pieIDnumPiece
                        FROM (prestations
                        INNER JOIN factures ON prestations.IDfacture = factures.IDfacture)
                        INNER JOIN matPieces ON factures.numero = matPieces.pieNoFacture
                     WHERE IDprestation IN %s ;""" % listeSQL

            retour = DB.ExecuterReq(req,MsgBox=u"aDLG_Exportcompta.GetODprestations2")
            if retour != "ok" :
                aGestionDB.MessageBox(None,retour)
                DB.Close()
                return False
            recordset = DB.ResultatReq()
            listeNoPiecesFac = []
            for IDnumPiece in recordset:
                listeNoPiecesFac.append(IDnumPiece[0])

            req = """SELECT matPieces.pieIDnumPiece
                        FROM (prestations
                        INNER JOIN factures ON prestations.IDfacture = factures.IDfacture)
                        INNER JOIN matPieces ON factures.numero = matPieces.pieNoAvoir
                     WHERE IDprestation IN %s ;""" % listeSQL
            retour = DB.ExecuterReq(req,MsgBox=u"aDLG_Exportcompta.GetODprestations3")
            if retour != "ok" :
                aGestionDB.MessageBox(None,retour)
                DB.Close()
                return False
            recordset = DB.ResultatReq()
            listeNoPiecesAvo = []
            for IDnumPiece in recordset:
                listeNoPiecesAvo.append(IDnumPiece[0])
            if len(listeNoPiecesFac)+ len(listeNoPiecesAvo) > 0:
                self.SetPointeursPieces(DB,listeNoPiecesFac,listeNoPiecesAvo)
        DB.Close()
        del  dlgAttente
        return listeDictLignes
        #fin GetPrestations

    def GetPieces(self):
        # Transfert des ventes regroup�es par pi�ces comptables
        DB = aGestionDB.DB()

        # Recherche compte et libell� 'transport' dans le plan comptable
        if self.dictParametres.has_key("Ventes"):
            compteTransp = self.dictParametres["Ventes"]
        else:
            compteTransp = "706"
        libCompteTransp = "code *TRANSP* pas dans matPlanComptable"

        req = """
            SELECT pctCompte, pctLibelle
            FROM matPlanComptable
            WHERE  pctCodeComptable LIKE '%%TRANSP%%'
            ;"""
        ret = DB.ExecuterReq(req)
        if ret == "ok" :
            recordset = DB.ResultatReq()
            for record in recordset:
                compteTransp = record[0]+"00"
                libCompteTransp = record[1]

        # R�cup des lignes des pi�ces Factures puis Avoir � transf�rer
        listeDictLignes = []
        dictClients = {}
        listeIDprestations = []
        listeIDcontrats = []
        listeNoPiecesFac = []
        listeNoPiecesAvo = []
        nbPieces = 0
        for facture in [True,False]:
            if facture :
                if not self.dictParametres["retransfert"] :
                    condTransfert = " AND ( pieComptaFac IS NULL )"
                else : condTransfert = ""
                condition  = " ((ligMontant <> 0) OR (piePrixTranspAller IS NOT NULL )OR (piePrixTranspRetour IS NOT NULL ) ) AND (pieDateFacturation >= '%s' ) AND (pieDateFacturation <= '%s' ) %s " %(self.date_debut, self.date_fin, condTransfert)

                req = """
                    SELECT  matPieces.pieIDnumPiece, matPiecesLignes.ligIDnumLigne, matPieces.pieDateFacturation, activites.abrege,
                    types_groupes_activites.observations, types_groupes_activites.anaTransports,
                    matGroupes.grpAnalytique, matPieces.pieIDfamille, nomsFamille.nom, nomsFamille.prenom,individus.nom, individus.prenom, matPieces.pieNoFacture,
                    matPieces.piePrixTranspAller, matPieces.piePrixTranspRetour, matPiecesLignes.ligLibelle, matPiecesLignes.ligMontant, matPiecesLignes.ligCodeArticle,
                    matPlanComptable.pctCompte, matPlanComptable.pctLibelle, matPieces.pieIDprestation
                    FROM (((((((matPieces
                    LEFT JOIN matGroupes ON matPieces.pieIDgroupe = matGroupes.grpIDgroupe)
                    LEFT JOIN (activites
                            LEFT JOIN groupes_activites ON activites.IDactivite = groupes_activites.IDactivite) ON matPieces.pieIDactivite = activites.IDactivite)
                            LEFT JOIN types_groupes_activites ON groupes_activites.IDtype_groupe_activite = types_groupes_activites.IDtype_groupe_activite)
                            LEFT JOIN individus ON matPieces.pieIDindividu = individus.IDindividu)
                            LEFT JOIN matPiecesLignes ON matPieces.pieIDnumPiece = matPiecesLignes.ligIDnumPiece)
                            LEFT JOIN (
                                    SELECT titulaires.IDfamille, individus.IDindividu, individus.nom, individus.prenom
                                    FROM (
                                        SELECT rattachements.IDfamille, rattachements.titulaire, Min(rattachements.IDindividu) AS MinDeIDindividu
                                        FROM rattachements
                                        WHERE rattachements.titulaire = 1
                                        GROUP BY rattachements.IDfamille, rattachements.titulaire
                                         ) as titulaires
                                    INNER JOIN individus ON titulaires.MinDeIDindividu = individus.IDindividu
                                    ) as nomsFamille
                            ON matPieces.pieIDfamille = nomsFamille.IDfamille)
                            LEFT JOIN matArticles ON matPiecesLignes.ligCodeArticle = matArticles.artCodeArticle)
                    LEFT JOIN matPlanComptable ON matArticles.artCodeComptable = matPlanComptable.pctCodeComptable
                    WHERE %s
                    GROUP BY  matPieces.pieIDnumPiece, matPiecesLignes.ligIDnumLigne, matPieces.pieDateFacturation, activites.abrege, types_groupes_activites.observations, matGroupes.grpAnalytique, matPieces.pieIDfamille, individus.nom, individus.prenom, matPieces.pieNoFacture, matPieces.piePrixTranspAller, matPieces.piePrixTranspRetour, matPiecesLignes.ligLibelle, matPiecesLignes.ligMontant, matPiecesLignes.ligCodeArticle, matPlanComptable.pctCompte, matPlanComptable.pctLibelle
                    ORDER BY matPieces.pieIDnumPiece
                    ;""" % (condition)
            else:
                if not self.dictParametres["retransfert"] :
                    condTransfert = " AND ( pieComptaAvo IS NULL )"
                else : condTransfert = ""
                condition  = " ((ligMontant <> 0) OR (piePrixTranspAller IS NOT NULL )OR (piePrixTranspRetour  IS NOT NULL)) AND (pieDateAvoir >= '%s' ) AND (pieDateAvoir <= '%s' ) %s " %(self.date_debut, self.date_fin, condTransfert)

                req = """
                    SELECT  matPieces.pieIDnumPiece, matPiecesLignes.ligIDnumLigne, matPieces.pieDateAvoir, activites.abrege,
                    types_groupes_activites.observations, types_groupes_activites.anaTransports,
                    matGroupes.grpAnalytique, matPieces.pieIDfamille, nomsFamille.nom, nomsFamille.prenom, individus.nom, individus.prenom,
                    matPieces.pieNoAvoir, matPieces.piePrixTranspAller, matPieces.piePrixTranspRetour,
                    matPiecesLignes.ligLibelle, matPiecesLignes.ligMontant, matPiecesLignes.ligCodeArticle, matPlanComptable.pctCompte, matPlanComptable.pctLibelle, matPieces.pieIDprestation
                    FROM (((((((matPieces
                    LEFT JOIN matGroupes ON matPieces.pieIDgroupe = matGroupes.grpIDgroupe)
                    LEFT JOIN (activites
                            LEFT JOIN groupes_activites ON activites.IDactivite = groupes_activites.IDactivite) ON matPieces.pieIDactivite = activites.IDactivite)
                            LEFT JOIN types_groupes_activites ON groupes_activites.IDtype_groupe_activite = types_groupes_activites.IDtype_groupe_activite)
                            LEFT JOIN individus ON matPieces.pieIDindividu = individus.IDindividu)
                            LEFT JOIN matPiecesLignes ON matPieces.pieIDnumPiece = matPiecesLignes.ligIDnumPiece)
                            LEFT JOIN
                                (
                                SELECT titulaires.IDfamille, individus.IDindividu, individus.nom, individus.prenom
                                FROM (
                                    SELECT rattachements.IDfamille, rattachements.titulaire, Min(rattachements.IDindividu) AS MinDeIDindividu
                                    FROM rattachements
                                    GROUP BY rattachements.IDfamille, rattachements.titulaire
                                    HAVING rattachements.titulaire = 1
                                     ) as titulaires
                                INNER JOIN individus ON titulaires.MinDeIDindividu = individus.IDindividu
                                ) as nomsFamille
                            ON matPieces.pieIDfamille = nomsFamille.IDfamille)
                            LEFT JOIN matArticles ON matPiecesLignes.ligCodeArticle = matArticles.artCodeArticle)
                    LEFT JOIN matPlanComptable ON matArticles.artCodeComptable = matPlanComptable.pctCodeComptable
                    WHERE %s
                    GROUP BY  matPieces.pieIDnumPiece, matPiecesLignes.ligIDnumLigne, matPieces.pieDateAvoir, activites.abrege, types_groupes_activites.observations, matGroupes.grpAnalytique, matPieces.pieIDfamille, individus.nom, individus.prenom, matPieces.pieNoAvoir, matPieces.piePrixTranspAller, matPieces.piePrixTranspRetour, matPiecesLignes.ligLibelle, matPiecesLignes.ligMontant, matPiecesLignes.ligCodeArticle, matPlanComptable.pctCompte, matPlanComptable.pctLibelle
                    ORDER BY matPieces.pieIDnumPiece
                    ;""" % (condition)

            retour = DB.ExecuterReq(req,MsgBox=u"GetPieces")
            if retour != "ok" :
                aGestionDB.MessageBox(None,retour)
                DB.Close()
                return False
            listeDonnees = DB.ResultatReq()

            if facture:
                type = "facture"
            else:
                type = "avoir"
            nbPieces += len(listeDonnees)
            dlgAttente = PBI.PyBusyInfo(_(u"Traitement de  %d pi�ces %ss pour transfert compta...")%(len(listeDonnees),type), parent=None, title=_(u"Veuillez patienter..."), icon=wx.Bitmap("Images/16x16/Logo.png", wx.BITMAP_TYPE_ANY))
            wx.Yield()

            journal = ("00"+self.dictParametres["journal_ventes"])[-2:]
            oldIDnumpiece = 0
            #listeChampsLigne = ["IDnumPiece","IDnumLigne", "date", "abrege", "actAnalytique", "grpAnalytique", "IDfamille", "nomFamille", "nomIndividu", "prenom", "noPiece", "prixTranspAller", "prixTranspRetour", "libelle", "montant", "codeArticle", "compte", "libCompte", "IDprestation]
            for IDnumPiece, IDnumLigne, date, abrege, actAnalytique, actAnalyTransp, grpAnalytique, IDfamille, nomFamille, prenomFamille, nomIndividu, prenom, noPiece, prixTranspAller, prixTranspRetour, libelle, montant, codeArticle, compte, libCompte,IDprestation in listeDonnees :
                montant = Nz(montant)
                prixTranspAller = Nz(prixTranspAller)
                prixTranspRetour = Nz(prixTranspRetour)
                if codeArticle == None:
                    codeArticle = "noArt."
                date = str(date)

                if actAnalytique == None : actAnalytique = "00"
                if nomFamille == None : nomFamille = u"Sans responsable"
                if prenomFamille == None : prenomFamille = u" "
                nomFamille = nomFamille[:18] + u" " + prenomFamille
                if nomIndividu == None :
                    nomIndividu = u"Famille"
                    prenom = nomFamille
                if prenom == None : prenom = u" "
                lgNom = len(nomIndividu[:10])
                libVte = nomIndividu[:10] + u" " + (prenom + "               ")[:16-lgNom] + u" " + codeArticle[:7]
                if abrege == None :
                    abrege = ""
                else : abrege = " - " + abrege[:8]
                analytique = ("00" + actAnalytique)[-2:]
                if grpAnalytique != None : analytique += grpAnalytique
                reference = ("00000" + str(IDfamille))[-4:]
                if noPiece == None :
                    aGestionDB.MessageBox(None,u"Probl�me de logique : pas de no facture ou avoir pour la famille %s %d avec date de facturation" % (nomFamille,IDfamille), titre=u"Anomalie � corriger")
                    DB.Close()
                    del dlgAttente
                    return False
                if compte == None :
                    if self.dictArticles.has_key(codeArticle):
                        compte = self.dictArticles[codeArticle]

                if compte == None and facture and Nz(montant) != 0.0:
                    aGestionDB.MessageBox(None,u"3 Pas de no de compte pour l'article %s " % codeArticle , titre=u"Compte vente par d�faut")
                if compte == None :
                    compte = self.dictParametres["code_ventes"]

                if libCompte == None : libCompte = ""
                if len(compte)<5 :
                    compte = compte + "000"
                    compte = compte[:3]
                    compte += actAnalytique
                if len(compteTransp)<5 :
                    compteTransp = compteTransp + "000"
                    compteTransp = compteTransp[:5]
                if actAnalyTransp != None and actAnalyTransp != '':
                    compteTransp = compteTransp[:3] + actAnalyTransp
                #constitution de la liste de dictionnaires par ligne de produit (cr�dit)
                if montant != 0.0:
                    montant = round(montant,2)
                    if facture :
                        dictTemp = self.DictEcritureComplete(type,date,journal,compte,libCompte + abrege,libVte,noPiece,montant,"C",reference=reference, analytique=analytique)
                    else :
                        dictTemp = self.DictEcritureComplete(type,date,journal,compte,libCompte + abrege,libVte,noPiece,montant,"D",reference=reference, analytique=analytique)
                    listeDictLignes.append((noPiece,dictTemp))
                mttTransp = 0.0
                if oldIDnumpiece != IDnumPiece :
                    oldIDnumpiece = IDnumPiece
                    if prixTranspAller != None : mttTransp += prixTranspAller
                    if prixTranspRetour != None : mttTransp += prixTranspRetour
                if mttTransp != 0.0:
                    mttTransp = round(mttTransp,2)
                    libelle = "Transport " + prenom + " " + nomIndividu
                    if facture:
                        dictTemp = self.DictEcritureComplete(type,date,journal,compteTransp,libCompteTransp + abrege,libelle,noPiece,mttTransp,"C",reference=reference, analytique=analytique)
                    else:
                        dictTemp = self.DictEcritureComplete(type,date,journal,compteTransp,libCompteTransp + abrege,libelle,noPiece,mttTransp,"D",reference=reference, analytique=analytique)
                    listeDictLignes.append((noPiece,dictTemp))

                # Stockage pour les d�bits
                if not dictClients.has_key((IDfamille,noPiece)):
                    dictClients[(IDfamille,noPiece)] = {"date" : date, "montant" : montant + mttTransp, "nomFamille" : nomFamille, "type" : type}
                else :
                    if dictClients[(IDfamille,noPiece)]["type"] == type:
                        dictClients[(IDfamille,noPiece)]["montant"] += montant + mttTransp
                    else:
                        aGestionDB.MessageBox(None,u"Le no de pi�ce %d est utils� � la fois comme avoir et facture" % noPiece , titre=u"Anomalie � corriger")
                        dictClients[(IDfamille,noPiece)]["montant"] -= (montant + mttTransp)
                        DB.Close()
                        del dlgAttente
                        return False
                #stockage pour les pointeurs de transfert
                if facture :
                    if (not IDprestation in listeIDprestations) and IDprestation != None:
                        listeIDprestations.append(IDprestation)
                    if not IDnumPiece in listeNoPiecesFac:
                        listeNoPiecesFac.append(IDnumPiece)
                else:
                    if (not IDnumPiece in listeIDcontrats) and IDnumPiece != None:
                        listeIDcontrats.append(IDnumPiece)
                    if not IDnumPiece in listeNoPiecesAvo:
                        listeNoPiecesAvo.append(IDnumPiece)
            del dlgAttente

        dlgAttente = PBI.PyBusyInfo(_(u"Pr�paration de %d �critures potentielles de ventes pour transfert compta...")%(nbPieces), parent=None, title=_(u"Veuillez patienter..."), icon=wx.Bitmap("Images/16x16/Logo.png", wx.BITMAP_TYPE_ANY))
        wx.Yield()
        # g�n�rations des contreparties client
        for (IDfamille,noPiece) in dictClients.keys() :
            date = dictClients[(IDfamille,noPiece)]["date"]
            montant = dictClients[(IDfamille,noPiece)]["montant"]
            libCompte = dictClients[(IDfamille,noPiece)]["nomFamille"]
            code_clients = self.dictParametres["code_clients"]
            if code_clients == None : code_clients = "4"
            compte = code_clients + ("00000" + str(IDfamille))[-4:]
            if dictClients[(IDfamille,noPiece)]["type"] == "facture" :
                libelle = u"Fac " + str(noPiece) + u" " + libCompte
                dictTemp = self.DictEcritureComplete(type,date,journal,compte,libCompte,libelle,noPiece,montant,"D",'conso')
            else :
                libelle = u"Avo " + str(noPiece) + u" " + libCompte
                dictTemp = self.DictEcritureComplete(type,date,journal,compte,libCompte,libelle,noPiece,montant,"C",'annul')
            listeDictLignes.append((noPiece,dictTemp))
        # Modif des pointeurs de transferts
        self.SetPointeursPrestations(DB,listeIDprestations,listeIDcontrats)
        self.SetPointeursPieces(DB,listeNoPiecesFac,listeNoPiecesAvo)
        del dlgAttente
        return listeDictLignes
        #fin GetPieces

    def GetReglements_OD(self):
        # selection des r�glements de type OD et pas d'un mode 'Ban*"
        listeDictLignes = []
        DB = aGestionDB.DB()
        journal = ("00"+self.dictParametres["journal_od_banque"])[-2:]
        codeClients = self.dictParametres["code_clients"]
        if codeClients == None : codeClients = "4"
        codeBanque = self.dictParametres["code_banque"]

        # Condition de s�lection des r�glements
            #condDepot = "AND (modes_reglements.type_comptable <> 'banque') AND (reglements.IDdepot IS NULL)"
            #condDepot = "AND (modes_reglements.type_comptable <> 'banque')"
        condDate = "(( reglements.date>='%s' AND reglements.date<='%s' )OR( reglements.date_differe >='%s' AND reglements.date_differe <='%s' ))" % (self.date_debut, self.date_fin,self.date_debut, self.date_fin)

        if not self.dictParametres["retransfert"] :
            #condTransfert = " AND ( reglements.compta IS NULL ) %s" % condDepot
            condTransfert = " AND ( reglements.compta IS NULL )"
        else :
            #condTransfert = " AND (modes_reglements.type_comptable <> 'banque') %s " % condDepot
            condTransfert = " "
        condition = condDate + condTransfert
        # tous r�glements sans consid�ration des d�pots
        req = """
            SELECT reglements.IDreglement, reglements.Date, reglements.date_differe, reglements.encaissement_attente, emetteurs.nom, reglements.IDcompte_payeur, reglements.numero_piece, reglements.montant, reglements.date_saisie, modes_reglements.label, modes_reglements.code_compta, nomsFamille.nom, nomsFamille.prenom
            FROM (  (   reglements
                        LEFT JOIN modes_reglements ON reglements.IDmode = modes_reglements.IDmode
                    )
                    LEFT JOIN emetteurs ON (reglements.IDemetteur = emetteurs.IDemetteur) AND (reglements.IDmode = emetteurs.IDmode)
                )
                LEFT JOIN ( SELECT titulaires.IDfamille, individus.IDindividu, individus.nom, individus.prenom
                            FROM (  SELECT rattachements.IDfamille, rattachements.titulaire, Min(rattachements.IDindividu) AS MinDeIDindividu
                                    FROM rattachements
                                    WHERE rattachements.titulaire = 1
                                    GROUP BY rattachements.IDfamille, rattachements.titulaire
                                ) as titulaires
                            INNER JOIN individus ON titulaires.MinDeIDindividu = individus.IDindividu
                )  AS nomsFamille
                ON reglements.IDcompte_payeur = nomsFamille.IDfamille
            WHERE %s
            GROUP BY reglements.IDreglement
            ;""" % condition
        retour = DB.ExecuterReq(req)

        if retour != "ok" :
            aGestionDB.MessageBox(None,retour)
            DB.Close()
            return []
        listeDonnees = DB.ResultatReq()
        dlgAttente = PBI.PyBusyInfo(_(u"Traitement de %d r�glements pour transfert compta...")%(len(listeDonnees)), parent=None, title=_(u"Veuillez patienter..."), icon=wx.Bitmap("Images/16x16/Logo.png", wx.BITMAP_TYPE_ANY))
        wx.Yield()
        listeIDreglements = []
        #priorit� � la date de diff�r� si elle est non nulle
        for IDreglement, dateReglement, dateDiffere, attente, nomEmetteur, IDcompte_payeur, numeroCheque, montant, dateSaisie, modeReglement, comptaMode, nomFamille, prenomFamille in listeDonnees :
            # les r�glements en attente sont ignor�s
            if attente != 0 :
                self.nbreAttente += 1
                continue
            # les r�glements diff�r�s attendent leur date de diff�r� pour �tre transf�r�s
            if dateDiffere != None:
                if DateEngEnDateDD(dateDiffere) > self.date_fin:
                    self.nbreDifferes +=1
                    continue
                dateComptaRegl = dateDiffere
            else:
                dateComptaRegl = dateReglement
            listeIDreglements.append(IDreglement)
            if nomFamille == None : nomFamille = u" "
            if prenomFamille == None : prenomFamille = u" "
            nomPayeur = nomFamille[:18] + " " + prenomFamille
            if comptaMode == None:
                comptaMode = ""
            # compte du mode de r�glement puis le compte de la banque associ�e au r�glement
            codeCompta = comptaMode
            if len(codeCompta) < 2:
                codeCompta = codeBanque

            #composition cr�dit
            codeClient = codeClients+ ("00000"+str(IDcompte_payeur))[-4:]
            emission = "???"
            if nomEmetteur != None:
                emission = nomEmetteur
            else:
                if modeReglement != None:
                    emission = modeReglement
            label = u"%s %s %s" % (FormateDate(DateEngEnDateDD(dateSaisie)), emission[:7] ,nomPayeur)
            noPiece = IDreglement

            dictLigne = self.DictEcritureComplete("reglement",str(dateComptaRegl),journal,codeClient,nomPayeur,label ,noPiece,
                                                  FloatToDecimal(montant),"C",reference= modeReglement)
            listeDictLignes.append((noPiece,dictLigne))

            #reprise pour d�bit
            label = u"%s %s-%s" % (modeReglement[:3],emission[:7],nomPayeur)

            # -------------- R�glement d�bit : sans regroupement ---------------
            dictLigne2 = copy.deepcopy(dictLigne)
            dictLigne2["sens"] = "D"
            dictLigne2["compte"] = codeCompta
            dictLigne2["libCompte"] = emission
            dictLigne2["libEcriture"] = label
            dictLigne2["reference"] = modeReglement
            listeDictLignes.append((noPiece,dictLigne2))
        # Modif des pointeurs de transferts
        self.SetPointeursReglements(DB,listeIDreglements)

        del dlgAttente
        if self.nbreAttente >0:
            # Avertissement de pr�sence de r�glements en attente
            msg = aGestionDB.Messages()
            msg.Box(message= _(u"Il y a %d r�glements en attente qui n'ont pas �t� transf�r�s !")% self.nbreAttente,titre= u"R�glements non transf�r�s")
            msg.Destroy()
        if self.nbreDifferes >0:
            # Avertissement de pr�sence de r�glements avec dates diff�r�es post�rieures
            msg = aGestionDB.Messages()
            msg.Box(message= _(u"Il y a %d r�glements avec des dates futures qui n'ont pas �t� transf�r�s !")% self.nbreDifferes,titre= u"R�glements non transf�r�s")
            msg.Destroy()
        return listeDictLignes
        #fin GetReglements_OD

    def GetReglements_Depots(self):
        # selection des r�glements ayant fait l'objet d'un d�p�t
        listeDictLignes = []
        DB = aGestionDB.DB()
        journal = ("00"+self.dictParametres["journal_banque"])[-2:]
        codeClients = self.dictParametres["code_clients"]
        if codeClients == None : codeClients = "4"
        codeBanque = self.dictParametres["code_banque"]
        # Condition de s�lection des r�glements
        if not self.dictParametres["retransfert"] :
            condTransfert = " AND ( reglements.compta IS NULL )"
        else : condTransfert = ""

        condition = "reglements.IDdepot IS NOT NULL AND depots.date IS NOT NULL AND depots.date>='%s' AND depots.date<='%s'" % (self.date_debut, self.date_fin)
        condition += condTransfert
        # r�glements ayant fait l'objet d'un d�p�t et n'�tant pas d�j� transf�r�s
        req = """
        SELECT depots.IDdepot, depots.Date, depots.nom, comptes_bancaires.nom, comptes_bancaires.numero, reglements.IDcompte_payeur,
                reglements.numero_piece, reglements.montant, reglements.date_saisie,  modes_reglements.IDmode, modes_reglements.label,
                modes_reglements.code_compta,depots.code_compta, comptes_bancaires.code_nne, nomsFamille.nom, nomsFamille.prenom,
                reglements.IDreglement, modes_reglements.type_comptable, reglements.IDemetteur, emetteurs.nom
        FROM (  (   (   (depots
                        LEFT JOIN reglements ON depots.IDdepot = reglements.IDdepot)
                    LEFT JOIN modes_reglements ON reglements.IDmode = modes_reglements.IDmode)
                LEFT JOIN comptes_bancaires ON depots.IDcompte = comptes_bancaires.IDcompte)
        LEFT JOIN (
                SELECT titulaires.IDfamille, individus.IDindividu, individus.nom, individus.prenom
                FROM (
                    SELECT rattachements.IDfamille, rattachements.titulaire, Min(rattachements.IDindividu) AS MinDeIDindividu
                    FROM rattachements
                    WHERE rattachements.titulaire = 1
                    GROUP BY rattachements.IDfamille, rattachements.titulaire
                     ) as titulaires
                    INNER JOIN individus ON titulaires.MinDeIDindividu = individus.IDindividu
                    ) as nomsFamille ON reglements.IDcompte_payeur = nomsFamille.IDfamille)
	    LEFT JOIN emetteurs ON (reglements.IDemetteur = emetteurs.IDemetteur) AND (reglements.IDmode = emetteurs.IDmode)
        WHERE %s
        ;""" % condition

        retour = DB.ExecuterReq(req)
        if retour != "ok" :
            aGestionDB.MessageBox(None,retour)
            DB.Close()
            return []
        listeDonnees = DB.ResultatReq()

        dictDepots = {}
        listeIDreglements = []
        for IDdepot, dateDepot, nomDepot, nomBanque, numeroBanque,IDcompte_payeur, numeroReglement,montant,dateSaisie,IDmode, modeReglement,comptaMode,comptaDepot,comptaBanque,nomFamille, prenomFamille,IDreglement,group,IDemetteur, nomEmetteur in listeDonnees :
            if nomFamille == None : nomFamille = u" "
            if prenomFamille == None : prenomFamille = u" "
            nomPayeur = nomFamille[:18] + " " + prenomFamille
            listeIDreglements.append(IDreglement)
            if comptaMode == None:
                comptaMode = ""
            if comptaBanque == None:
                comptaBanque = ""
            # priorit� est donn�e au code comptable du d�pot s'il est num�rique
            try:
                codeCompta = str(int(comptaDepot))
            except: codeCompta = ""

            if len(codeCompta) < 2 :
                # ensuite compte de la banque associ�e au d�pot puis le compte du mode de r�glement
                if len(codeCompta) < 2:
                    codeCompta = comptaBanque
                if len(codeCompta) < 2:
                    codeCompta = comptaMode
                if len(codeCompta) < 2:
                    codeCompta = codeBanque


            if montant == None: montant = FloatToDecimal(0.0)
            if nomDepot == None: nomDepot = ""
            if group == "banque":
                cle = (IDdepot, IDmode)
                label = u"%s-%s" % (modeReglement[:7],nomDepot)
                ref = u"Bq:%s" %nomBanque[:7]
            elif group == 'bancaf':
                cle = (IDdepot,IDemetteur)
                if nomEmetteur == None: nomEmetteur = ""
                label = u"%s-%s-%s" % (modeReglement[:3],nomBanque[:3],nomEmetteur)
                ref = u"Dep:%s" %nomDepot[:7]
            else :
                cle = (IDreglement)
                if nomEmetteur == None: nomEmetteur = ""
                if nomPayeur == None: nomPayeur = ""
                label = u"%s %s %s" % (modeReglement[:3]+nomEmetteur[:5], FormateDate(DateEngEnDateDD(dateSaisie))[:5],nomPayeur)
                ref = u"412%s" %IDcompte_payeur
            #regroupements pour debits
            if dictDepots.has_key((cle,codeCompta)):
                dictDepots[(cle,codeCompta)]["nbre"]+=1
                dictDepots[(cle,codeCompta)]["montant"]+=FloatToDecimal(montant)
            else:
                dictDepots[(cle,codeCompta)]={}
                dictDepots[(cle,codeCompta)]["nbre"]=1
                dictDepots[(cle,codeCompta)]["montant"]=FloatToDecimal(montant)
                dictDepots[(cle,codeCompta)]["date"]= dateDepot
                dictDepots[(cle,codeCompta)]["IDdepot"]=IDdepot
                dictDepots[(cle,codeCompta)]["nomDepot"]=nomDepot
                dictDepots[(cle,codeCompta)]["nomBanque"]=nomBanque.replace(" ","")
                dictDepots[(cle,codeCompta)]["numeroBanque"]=numeroBanque
                dictDepots[(cle,codeCompta)]["codeCompta"]=codeCompta
                dictDepots[(cle,codeCompta)]["label"]=label
                dictDepots[(cle,codeCompta)]["ref"]=ref

            #composition cr�dit
            listeLignes = []
            codeClient = codeClients+ ("00000"+str(IDcompte_payeur))[-4:]
            label = u"%s %s %s" % (modeReglement[:3]+str(numeroReglement), FormateDate(DateEngEnDateDD(dateSaisie)),nomPayeur)

            dictLigne = self.DictEcritureComplete("depot",str(dateDepot),journal,codeClient,nomPayeur,label ,IDdepot,
                                                  FloatToDecimal(montant),"C",reference= (u"Bq:"+ nomBanque.replace(" ","")))
            listeDictLignes.append((cle,dictLigne))

        #reprise des totaux par d�pot pour d�bits
        for (cle,codeCompta) in dictDepots.keys():
            nbre = str(dictDepots[(cle,codeCompta)]["nbre"])
            if nbre in ["0","1"]: nbre = ""
            label = u"%s%s" % (nbre, dictDepots[(cle,codeCompta)]["label"])
            ref = dictDepots[(cle,codeCompta)]["ref"]

            # DictEcritureComplete(self,type,date,journal,compte,     libCompte,libEcriture,noPiece,    montant,sens,reference="
            dictLigne = self.DictEcritureComplete("depot",str(dictDepots[(cle,codeCompta)]["date"]),journal,dictDepots[(cle,codeCompta)]["codeCompta"],
                                                  dictDepots[(cle,codeCompta)]["nomBanque"],label ,dictDepots[(cle,codeCompta)]["IDdepot"],
                                                  dictDepots[(cle,codeCompta)]["montant"],"D",reference= ref)
            listeDictLignes.append((cle,dictLigne))
        # Modif des pointeurs de transferts
        self.SetPointeursReglements(DB,listeIDreglements)

        return listeDictLignes
        #fin GetReglements_Depots

class CTRL_Logiciel(BitmapComboBox):
    def __init__(self, parent, size=(-1,  -1)):
        BitmapComboBox.__init__(self, parent, size=size, style=wx.CB_READONLY)
        self.parent = parent
        self.listeFormats = [
            {"code" : "compta_matt_delimite", "label" : _(u"Matth Compta (Champs d�limit�s)"), "image" : wx.Bitmap('Images/48x48/Sync_upload.png', wx.BITMAP_TYPE_PNG)},
            {"code" : "compta_matt_fixe", "label" : _(u"Matth Compta (Largeurs fixes)"), "image" : wx.Bitmap('Images/48x48/Sync_upload.png', wx.BITMAP_TYPE_PNG)},
            {"code" : "compta_ebp", "label" : _(u"EBP Compta"), "image" : wx.Bitmap('Images/48x48/Logiciel_ebp.png', wx.BITMAP_TYPE_PNG)},
            ]
        for dictFormat in self.listeFormats :
            self.Append(dictFormat["label"], dictFormat["image"], dictFormat["label"])
        self.SetSelection(0)
        self.Importation() 
    
    def SetCode(self, code=""):
        index = 0
        for dictFormat in self.listeFormats :
            if dictFormat["code"] == code :
                 self.SetSelection(index)
            index += 1

    def GetCode(self):
        index = self.GetSelection()
        if index == -1 : return None
        return self.listeFormats[index]["code"]
    
    def Importation(self):
        format = UTILS_Parametres.Parametres(mode="get", categorie="export_compta", nom="nom_format", valeur="compta_matt_delimite")
        self.SetCode(format) 

    def Sauvegarde(self):
        UTILS_Parametres.Parametres(mode="set", categorie="export_compta", nom="nom_format", valeur=self.GetCode())

# -------------------------------------------------------------------------------------------------------------------------------------------

class CTRL_Parametres(CTRL_Propertygrid.CTRL):#(wxpg.PropertyGrid) :
    def __init__(self, parent, listeDonnees=[]):
        CTRL_Propertygrid.CTRL.__init__(self, parent, style=wxpg.PG_STATIC_SPLITTER )
        self.parent = parent
        self.listeDonnees = listeDonnees
        self.SetExtraStyle(wxpg.PG_EX_HELP_AS_TOOLTIPS)
        couleurFond = "#e5ecf3"
        self.SetCaptionBackgroundColour(couleurFond)
        self.SetMarginColour(couleurFond)
        self.SetSplitterPosition(220)
        self.DB = aGestionDB.DB()

    
    def Remplissage(self):        
        # Autres lignes
        for valeur in self.listeDonnees :
            if type(valeur) == dict :
                if valeur["type"] == "chaine" :
                    propriete = wxpg.StringProperty(label=valeur["label"], name=valeur["code"], value=valeur["defaut"])
                if valeur["type"] == "choix" :
                    propriete = wxpg.EnumProperty(label=valeur["label"], name=valeur["code"], labels=valeur["choix"], values=range(0, len(valeur["choix"])), value=valeur["defaut"])
                if valeur["type"] == "check" :
                    propriete = wxpg.BoolProperty(label=valeur["label"], name=valeur["code"], value=valeur["defaut"])
                    propriete.SetAttribute("UseCheckbox", True)
                propriete.SetHelpString(valeur["tip"]) 
                self.Append(propriete)
            else :
                self.Append(wxpg.PropertyCategory(valeur))

    def Importation(self):
        """ Importation des valeurs dans le contr�le """
        # R�cup�ration des noms et valeurs par d�faut du contr�le
        dictValeurs = copy.deepcopy(self.GetPropertyValues())
        # Recherche les param�tres m�moris�s
        dictParametres = UTILS_Parametres.ParametresCategorie(mode="get", categorie="export_compta", dictParametres=dictValeurs)
        # Envoie les param�tres dans le contr�le
        for nom, valeur in dictParametres.iteritems() :
            propriete = self.GetPropertyByName(nom)
            ancienneValeur = propriete.GetValue() 
            propriete.SetValue(valeur)
    
    def Sauvegarde(self,forcer = False):
        """ M�morisation des valeurs du contr�le"""
        dictValeurs = copy.deepcopy(self.GetPropertyValues())
        UTILS_Parametres.ParametresCategorie(mode="set", categorie="export_compta", dictParametres=dictValeurs)
        self.parent.ctrl_logiciel.Sauvegarde()

    def Validation(self):
        # P�riode
        if self.parent.ctrl_date_debut.GetDate() == None :
            dlg = wx.MessageDialog(self, _(u"Vous devez obligatoirement renseigner la date de d�but de p�riode !"), _(u"Information"), wx.OK | wx.ICON_EXCLAMATION)
            dlg.ShowModal()
            dlg.Destroy()
            return False
        else:
            debutExercice,finExercice = self.DB.GetExercice(self.parent.ctrl_date_debut.GetDate())
            if debutExercice == None:
                return False

        if self.parent.ctrl_date_fin.GetDate() == None :
            dlg = wx.MessageDialog(self, _(u"Vous devez obligatoirement renseigner la date de fin de p�riode !"), _(u"Information"), wx.OK | wx.ICON_EXCLAMATION)
            dlg.ShowModal()
            dlg.Destroy()
            return False
        else:
            debutExercice2,finExercice2 = self.DB.GetExercice(self.parent.ctrl_date_fin.GetDate())
            if debutExercice2 == None:
                return False
        if debutExercice <> debutExercice2:
            dlg = wx.MessageDialog(self, _(u"Non bloquant: Les dates d�but et fin ne sont pas dans le m�me exercice comptable !"), _(u"Ecritures possibles hors exercice"), wx.OK | wx.ICON_EXCLAMATION)
            dlg.ShowModal()
            dlg.Destroy()

        # Param�tres
        for valeur in self.listeDonnees :
            if type(valeur) == dict :
                if valeur["type"] == "chaine" and valeur["obligatoire"] == True and self.GetPropertyValue(valeur["code"]) == "" :
                    dlg = wx.MessageDialog(self, _(u"Vous devez obligatoirement renseigner l'information '%s' !") % valeur["description"], _(u"Information"), wx.OK | wx.ICON_EXCLAMATION)
                    dlg.ShowModal()
                    dlg.Destroy()
                    return False
        return True

    def GetParametres(self):
        dictParametres = self.GetPropertyValues()
        dictParametres["date_debut"] = self.parent.ctrl_date_debut.GetDate() 
        dictParametres["date_fin"] = self.parent.ctrl_date_fin.GetDate() 
        return dictParametres

    def CreationFichier(self, nomFichier="", texte="", iso = "iso-8859-15"):
        # Demande � l'utilisateur le nom de fichier et le r�pertoire de destination
        wildcard = "Fichier texte (*.txt)|*.txt|" \
                        "All files (*.*)|*.*"
        sp = wx.StandardPaths.Get()
        cheminDefaut = sp.GetDocumentsDir()
        dlg = wx.FileDialog(
            None, message = _(u"Veuillez s�lectionner le r�pertoire de destination et le nom du fichier"), defaultDir=cheminDefaut, 
            defaultFile = nomFichier, 
            wildcard = wildcard, 
            style = wx.SAVE
            )
        dlg.SetFilterIndex(0)
        if dlg.ShowModal() == wx.ID_OK:
            cheminFichier = dlg.GetPath()
            dlg.Destroy()
        else:
            dlg.Destroy()
            return
        
        # Le fichier de destination existe d�j� :
        if os.path.isfile(cheminFichier) == True :
            dlg = wx.MessageDialog(None, _(u"Un fichier portant ce nom existe d�j�. \n\nVoulez-vous le remplacer ?"), "Attention !", wx.YES_NO | wx.NO_DEFAULT | wx.ICON_EXCLAMATION)
            if dlg.ShowModal() == wx.ID_NO :
                return False
                dlg.Destroy()
            else:
                dlg.Destroy()

        # Cr�ation du fichier texte
        f = open(cheminFichier, "w")
        if iso == "sans":
            # tous ces caract�res sont transpos�s avec plusieurs par unidecode ex : � -> EUR
            car  = [u"�",u"�",u"�",u"\\",u"?",u"�",u"�",u"�",]
            carR = [u"E",u"o",u"$",u"/",u"-",u"$",u"e",u"e"]
            for i in range(0,len(car)):
                texte=texte.replace(car[i],carR[i])
            try:
                from unidecode import unidecode
                f.write(unidecode(texte))
            except:
                txtMessage = _(u"Il faut installer le module unidecode par la commande systeme PIP INSTALL unidecode")
                dlgConfirm = wx.MessageDialog(None, txtMessage, _(u" "), wx.YES_NO|wx.NO_DEFAULT|wx.ICON_QUESTION)
                dlgConfirm.ShowModal()
                dlgConfirm.Destroy()
        else:
            if iso == 'latin':
                texte=texte.replace(u"�",u"E")
            f.write(texte.encode(iso))
        f.close()
        
        # Confirmation de cr�ation du fichier et demande d'ouverture directe dans Excel
        txtMessage = _(u"Le fichier a �t� cr�� avec succ�s.\n\nSouhaitez-vous l'ouvrir d�s maintenant ?")
        dlgConfirm = wx.MessageDialog(None, txtMessage, _(u"Confirmation"), wx.YES_NO|wx.NO_DEFAULT|wx.ICON_QUESTION)
        reponse = dlgConfirm.ShowModal()
        dlgConfirm.Destroy()
        if reponse == wx.ID_NO:
            return
        else:
            FonctionsPerso.LanceFichierExterne(cheminFichier)

class CTRL_Parametres_defaut(CTRL_Parametres) :
    def __init__(self, parent):
        self.listeDonnees = [
            _(u"Options g�n�rales"),
            {"type":"check", "label":_(u"Export des Ventes"), "description":_(u"Export des Ventes"), "code":"export_ventes", "tip":_(u"Cochez pour exporter les ventes, les avoirs et les prestations saisies"), "defaut":True, "obligatoire":True},
            {"type":"check", "label":_(u"Export des R�glements"), "description":_(u"Export des R�glements"), "code":"export_reglements", "tip":_(u"Cochez pour exporter les r�glements"), "defaut":True, "obligatoire":True},
            {"type":"check", "label":_(u"Ecritures d�j� transf�r�es"), "description":_(u"Ecritures d�j� transf�r�es"), "code":"retransfert", "tip":_(u"Attention risque de doublon dans la compta"), "defaut":False, "obligatoire":True},
            {"type":"choix", "label":_(u"D�tails ventes pour clients"), "description":_(u"Option regroupement des ventes"), "code":"option_ventes", "tip":_(u"S�lectionnez le mode de regroupement des ventes dans le compte client"), "choix":[_(u"Par numero de pi�ce comptable"), _(u"Par prestation")], "defaut":0, "obligatoire":True},
            {"type":"choix", "label":_(u"Option type de r�glements"), "description":_(u"Option s�lection des r�glements"), "code":"option_reglements", "tip":_(u"La date comptable des r�glements d�pend de ce choix"),
             "choix":[_(u"Seuls les r�glements avec d�p�t sur la p�riode sont transf�r�s"), _(u"Transf�re tous les r�glements � leur date de saisie (d�pos�s ou pas)")], "defaut":0, "obligatoire":True},
            {"type":"check", "label":_(u"Ins�rer une ligne d'ent�te"), "description":_(u"Ins�rer ligne noms des champs"), "code":"ligne_noms_champs", "tip":_(u"Cochez pour ins�rer en d�but de fichier une ligne avec les noms des champs"), "defaut":False, "obligatoire":True},
            {"type":"check", "label":_(u"M�moriser les param�tres"), "description":_(u"M�moriser les modifications de param�tres"), "code":"memoriser_parametres", "tip":_(u"Cochez pour m�moriser les param�tres � chaque sortie"), "defaut":False, "obligatoire":True},
            {"type":"choix", "label":_(u"Encodage des caract�res"), "description":_(u"Encodage des caract�ers en sortie"), "code":"encodage", "tip":_(u"Si les accents posent probl�me pr�f�rer le sans accent"), "choix":[_(u"UTF8 standard"), _(u"Supprimer les accents"), _(u"DOS Latin"), _(u"Windows iso-8859-15")], "defaut":0, "obligatoire":True},
            _(u"Codes journaux par d�faut"),
            {"type":"chaine", "label":_(u"Ventes"), "description":_(u"Code journal des ventes"), "code":"journal_ventes", "tip":_(u"Saisissez le code journal des ventes"), "defaut":_(u"02"), "obligatoire":True},
            {"type":"chaine", "label":_(u"Banque"), "description":_(u"Code journal des banques"), "code":"journal_banque", "tip":_(u"Saisissez le code journal de la banque"), "defaut":_(u"04"), "obligatoire":True},
            {"type":"chaine", "label":_(u"ODventes"), "description":_(u"Code journal pour les prestations sans pi�ce"), "code":"journal_od_ventes", "tip":_(u"Code journal des prestations saisies directement"), "defaut":_(u"03"), "obligatoire":True},
            {"type":"chaine", "label":_(u"ODbanque"), "description":_(u"Code journal des r�glements divers"), "code":"journal_od_banque", "tip":_(u"Saisissez le code journal des r�gularisations"), "defaut":_(u"05"), "obligatoire":True},
            _(u"Codes comptables par d�faut"),
            {"type":"chaine", "label":_(u"Ventes"), "description":_(u"Code comptable des ventes"), "code":"code_ventes", "tip":_(u"Saisissez le code comptable des ventes (Peut �tre ajust� en d�tail dans le param�trage des activit�s, des cotisations, des tarifs et des prestations)"), "defaut":u"706", "obligatoire":True},
            {"type":"chaine", "label":_(u"Clients"), "description":_(u"Code comptable des clients"), "code":"code_clients", "tip":_(u"Saisissez le code comptable des clients (Peut- �tre ajust� en d�tail dans la fiche famille)"), "defaut":u"411", "obligatoire":True},
            {"type":"chaine", "label":_(u"R�glements"), "description":_(u"Code comptable de la banque"), "code":"code_banque", "tip":_(u"Saisissez le code comptable de la banque"), "defaut":u"512", "obligatoire":True},
            {"type":"chaine", "label":_(u"D�bours"), "description":_(u"D�bours saisis en prestation"), "code":"debours", "tip":_(u"Saisissez le code comptable utilis� pour les d�bours saisis en prestations"), "defaut":u"58140", "obligatoire":True},
            {"type":"chaine", "label":_(u"Dons"), "description":_(u"Dons saisis en prestation"), "code":"dons", "tip":_(u"Saisissez le code comptable utilis� pour les dons saisis en prestation"), "defaut":u"758", "obligatoire":True},
            {"type":"chaine", "label":_(u"Autres"), "description":_(u"Prestations de type autres"), "code":"autres", "tip":_(u"Saisissez le code comptable des pestations de type 'autre'"), "defaut":u"4711", "obligatoire":True},
            ]
        """_(u"Formats des libell�s"),
        {"type":"chaine", "label":_(u"Client - Prestation"), "description":_(u"Format du libell� des ventes au client"), "code":"format_clients_ventes", "tip":_(u"Saisissez le format du libell� du total des ventes. Vous pouvez utiliser les mots-cl�s suivants : {DATE_DEBUT} {DATE_FIN}."), "defaut":_(u"Prestations du {DATE_DEBUT} au {DATE_FIN}"), "obligatoire":True},
        {"type":"chaine", "label":_(u"Client - R�glement"), "description":_(u"Format du libell� des r�glements du client"), "code":"format_clients_reglements", "tip":_(u"Saisissez le format du libell� du total des r�glements. Vous pouvez utiliser les mots-cl�s suivants : {DATE_DEBUT} {DATE_FIN}."), "defaut":_(u"R�glements du {DATE_DEBUT} au {DATE_FIN}"), "obligatoire":True},
        {"type":"chaine", "label":_(u"Prestation"), "description":_(u"Format du libell� des prestations"), "code":"format_prestation", "tip":_(u"Saisissez le format du libell� des prestations. Vous pouvez utiliser les mots-cl�s suivants : {NOM_PRESTATION} {DATE_DEBUT} {DATE_FIN}."), "defaut":u"{NOM_PRESTATION}", "obligatoire":True},
        {"type":"chaine", "label":_(u"D�p�t"), "description":_(u"Format du libell� des d�p�ts"), "code":"format_depot", "tip":_(u"Saisissez le format du libell� des d�p�ts. Vous pouvez utiliser les mots-cl�s suivants : {IDDEPOT} {NOM_DEPOT} {DATE_DEPOT} {MODE_REGLEMENT} {TYPE_COMPTABLE} {NBRE_REGLEMENTS}."), "defaut":u"{NOM_DEPOT} - {DATE_DEPOT}", "obligatoire":True},
        {"type":"chaine", "label":_(u"R�glement"), "description":_(u"Format du libell� des r�glements"), "code":"format_reglement", "tip":_(u"Saisissez le format du libell� des r�glements. Vous pouvez utiliser les mots-cl�s suivants : {IDREGLEMENT} {DATE} {MODE_REGLEMENT} {NOM_FAMILLE} {NUMERO_PIECE} {NOM_PAYEUR} {NUMERO_QUITTANCIER} {DATE_DEPOT} {NOM_DEPOT}."), "defaut":u"{MODE_REGLEMENT} {NOM_FAMILLE}", "obligatoire":True},
        ]"""
        CTRL_Parametres.__init__(self, parent, self.listeDonnees)

    def Generation(self, format="compta_ebp"):
        dlgAttente = PBI.PyBusyInfo(_(u"V�rification de la coh�rence des donn�es..."), parent=None, title=_(u"Veuillez patienter..."), icon=wx.Bitmap("Images/16x16/Logo.png", wx.BITMAP_TYPE_ANY))
        wx.Yield()
        if self.Validation() == False :
            del dlgAttente
            return False
        # R�cup�ration des param�tres, puis test coh�rence
        dictParametres = self.GetParametres() 
        fDon = Donnees(dictParametres)
        del dlgAttente
        if fDon.coherent == False:
            return False
        dlgAttente = PBI.PyBusyInfo(_(u"Appel de donn�es pr�alables au traitement..."), parent=None, title=_(u"Veuillez patienter..."), icon=wx.Bitmap("Images/16x16/Logo.png", wx.BITMAP_TYPE_ANY))
        wx.Yield()
        numLigne = 1
        listeLignesTxt = []

        iso = 'utf-8'
        encodage = dictParametres["encodage"]
        if encodage == 1:
            iso = 'sans'
        elif encodage == 2:
            iso = 'latin'
        elif encodage == 2:
            iso = 'iso-8859-15'

            
        # Ligne d'ent�te
        #if dictParametres["ligne_noms_champs"] == True and (not format in ["compta_matt_fixe","compta_matt_delimite",]):
        if dictParametres["ligne_noms_champs"] == True :
            listeLignesTxt.append(self.EnteteLigne(format))

        # Ventes
        if dictParametres["export_ventes"] == True :
            if dictParametres["option_ventes"] == 0 :
                lignesVentes = fDon.GetPieces()
            if dictParametres["option_ventes"] == 1 :
                lignesVentes = fDon.GetPrestations(datePrestPourConsos=True)
            if lignesVentes != False :
                for ID,ligne in sorted(lignesVentes) :
                    if ligne["montant"] != FloatToDecimal(0.0) :
                        listeLignesTxt.append(self.FormateLigne(format, ligne, dictParametres, numLigne))
                        numLigne += 1
                lignesVtes = fDon.GetPrestations(datePrestPourConsos = False)
                if lignesVtes != False:
                    for ID,ligne in sorted(lignesVtes) :
                        if ligne["montant"] != FloatToDecimal(0.0) :
                            listeLignesTxt.append(self.FormateLigne(format, ligne, dictParametres, numLigne))
                            numLigne += 1
        # Banque
        if dictParametres["export_reglements"] == True :
            if dictParametres["option_reglements"] != 0 :
                lignesBanques = fDon.GetReglements_OD()
                if len(lignesBanques) >0 :
                    for ID,ligne in sorted(lignesBanques) :
                        if ligne["montant"] != FloatToDecimal(0.0) :
                            listeLignesTxt.append(self.FormateLigne(format, ligne, dictParametres, numLigne))
                            numLigne += 1
            else:
                lignesBanques = fDon.GetReglements_Depots()
                if len(lignesBanques) >0 :
                    for ID,ligne in sorted(lignesBanques) :
                        if ligne["montant"] != FloatToDecimal(0.0) :
                            listeLignesTxt.append(self.FormateLigne(format, ligne, dictParametres, numLigne))
                            numLigne += 1
        del dlgAttente

        # Finalisation du texte
        if numLigne == 1:
            dlg = wx.MessageDialog(self, _(u"Aucune ligne ne correspond � cette selection !"), _(u"Information"), wx.OK | wx.ICON_EXCLAMATION)
            dlg.ShowModal()
            dlg.Destroy()
        else:
            texte = "\n".join(listeLignesTxt)
            fin = chr(10)+chr(26)
            nomFichier = _(u"Noethys")
            self.CreationFichier(nomFichier=nomFichier, texte=texte + fin, iso=iso)
    
    def EnteteLigne(self, format):
        if format == "compta_matt_delimite" :
            return Export_compta_matt_delimite(None)
        if format == "compta_matt_fixe" :
            return XImportLine(None,None).entete
        if format == "compta_ebp" :
            return Export_compta_EBP(None,None)

    def FormateLigne(self, format, ligne, dictParametres, numLigne):
        montant = ligne["montant"]
        sens = ligne["sens"]
        ligne["montant"], ligne["sens"] = GetSens(montant, sens )

        if format == "compta_matt_delimite" :
            return Export_compta_matt_delimite(ligne)
        if format == "compta_matt_fixe" :
            return XImportLine(ligne, numLigne).getData()
        if format == "compta_ebp" :
            return Export_compta_EBP(ligne, numLigne)

# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class Dialog(wx.Dialog):
    def __init__(self, parent):
        wx.Dialog.__init__(self, parent, -1, style=wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER|wx.MAXIMIZE_BOX|wx.MINIMIZE_BOX)
        self.parent = parent
        self.DB = aGestionDB.DB()
        dateDebut = self.DB.GetParam(param="DebutCompta",type="date",user = "Any")
        if dateDebut == None:
            #fixation d'une date de Migration
            dateDebut = str(datetime.date(datetime.date.today().year,01,01))
            self.DB.SetParam(param="DebutCompta", value=dateDebut, type="date", user = "Any", unique= True)
        dateFin = DateDDenEng(datetime.date.today())
        self.DB.SetParam(param="FinCompta", value=dateFin, type="date", user = "Any", unique = True)

        # Bandeau
        intro = _(u"S�lectionnez les dates de la p�riode � exporter, choisissez le format d'export correspondant � votre logiciel de compatibilit� puis renseignez les param�tres n�cessaires avant cliquer sur G�n�rer. Vous obtiendrez un fichier qu'il vous suffira d'importer depuis votre logiciel de comptabilit�.")
        titre = _(u"aDLG_Export_compta : Export des �critures comptables")
        self.SetTitle(titre)
        self.ctrl_bandeau = CTRL_Bandeau.Bandeau(self, titre=titre, texte=intro, hauteurHtml=30, nomImage="Images/22x22/Smiley_nul.png")
        
        # P�riode
        self.box_periode_staticbox = wx.StaticBox(self, wx.ID_ANY, _(u"P�riode"))
        self.label_date_debut = wx.StaticText(self, wx.ID_ANY, u"Du")
        self.ctrl_date_debut = CTRL_Saisie_date.Date2(self)
        self.label_date_fin = wx.StaticText(self, wx.ID_ANY, _(u"au"))
        self.ctrl_date_fin = CTRL_Saisie_date.Date2(self)
        self.ctrl_date_debut.SetDate(dateDebut)
        self.ctrl_date_fin.SetDate(str(dateFin))

        # Logiciel de sortie
        self.box_logiciel_staticbox = wx.StaticBox(self, -1, _(u"Format d'export"))
        self.ctrl_logiciel = CTRL_Logiciel(self)

        # Param�tres
        self.box_parametres_staticbox = wx.StaticBox(self, wx.ID_ANY, _(u"Param�tres"))
        self.ctrl_parametres = CTRL_Parametres_defaut(self)
        
        self.bouton_reinitialisation = CTRL_Propertygrid.Bouton_reinitialisation(self, self.ctrl_parametres)
        self.bouton_sauvegarde = CTRL_Propertygrid.Bouton_sauvegarde(self, self.ctrl_parametres)

        # Boutons
        self.bouton_aide = CTRL_Bouton_image.CTRL(self, texte=_(u"Aide"), cheminImage="Images/32x32/Aide.png")
        self.bouton_ok = CTRL_Bouton_image.CTRL(self, texte=_(u"G�n�rer le fichier"), cheminImage="Images/32x32/Disk.png")
        self.bouton_recap = CTRL_Bouton_image.CTRL(self, texte=_(u"R�cap des transferts"), cheminImage="Images/32x32/Facture.png")
        self.bouton_fermer = CTRL_Bouton_image.CTRL(self, texte=_(u"Fermer"), cheminImage="Images/32x32/Fermer.png")

        self.__set_properties()
        self.__do_layout()

        self.Bind(wx.EVT_BUTTON, self.OnBoutonAide, self.bouton_aide)
        self.Bind(wx.EVT_BUTTON, self.OnBoutonOk, self.bouton_ok)
        self.Bind(wx.EVT_BUTTON, self.OnBoutonRecap, self.bouton_recap)
        self.Bind(wx.EVT_BUTTON, self.OnBoutonFermer, self.bouton_fermer)
        self.Bind(wx.EVT_CLOSE, self.OnBoutonFermer)
        
        wx.CallAfter(self.ctrl_date_debut.SetFocus)

    def __set_properties(self):
        self.ctrl_date_debut.SetToolTip(wx.ToolTip(_(u"Saisissez la date de d�but de la p�riode � exporter")))
        self.ctrl_date_fin.SetToolTip(wx.ToolTip(_(u"Saisissez la date de fin de la p�riode � exporter")))
        self.bouton_aide.SetToolTip(wx.ToolTip(_(u"Cliquez ici pour obtenir de l'aide")))
        self.bouton_ok.SetToolTip(wx.ToolTip(_(u"Cliquez ici pour lancer la g�n�ration des fichiers d'exportation")))
        self.bouton_recap.SetToolTip(wx.ToolTip(_(u"Cliquez ici pour un r�capitulatif des exportations")))
        self.bouton_fermer.SetToolTip(wx.ToolTip(_(u"Cliquez ici pour fermer")))
        self.SetMinSize((700, 680))

    def __do_layout(self):
        grid_sizer_base = wx.FlexGridSizer(4, 1, 10, 10)
        
        grid_sizer_haut = wx.FlexGridSizer(1, 2, 10, 10)
        
        box_periode = wx.StaticBoxSizer(self.box_periode_staticbox, wx.VERTICAL)
        grid_sizer_periode = wx.FlexGridSizer(2, 2, 5, 5)
        grid_sizer_base.Add(self.ctrl_bandeau, 0, wx.EXPAND, 0)
        grid_sizer_periode.Add(self.label_date_debut, 0, wx.ALIGN_CENTER_HORIZONTAL | wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_periode.Add(self.ctrl_date_debut, 0, 0, 0)
        grid_sizer_periode.Add(self.label_date_fin, 0, wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_periode.Add(self.ctrl_date_fin, 0, 0, 0)
        box_periode.Add(grid_sizer_periode, 1, wx.ALL|wx.EXPAND, 10)
        grid_sizer_haut.Add(box_periode, 1, wx.EXPAND, 10)
        
        box_logiciel = wx.StaticBoxSizer(self.box_logiciel_staticbox, wx.VERTICAL)
        grid_sizer_logiciel = wx.FlexGridSizer(1, 2, 5, 5)
        grid_sizer_logiciel.Add(self.ctrl_logiciel, 0, wx.EXPAND, 0)
        grid_sizer_logiciel.AddGrowableCol(0)
        box_logiciel.Add(grid_sizer_logiciel, 1, wx.ALL|wx.EXPAND, 10)
        grid_sizer_haut.Add(box_logiciel, 1, wx.EXPAND, 10)
        
        grid_sizer_haut.AddGrowableCol(1)
        grid_sizer_base.Add(grid_sizer_haut, 1, wx.LEFT | wx.RIGHT | wx.EXPAND, 10)
        
        box_parametres = wx.StaticBoxSizer(self.box_parametres_staticbox, wx.VERTICAL)
        grid_sizer_parametres = wx.FlexGridSizer(1, 2, 5, 5)
        grid_sizer_parametres.Add(self.ctrl_parametres, 1, wx.ALL | wx.EXPAND, 0) 

        grid_sizer_parametres_boutons = wx.FlexGridSizer(5, 1, 5, 5)
        grid_sizer_parametres_boutons.Add(self.bouton_reinitialisation, 1, wx.ALL | wx.EXPAND, 0) 
        grid_sizer_parametres_boutons.Add(self.bouton_sauvegarde, 1, wx.ALL | wx.EXPAND, 0) 
        grid_sizer_parametres.Add(grid_sizer_parametres_boutons, 1, wx.ALL | wx.EXPAND, 0) 
        
        grid_sizer_parametres.AddGrowableRow(0)
        grid_sizer_parametres.AddGrowableCol(0)
        box_parametres.Add(grid_sizer_parametres, 1, wx.ALL | wx.EXPAND, 10) 
        grid_sizer_base.Add(box_parametres, 1, wx.LEFT | wx.RIGHT | wx.EXPAND, 10)
        
        grid_sizer_boutons = wx.FlexGridSizer(1, 5, 10, 10)
        grid_sizer_boutons.Add(self.bouton_aide, 0, 0, 0)
        grid_sizer_boutons.Add((20, 20), 0, wx.EXPAND, 0)
        grid_sizer_boutons.Add(self.bouton_ok, 0, 0, 0)
        grid_sizer_boutons.Add(self.bouton_recap, 0, 0, 0)
        grid_sizer_boutons.Add(self.bouton_fermer, 0, 0, 0)
        grid_sizer_boutons.AddGrowableCol(1)
        grid_sizer_base.Add(grid_sizer_boutons, 1, wx.LEFT | wx.RIGHT | wx.BOTTOM | wx.EXPAND, 10)
        self.SetSizer(grid_sizer_base)
        grid_sizer_base.Fit(self)
        grid_sizer_base.AddGrowableRow(2)
        grid_sizer_base.AddGrowableCol(0)
        self.Layout()
        self.CenterOnScreen() 

    def OnBoutonAide(self, event):  
        import UTILS_Aide
        UTILS_Aide.Aide("")

    def OnBoutonFermer(self, event): 
        if self.ctrl_parametres.GetPropertyByName("memoriser_parametres").GetValue() == True :
            self.ctrl_parametres.Sauvegarde()
        dateDebut = self.ctrl_date_debut.GetDate()
        self.DB.SetParam(param="DebutCompta", value=dateDebut, type="date", user = "Any", unique = True)
        dateFin = self.ctrl_date_fin.GetDate()
        self.DB.SetParam(param="FinCompta", value=dateFin, type="date", user = "Any", unique = True)
        self.EndModal(wx.ID_CANCEL)

    def OnBoutonOk(self, event): 
        format = self.ctrl_logiciel.GetCode()
        self.ctrl_parametres.Generation(format)

    def OnBoutonRecap(self, event):
        import aDLG_Liste_transferts
        dateFin = self.ctrl_date_fin.GetDate()
        dlg = aDLG_Liste_transferts.Dialog(self,dateFin = dateFin)
        dlg.ShowModal()


# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class CTRL_Codes(wxpg.PropertyGrid) :
    def __init__(self, parent, dictCodes=None, keyStr=False):
        wxpg.PropertyGrid.__init__(self, parent, -1, style=wxpg.PG_SPLITTER_AUTO_CENTER )
        self.parent = parent
        self.dictCodes = dictCodes
        self.keyStr = keyStr
        self.SetExtraStyle(wxpg.PG_EX_HELP_AS_TOOLTIPS)
        couleurFond = "#e5ecf3"
        self.SetCaptionBackgroundColour(couleurFond)
        self.SetMarginColour(couleurFond)
        
        # Remplissage des valeurs
        if keyStr == True :
            listeIntitules = dictCodes.keys() 
            listeIntitules.sort() 
            for intitule in listeIntitules :
                valeur = dictCodes[intitule]["code_compta"]
                if valeur == None : valeur = ""
                propriete = wxpg.StringProperty(label=intitule, name=intitule, value=valeur)
                self.Append(propriete)
        else :
            for ID, dictValeurs in dictCodes.iteritems() :
                valeur = dictValeurs["code_compta"]
                if valeur == None : valeur = ""
                if dictValeurs.has_key("label") : intitule = dictValeurs["label"]
                if dictValeurs.has_key("intitule") : intitule = dictValeurs["intitule"]
                propriete = wxpg.StringProperty(label=intitule, name=str(ID), value=valeur)
                self.Append(propriete)
                

    def Validation(self):
        for label, valeur in self.GetPropertyValues().iteritems() :
            if valeur == "" :
                if self.keyStr == False :
                    ID = int(label)
                    if self.dictCodes[ID].has_key("label") : label = self.dictCodes[ID]["label"]
                    if self.dictCodes[ID].has_key("intitule") : label = self.dictCodes[ID]["intitule"]
                dlg = wx.MessageDialog(None, _(u"Vous n'avez pas renseign� le code comptable de la ligne '%s'.\n\nSouhaitez-vous tout de m�me continuer ? (Si oui, cette ligne ne sera pas export�e)") % label, _(u"Information manquante"), wx.YES_NO|wx.YES_DEFAULT|wx.ICON_EXCLAMATION)
                reponse = dlg.ShowModal()
                dlg.Destroy()
                if reponse == wx.ID_NO:
                    return False

        return True

    def GetCodes(self):
        dictCodes = self.GetPropertyValues()
        return dictCodes

class Dialog_codes(wx.Dialog):
    def __init__(self, parent, dictCodes=None, keyStr=False, titre=_(u"V�rification des codes comptables")):
        wx.Dialog.__init__(self, parent, -1, style=wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER|wx.MAXIMIZE_BOX|wx.MINIMIZE_BOX)
        self.parent = parent
        self.dictCodes = dictCodes
        
        self.label_intro = wx.StaticText(self, wx.ID_ANY, _(u"Veuillez v�rifier ci-dessous que les codes comptables attribu�s sont exacts. \nLaissez la ligne vide si vous souhaitez exclure celle-ci de l'export."))
        self.ctrl_codes = CTRL_Codes(self, dictCodes=dictCodes, keyStr=keyStr)
        self.bouton_ok = CTRL_Bouton_image.CTRL(self, texte=_(u"Ok"), cheminImage="Images/32x32/Valider.png")
        self.bouton_fermer = CTRL_Bouton_image.CTRL(self, texte=_(u"Annuler"), cheminImage="Images/32x32/Annuler.png")
        
        # Propri�t�s
        self.bouton_ok.SetToolTip(wx.ToolTip(_(u"Cliquez ici pour valider")))
        self.bouton_fermer.SetToolTip(wx.ToolTip(_(u"Cliquez ici pour fermer")))
        self.SetMinSize((590, 600))
        self.SetTitle(titre)
        
        # Affichage
        grid_sizer_base = wx.FlexGridSizer(4, 1, 10, 10)
        
        grid_sizer_base.Add(self.label_intro, 1, wx.LEFT | wx.RIGHT | wx.TOP | wx.EXPAND, 10)
        grid_sizer_base.Add(self.ctrl_codes, 1, wx.LEFT | wx.RIGHT | wx.EXPAND, 10)
        
        grid_sizer_boutons = wx.FlexGridSizer(1, 4, 10, 10)
        grid_sizer_boutons.Add((20, 20), 0, wx.EXPAND, 0)
        grid_sizer_boutons.Add(self.bouton_ok, 0, 0, 0)
        grid_sizer_boutons.Add(self.bouton_fermer, 0, 0, 0)
        grid_sizer_boutons.AddGrowableCol(0)
        grid_sizer_base.Add(grid_sizer_boutons, 1, wx.LEFT | wx.RIGHT | wx.BOTTOM | wx.EXPAND, 10)
        
        self.SetSizer(grid_sizer_base)
        grid_sizer_base.Fit(self)
        grid_sizer_base.AddGrowableRow(1)
        grid_sizer_base.AddGrowableCol(0)
        self.Layout()
        self.CenterOnScreen() 

        # Binds
        self.Bind(wx.EVT_BUTTON, self.OnBoutonOk, self.bouton_ok)
        self.Bind(wx.EVT_BUTTON, self.OnBoutonFermer, self.bouton_fermer)

    def OnBoutonFermer(self, event): 
        self.EndModal(wx.ID_CANCEL)

    def OnBoutonOk(self, event): 
        if self.ctrl_codes.Validation() == False :
            return False
        self.EndModal(wx.ID_OK)
        
    def GetCodes(self):
        return self.ctrl_codes.GetCodes() 

if __name__ == u"__main__":
    app = wx.App(0)
    dlg = Dialog(None)
    app.SetTopWindow(dlg)
    dlg.ShowModal()
    app.MainLoop()

