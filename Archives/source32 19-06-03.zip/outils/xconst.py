#!/usr/bin/python3
# -*- coding: utf-8 -*-

#  Jacques Brunel x Sébastien Gouast x Ivan Lucas
#  MATTHANIA - Projet XPY - xconst.py (constantes)
#  2019/04/18

SYMBOLE = "€"