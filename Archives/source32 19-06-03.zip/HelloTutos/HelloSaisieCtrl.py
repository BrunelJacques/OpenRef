# !/usr/bin/env python
# -*- coding: utf-8 -*-

#----------------------------------------------------------------------------
# Application :    Projet XPY, Panel contenant des objets de saisie et ctrl
# Auteurs:          Jacques BRUNEL
# Copyright:       (c) 2019-04     Cerfrance Provence, Matthania
# Licence:         Licence GNU GPL
#----------------------------------------------------------------------------

import wx
import os

class PNL_bool(wx.Panel):
    # GetValue retourne la valeur choisie dans le texte avec action possible par bouton à droite
    def __init__(self, *args, genre="", label="", value="", help=None, btnLabel=None, btnHelp=None, **kwds):
        wx.Panel.__init__(self,*args, **kwds)

        if btnLabel :
            self.avecBouton = True
        else: self.avecBouton = False

        self.MaxSize = (2000, 35)
        self.txt = wx.StaticText(self, -1, label + " :")
        self.txt.MinSize = (150, 65)
        self.check = wx.CheckBox(self, -1)
        if help:
            self.check.SetToolTip(help)
            self.check.SetToolTip(help)
        if self.avecBouton:
            self.btn = wx.Button(self, -1, btnLabel, size=(30, 20))
            if btnHelp:
                self.btn.SetToolTip(btnHelp)
        self.BoxSizer()
        self.check.SetValue(value)

    def BoxSizer(self):
        topbox = wx.BoxSizer(wx.HORIZONTAL)
        topbox.Add(self.txt,0, wx.LEFT|wx.TOP|wx.ALIGN_TOP, 4)
        topbox.Add(self.check, 1, wx.ALL | wx.EXPAND, 4)
        if self.avecBouton:
            topbox.Add(self.btn, 0, wx.ALL|wx.EXPAND, 4)
        self.SetSizer(topbox)

    def GetValue(self):
        return self.check.GetValue()

class PNL_texte(wx.Panel):
    # GetValue retourne la valeur choisie dans le texte avec action possible par bouton à droite
    def __init__(self, parent, *args, label="", valeur="", help=None, btnLabel=None, btnHelp=None, **kwds):
        wx.Panel.__init__(self,parent,*args, **kwds)
        if btnLabel :
            self.avecBouton = True
        else: self.avecBouton = False

        self.MaxSize = (2000, 35)
        self.txt = wx.StaticText(self, -1, label + " :")
        self.txt.MinSize = (150, 65)
        self.texte = wx.TextCtrl(self, -1)
        if help:
            self.texte.SetToolTip(help)
            self.txt.SetToolTip(help)
        if self.avecBouton:
            self.btn = wx.Button(self, -1, btnLabel, size=(30, 20))
            if btnHelp:
                self.btn.SetToolTip(btnHelp)
        self.BoxSizer()
        self.texte.SetValue(valeur)

    def BoxSizer(self):
        topbox = wx.BoxSizer(wx.HORIZONTAL)
        topbox.Add(self.txt,0, wx.LEFT|wx.TOP|wx.ALIGN_TOP, 4)
        topbox.Add(self.texte, 1, wx.ALL | wx.EXPAND, 4)
        if self.avecBouton:
            topbox.Add(self.btn, 0, wx.ALL|wx.EXPAND, 4)
        self.SetSizer(topbox)

    def GetValue(self):
        return self.texte.GetValue()

class PNL_combo(wx.Panel):
    # GetValue retourne la valeur choisie dans le combo avec action possible sur bouton à droite
    def __init__(self, parent, *args,label="", valeurs=[], help=None, btnLabel=None, btnHelp=None, **kwds):
        wx.Panel.__init__(self,parent,*args, **kwds)
        if btnLabel :
            self.avecBouton = True
        else: self.avecBouton = False

        self.MaxSize = (2000, 35)
        self.txt = wx.StaticText(self, -1, label + " :")
        self.txt.MinSize = (150, 65)
        self.combo = wx.ComboBox(self, -1)
        if help:
            self.combo.SetToolTip(help)
            self.txt.SetToolTip(help)
        if self.avecBouton:
            self.btn = wx.Button(self, -1, btnLabel, size=(30, 20))
            if btnHelp:
                self.btn.SetToolTip(btnHelp)
        self.BoxSizer()
        self.combo.Set(valeurs)
        self.combo.SetSelection (0)

    def BoxSizer(self):
        topbox = wx.BoxSizer(wx.HORIZONTAL)
        topbox.Add(self.txt,0, wx.LEFT|wx.TOP|wx.ALIGN_TOP, 4)
        topbox.Add(self.combo, 1, wx.ALL | wx.ALIGN_TOP, 4)
        if self.avecBouton:
            topbox.Add(self.btn, 0, wx.ALL|wx.EXPAND, 4)
        self.SetSizer(topbox)

    def GetValue(self):
        return self.combo.GetValue()

#************************   Pour Test  ou modèle  *******************************
class Frame(wx.Frame):
    def __init__(self, *args, **kwds):
        listArbo=os.path.abspath(__file__).split("\\")
        titre = listArbo[-1:][0] + "/" + self.__class__.__name__
        wx.Frame.__init__(self,*args, title=titre, **kwds)
        self.Size = (600,400)
        self.combo1 = PNL_combo(self,-1,
                            label="Le nom du choix PEUT être long ",
                            valeurs=["ceci est parfois plus long, plus long qu'un autre", 'cela', 'ou un autre', 'la vie est faite de choix'],
                            help="Je vais vous expliquer",
                            btnLabel=" ! ",
                            btnHelp="Là vous pouvez lancer une action par clic")

        self.combo2 = PNL_combo(self,-1,label="Le nom2",valeurs=['ceci', 'cela', 'ou un autre', 'la vie LOong fleuve tranquile'],help="Je vais vous expliquer",btnLabel="...", btnHelp="Là vous pouvez lancer une action de gestion des choix possibles")
        self.combo3 = PNL_combo(self,-1,label="Le nom3 plus long",valeurs=['ceci sans bouton', 'cela', 'ou un autre', 'la vie EST COURTE'], btnHelp="Là vous pouvez lancer une action telle que la gestion des choix possibles")
        self.texte1 = PNL_texte(self,-1,label="Un texte à saisir",valeur='monchoix', help="Je vais vous expliquer",)
        self.texte2 = PNL_texte(self,-1,label="Avec bouton de ctrl",valeur='monchoix étendu', help="Je vais vous expliquer", btnLabel="Ctrl", btnHelp="Là vous pouvez lancer une action de validation")

        self.combo1.btn.Bind(wx.EVT_BUTTON,self.OnBoutonActionCombo1)
        self.combo2.btn.Bind(wx.EVT_BUTTON,self.OnBoutonActionCombo2)
        self.texte2.btn.Bind(wx.EVT_BUTTON,self.OnBoutonActionTexte2)

        marge = 10
        sizer_1 = wx.BoxSizer(wx.VERTICAL)
        sizer_1.Add((10,10), 0, wx.LEFT|wx.ALIGN_TOP,marge)
        sizer_1.Add(self.combo1, 1, wx.LEFT|wx.ALIGN_TOP,marge)
        sizer_1.Add(self.combo2, 1, wx.LEFT|wx.ALIGN_TOP,marge)
        sizer_1.Add(self.texte1, 1, wx.LEFT|wx.ALIGN_TOP,marge)
        sizer_1.Add(self.combo3, 1, wx.LEFT|wx.ALIGN_TOP,marge)
        sizer_1.Add(self.texte2, 1, wx.LEFT|wx.ALIGN_TOP,marge)
        self.SetBackgroundColour(wx.WHITE)
        self.SetSizer(sizer_1)
        self.Layout()
        self.CentreOnScreen()

    def OnBoutonActionCombo1(self, event):
        #Bouton Test
        print("Bonjour l'action OnBoutonActionCombo1 de l'appli")
        self.combo1.btn.SetLabel("Clic")

    def OnBoutonActionCombo2(self, event):
        #Bouton Test
        print("Bonjour l'action OnBoutonActionCombo2 de l'appli")
        self.combo2.combo.Set(["Crack","boum","hue"])
        self.combo2.combo.SetSelection (0)

    def OnBoutonActionTexte2(self, event):
        #Bouton Test
        print("Bonjour l'action OnBoutonActionCombo2 de l'appli")
        wx.MessageBox("Houston nous avons un problème!",style=wx.OK)
        self.texte2.texte.SetValue("corrigez")

if __name__ == '__main__':
    app = wx.App(0)
    frame_1 = Frame(None,)
    app.SetTopWindow(frame_1)
    frame_1.Show()
    app.MainLoop()
