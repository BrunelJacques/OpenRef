# !/usr/bin/env python
# -*- coding: utf-8 -*-

#----------------------------------------------------------------------------
# Application :    Projet XPY, gestion des saisies de paramètres
# Auteurs:          Jacques BRUNEL, d'après Yvan LUCAS Noethys
# Copyright:       (c) 2019-04     Cerfrance Provence, Matthania
# Licence:         Licence GNU GPL
#----------------------------------------------------------------------------

import wx
import os
import wx.propgrid as wxpg

MATRICE_IDENT = {
    ("ident","Votre session"):
    [
        {'genre': 'String', 'name': 'domaine', 'label': 'Votre organisation', 'value': "NomDuPC",
         'help': 'Ce préfixe à votre nom permet de vous identifier'},
        {'genre': 'String', 'name': 'utilisateur', 'label': 'Votre identifiant', 'value': "NomSession",
         'help': 'Confirmez le nom de sesssion de l\'utilisateur'},
    ],
}
MATRICE_CHOIX_CONFIG = {
    ("choix_config","Choisissez votre configuration"):
    [
        {'genre': 'Enum', 'name': 'config', 'label': 'Configuration active',
        'help': "Le bouton de droite vous permet de créer une nouvelle configuration",
        'btnLabel':"...", 'btnHelp':"Cliquez pour gérer les configurations",
        'btnAction' : 'OnBtnChoixConfig'
        },
    ]
}
MATRICE_CONFIG = {
    ("bd_reseau","Base de donnée réseau"): [
        {'genre': 'Bool', 'name': 'bdReseau', 'label': 'Faut-il se connecter sur une base de données réseau', 'value': True,
         'help': "Il faudra connaître les identifiants d'accès à cette base"},
        {'genre': 'String', 'name': 'serveur', 'label': 'Nom du serveur', 'value': '',
         'help': "Il s'agit du serveur de réseau porteur de la base de données"},
    ]
}

def AppelMatrice(code=None, possibles={}):
    # retourne la matrice du code demandé
    label = ''
    matrice = {}
    if possibles:
        for nomCategorie, labelCategorie in possibles:
            if isinstance(nomCategorie, str):
                if code:
                    if code == nomCategorie:
                        label = labelCategorie
                        matrice = possibles[(nomCategorie, labelCategorie)]
                else:
                    label = labelCategorie, possibles
                    matrice = possibles[(nomCategorie, labelCategorie)]
                    break
    return label, matrice

#**********************************************************************************
#                   GESTION PAR UN SEUL CONTROLE  : GRILLE PROPERTY
#**********************************************************************************
class BTN_reinitialisation(wx.BitmapButton):
    # à parfaire
    def __init__(self, parent, ctrl_parametres=None):
        wx.BitmapButton.__init__(self, parent, -1, wx.Bitmap("xpy/Images/16x16/Actualiser.png", wx.BITMAP_TYPE_ANY))
        self.ctrl_parametres = ctrl_parametres
        self.SetToolTip(("Cliquez ici pour réinitialiser tous les paramètres"))
        self.Bind(wx.EVT_BUTTON, self.OnBouton)
    def OnBouton(self, event):
        self.ctrl_parametres.Reinitialisation()

class BTN_sauvegarde(wx.BitmapButton):
    # à parfaire
    def __init__(self, parent, ctrl_parametres=None):
        wx.BitmapButton.__init__(self, parent, -1, wx.Bitmap("xpy/Images/16x16/Sauvegarder.png", wx.BITMAP_TYPE_ANY))
        self.ctrl_parametres = ctrl_parametres
        self.SetToolTip(("Cliquez ici pour mémoriser tous les paramètres"))
        self.Bind(wx.EVT_BUTTON, parent.OnSauvegarde)

class BTN_fermer(wx.BitmapButton):
    # à parfaire
    def __init__(self, parent, ctrl_parametres=None):
        wx.BitmapButton.__init__(self, parent, -1, wx.Bitmap("xpy/Images/100x30/Bouton_ok.png", wx.BITMAP_TYPE_ANY))
        self.ctrl_parametres = ctrl_parametres
        self.SetToolTip(("Cliquez ici pour enregistrer et fermer la fenêtre"))
        self.Bind(wx.EVT_BUTTON, parent.OnAction)

class CTRL_property(wxpg.PropertyGrid):
    # grille property affiche les paramètres gérés par PNL_property
    def __init__(self, parent, matrice={}, valeursDefaut={}, enable=True, style=wxpg.PG_SPLITTER_AUTO_CENTER):
        wxpg.PropertyGrid.__init__(self, parent, -1, style=style)
        self.parent = parent
        self.dictValeursDefaut = valeursDefaut
        self.Bind(wxpg.EVT_PG_CHANGED, self.OnPropGridChange)
        if not enable:
            self.Enable(False)
            couleurFond = wx.LIGHT_GREY
            self.SetCaptionBackgroundColour(couleurFond)
            self.SetCellBackgroundColour(couleurFond)
            self.SetMarginColour(couleurFond)
            self.SetEmptySpaceColour(couleurFond)

        # Remplissage de la matrice
        self.InitMatrice(matrice)

        # Remplissage des valeurs
        self.SetValeurs(self.dictValeursDefaut)

    def OnPropGridChange(self, event):
        event.Skip()

    def InitMatrice(self, matrice={}):
        # Compose la grille de saisie des paramètres selon le dictionnaire matrice
        for (code, chapitre) in matrice:
            # Chapitre
            if isinstance(chapitre, str):
                self.Append(wxpg.PropertyCategory(chapitre))

                for ligne in matrice[(code, chapitre)]:
                    if 'genre' in ligne:
                        if ligne['genre'] == 'Enum':
                            propriete = wxpg.EnumProperty(label=ligne['label'], name=ligne['name'],
                                                          labels=ligne['labels'], values=ligne['values'],
                                                          value=ligne['value'])
                        elif ligne['genre'] == 'MultiChoice':
                            propriete = wxpg.MultiChoiceProperty(label=ligne['label'], name=ligne['name'],
                                                                 choices=ligne['labels'], value=ligne['value'])
                        else:
                            commande = "wxpg." + ligne[
                                'genre'] + "Property(label= ligne['label'], name=ligne['name'], value=ligne['value'])"
                            propriete = eval(commande)
                        if 'help' in ligne:
                            propriete.SetHelpString(ligne['help'])
                        self.Append(propriete)

    def Reinitialisation(self):
        dlg = wx.MessageDialog(None, ("Souhaitez-vous vraiment réinitialiser tous les paramètres ?"),
                               ("Paramètres par défaut"), wx.YES_NO | wx.NO_DEFAULT | wx.CANCEL | wx.ICON_QUESTION)
        reponse = dlg.ShowModal()
        dlg.Destroy()
        if reponse == wx.ID_YES:
            self.SetValeurs(self.dictValeursDefaut)

    def SetValeurs(self, valeurs={}):
        # Alimente les valeurs dans la grille
        for nom, valeur in valeurs.items():
            propriete = self.GetPropertyByName(nom)
            if propriete:
                propriete.SetValue(valeur)

    def GetValeurs(self):
        return self.GetPropertyValues()

class PNL_property(wx.Panel):
    #affichage d'une grille de paramètres avec boutons classiques
    def __init__(self, parent, topWin, *args, title='', matrice={}, donnees={}, lblbox="Paramètres", **kwds):
        self.parent = parent
        wx.Panel.__init__(self, parent, *args, **kwds)
        self.ctrl = CTRL_property(self,matrice,donnees)
        self.bouton_action = BTN_sauvegarde(self, self.ctrl)
        self.bouton_reinit = BTN_reinitialisation(self, self.ctrl)
        cadre_staticbox = wx.StaticBox(self,-1,label=lblbox)
        topbox = wx.StaticBoxSizer(cadre_staticbox,wx.HORIZONTAL)
        topbox.Add(self.ctrl,1,wx.ALL|wx.EXPAND,4)
        droite_flex = wx.FlexGridSizer(2,1,0,0)
        droite_flex.Add(self.bouton_action, 0, wx.ALL|wx.TOP, 4)
        droite_flex.Add(self.bouton_reinit, 0, wx.ALL|wx.TOP, 4)
        topbox.Add(droite_flex,0,wx.ALL|wx.TOP,1)
        topbox.MinSize = (300,400)
        self.SetSizerAndFit(topbox)

    def OnSauvegarde(self, event):
        # Action du clic sur l'icone sauvegarde renvoie au parent
        if self.parent:
            self.parent.OnSauvegarde(event)
        else:
            print("Bonjour l'action sauvegarde du parent de PNL_property")

#**********************************************************************************
#                   GESTION par des  CONTROLES  composés dans des  PANELS
#**********************************************************************************

class PNL_ctrl(wx.Panel):
    # GetValue retourne la valeur choisie dans le ctrl avec action possible par bouton à droite
    def __init__(self, parent, *args,label=None, genre='string', name=None, value= None, labels=None, values=None,valeurs=[], help=None,
                 btnLabel=None, btnHelp=None, btnAction='', ctrlAction='', **kwds):
        wx.Panel.__init__(self,parent,*args, **kwds)
        self.value = value
        if btnLabel :
            self.avecBouton = True
        else: self.avecBouton = False

        self.MaxSize = (2000, 35)
        self.txt = wx.StaticText(self, -1, label + " :")
        self.txt.MinSize = (150, 65)

        if genre.lower() in ['enum', 'combo', 'multichoice']:
            self.ctrl = wx.ComboBox(self, -1)
            self.ctrl.Set(valeurs)
            self.ctrl.SetSelection(0)
        elif genre.lower() in ['bool', 'check']:
            self.ctrl = wx.CheckBox(self, -1)
            self.UseCheckbox = 1
        else:
            self.ctrl= wx.TextCtrl(self, -1)
        if help:
            self.ctrl.SetToolTip(help)
            self.txt.SetToolTip(help)
        if genre.lower() == 'dir':
            self.avecBouton = True
            if not btnLabel: btnLabel = '...'
            self.btn = wx.Button(self, -1, btnLabel, size=(30, 20))
            self.btn.Bind(wx.EVT_BUTTON, self.OnDir)
        elif self.avecBouton:
            self.btn = wx.Button(self, -1, btnLabel, size=(30, 20))
            if btnHelp:
                self.btn.SetToolTip(btnHelp)
        self.BoxSizer()

    def BoxSizer(self):
        topbox = wx.BoxSizer(wx.HORIZONTAL)
        topbox.Add(self.txt,0, wx.LEFT|wx.TOP|wx.ALIGN_TOP, 4)
        topbox.Add(self.ctrl, 1, wx.ALL | wx.EXPAND, 4)
        if self.avecBouton:
            topbox.Add(self.btn, 0, wx.ALL|wx.EXPAND, 4)
        self.SetSizer(topbox)

    def GetValue(self):
        return self.ctrl.GetValue()

    def SetValue(self,value):
        self.ctrl.SetValue(value)

    def SetValues(self,values):
        self.ctrl.Set(values)

    def OnDir(self,event):
        """ Open a file"""
        self.dirname = ''
        dlg = wx.DirDialog(self, "Choisissez un emplacement", self.dirname)
        if dlg.ShowModal() == wx.ID_OK:
            self.ctrl.SetValue(dlg.GetPath())
        dlg.Destroy()

class BoxPanel(wx.Panel):
    # aligne les contrôles définis dans la matrice dans une box
    def __init__(self, parent, *args, lblbox="Box", lignes=[], **kwds):
        wx.Panel.__init__(self,parent, *args, **kwds)
        self.parent = parent

        ssbox = wx.BoxSizer(wx.VERTICAL)
        for ligne in lignes:
            for nom,valeur in ligne.items():
               kwds[nom] = valeur
            if 'genre' in ligne:
                panel = PNL_ctrl(self, *args, **kwds)
                if ligne['genre'].lower() in ['bool', 'check']:
                    self.UseCheckbox = 1
                if panel:
                    for cle in ('name','label','ctrlAction','btnLabel','btnAction'):
                        if not cle in ligne:
                            ligne[cle]=None
                    ssbox.Add(panel,1,wx.ALL|wx.EXPAND,4)
                    panel.ctrl.genreCtrl = ligne['genre']
                    panel.ctrl.nameCtrl = ligne['name']
                    panel.ctrl.labelCtrl = ligne['label']
                    panel.ctrl.actionCtrl = ligne['ctrlAction']
                    if panel.avecBouton and ligne['genre'].lower() != 'dir' :
                        panel.btn.nameBtn = ligne['name']
                        panel.btn.labelBtn = ligne['btnLabel']
                        panel.btn.actionBtn = ligne['btnAction']
                        panel.btn.Bind(wx.EVT_BUTTON,self.parent.OnBouton)
                    panel.ctrl.Bind(wx.EVT_TEXT,self.parent.OnEnter)
                    panel.ctrl.Bind(wx.EVT_COMBOBOX, self.parent.OnEnter)
                    panel.ctrl.Bind(wx.EVT_CHECKBOX, self.parent.OnEnter)
        self.SetSizerAndFit(ssbox)

class TopPanel(wx.Panel):
    def __init__(self, parent, *args, matrice={}, donnees={}, lblbox="Paramètres", **kwds):
        wx.Panel.__init__(self,parent,*args, **kwds)
        self.parent = parent

        cadre_staticbox = wx.StaticBox(self,-1,label=lblbox)
        topbox = wx.StaticBoxSizer(cadre_staticbox,wx.HORIZONTAL)
        for nomCategorie, labelCategorie in matrice:
            if isinstance(nomCategorie,str):
                topbox.Add(BoxPanel(self, -1, lblbox=labelCategorie, lignes=matrice[(nomCategorie,labelCategorie)]), 1, wx.EXPAND,0)
        self.SetSizerAndFit(topbox)
    def OnEnter(self,event):
        self.parent.OnEnter(event)

    def OnBouton(self,event):
        self.parent.OnBouton(event)

class xFrame(wx.Frame):
    def __init__(self, *args, matrice={}, donnees={}, btnaction=None, lblbox="Paramètres", **kwds):
        listArbo=os.path.abspath(__file__).split("\\")
        titre = listArbo[-1:][0] + "/" + self.__class__.__name__
        wx.Frame.__init__(self,*args, title=titre, **kwds)
        self.topPnl = TopPanel(self,-1, matrice=matrice, donnees=donnees, lblbox=lblbox)
        self.btn0 = wx.Button(self, -1, "Action Frame")
        self.btn0.Bind(wx.EVT_BUTTON,self.OnBoutonAction)
        marge = 10
        sizer_1 = wx.BoxSizer(wx.VERTICAL)
        sizer_1.Add(self.topPnl, 0, wx.LEFT|wx.EXPAND,marge)
        sizer_1.Add(self.btn0, 0, wx.RIGHT|wx.ALIGN_TOP,marge)
        self.SetSizerAndFit(sizer_1)
        self.CentreOnScreen()

    def OnEnter(self,event):

        print('Bonjour Enter sur le ctrl : ',event.EventObject.Name)
        print(event.EventObject.genreCtrl, event.EventObject.nameCtrl, event.EventObject.labelCtrl,)
        print('Action prévue : ',event.EventObject.actionCtrl)

    def OnBouton(self,event):
        print('Vous avez cliqué sur le bouton')
        print(event.EventObject.Name)
        print( event.EventObject.nameBtn, event.EventObject.labelBtn,)
        print('vous avez donc souhaité : ',event.EventObject.actionBtn)

    def OnSauvegarde(self, event):
        #Bouton Test
        print("Bonjour l'action de sauvegarde dans la frame")

    def OnBoutonAction(self, event):
        #Bouton Test
        print("Bonjour l'action OnBoutonAction de l'appli")

#************************   Gestion de l'identification initiale *****************

class DLG_identification(wx.Dialog):
    # Ecran de saisie de paramètres en dialog
    def __init__(self, parent, *args, **kwds):
        listArbo=os.path.abspath(__file__).split("\\")
        titre = listArbo[-1:][0] + "/" + self.__class__.__name__
        wx.Dialog.__init__(self,*args, title=titre, **kwds)
        self.parent = parent

        cadre_staticbox = wx.StaticBox(self, -1, label='identification')
        topbox = wx.StaticBoxSizer(cadre_staticbox, wx.VERTICAL)

        def AffichID():
            #Affichage de l'identification
            self.ctrlID = CTRL_property(self, matrice=MATRICE_IDENT, enable=False)
            valeurs = {}
            valeurs['utilisateur'] = os.environ['USERNAME']
            valeurs['domaine'] = '----'
            try:
                valeurs['domaine'] = os.environ['USERDOMAIN']
            except:
                import platform
                valeurs['domaine'] = platform.node()
            self.ctrlID.SetValeurs(valeurs=valeurs)
            topbox.Add(self.ctrlID, 0,wx.ALL | wx.EXPAND, 5)
            label,matrice = AppelMatrice(None, MATRICE_CHOIX_CONFIG)
            topbox.Add((20,20), 0, wx.ALIGN_TOP, 0)
            topbox.Add(BoxPanel(self, -1, lblbox=label, lignes=matrice), 0, wx.ALIGN_TOP, 0)
            topbox.Add((40,40), 0, wx.ALIGN_TOP, 0)
        AffichID()
        self.SetSizerAndFit(topbox)

    def OnBouton(self,event):
        DLG_saisieConfig()

    def OnEnter(self,event):
        pass

class DLG_saisieConfig(wx.Dialog):
    # Ecran de saisie de paramètres en dialog
    def __init__(self, parent, *args, **kwds):
        listArbo=os.path.abspath(__file__).split("\\")
        titre = listArbo[-1:][0] + "/" + self.__class__.__name__
        wx.Dialog.__init__(self,*args, title=titre, **kwds)
        self.parent = parent

        cadre_staticbox = wx.StaticBox(self, -1, label='configuration')
        topbox = wx.StaticBoxSizer(cadre_staticbox, wx.VERTICAL)

        # seuls les paragraphes option  choisis par l'appli seront appelés.
        matrice = {}
        for option in self.parent.dictAPPLI['CONFIGS']:
            for code,chapitre in MATRICE_CONFIG:
                if option == code:
                    matrice[(code,chapitre)] = MATRICE_CONFIG[(code,chapitre)]
        if matrice != {}:
            self.SetBackgroundColour(wx.WHITE)
            self.pnl = PNL_property(self, *args, matrice=matrice, lblbox="Paramètres", **kwds)
            self.pnl.MinSize = (400,300)
            self.btn = BTN_fermer(self, self.pnl.ctrl)
            self.btn.Bind(wx.EVT_BUTTON, self.OnAction)

            sizer = wx.BoxSizer(wx.VERTICAL)
            sizer.Add(self.pnl, 1,wx.EXPAND | wx.ALL, 10)
            sizer.Add(self.btn, 0,  wx.ALIGN_RIGHT | wx.RIGHT,40)
            sizer.SetSizeHints(self)
            topbox.Add(sizer, 1, wx.EXPAND, 0)
        self.SetSizerAndFit(topbox)

    def OnBouton(self,event):
        pass
    def OnEnter(self,event):
        pass

    def OnAction(self, event):
            self.OnSauvegarde(None)
            self.Destroy()
    def OnSauvegarde(self, event):
            print("Bonjour Sauvegarde de Frame_config")

#************************   Pour Test ou modèle  *********************************
class FrameGrid(wx.Frame):
    def __init__(self, *args, matrice=None, **kwds):
        listArbo=os.path.abspath(__file__).split("\\")
        titre = listArbo[-1:][0] + "/" + self.__class__.__name__
        wx.Frame.__init__(self,*args, title=titre, **kwds)

        self.SetBackgroundColour(wx.WHITE)
        self.pnl = PNL_property(self, *args, matrice = matrice, **kwds )
        self.pnl.MinSize = (400,300)
        self.btn = wx.Button(self, -1, "action Test")
        self.btn.Bind(wx.EVT_BUTTON, self.OnAction)

        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.pnl, 1,wx.EXPAND | wx.ALL, 10)
        sizer.Add(self.btn, 0,  wx.ALIGN_RIGHT | wx.RIGHT,40)
        sizer.SetSizeHints(self)
        self.SetSizer(sizer)

    def OnAction(self, event):
            print("Bonjour l'Action de Frame_test")

    def OnSauvegarde(self, event):
            print("Bonjour Sauvegarde de Frame_test")

class FramePanels(wx.Frame):
    def __init__(self, *args, **kwds):
        # cette frame ne passe pas par des panels de présentation elle appelle directement les panels des controles
        listArbo=os.path.abspath(__file__).split("\\")
        titre = listArbo[-1:][0] + "/" + self.__class__.__name__
        wx.Frame.__init__(self,*args, title=titre, **kwds)
        self.Size = (600,400)
        self.combo1 = PNL_ctrl(self,-1,
                            genre="combo",
                            label="Le nom du choix PEUT être long ",
                            valeurs=["ceci est parfois plus long, plus long qu'un autre", 'cela', 'ou un autre', 'la vie est faite de choix'],
                            help="Je vais vous expliquer",
                            btnLabel=" ! ",
                            btnHelp="Là vous pouvez lancer une action par clic")

        self.combo2 = PNL_ctrl(self,-1,genre="combo",label="Le nom2",valeurs=['ceci', 'cela', 'ou un autre', 'la vie LOong fleuve tranquile'],help="Je vais vous expliquer",btnLabel="...", btnHelp="Là vous pouvez lancer une action de gestion des choix possibles")
        self.combo3 = PNL_ctrl(self,-1,genre="combo",label="Le nom3 plus long",value=['ceci sans bouton', 'cela', 'ou un autre', 'la vie EST COURTE'], btnHelp="Là vous pouvez lancer une action telle que la gestion des choix possibles")
        self.ctrl1 = PNL_ctrl(self,-1,genre="string",label="Un ctrl à saisir",value='monchoix', help="Je vais vous expliquer",)
        self.ctrl2 = PNL_ctrl(self,-1,genre="string",label="Avec bouton de ctrl",value='monchoix étendu', help="Je vais vous expliquer", btnLabel="Ctrl", btnHelp="Là vous pouvez lancer une action de validation")

        self.combo1.btn.Bind(wx.EVT_BUTTON,self.OnBoutonActionCombo1)
        self.combo2.btn.Bind(wx.EVT_BUTTON,self.OnBoutonActionCombo2)
        self.ctrl2.btn.Bind(wx.EVT_BUTTON,self.OnBoutonActionTexte2)

        marge = 10
        sizer_1 = wx.BoxSizer(wx.VERTICAL)
        sizer_1.Add((10,10), 0, wx.LEFT|wx.ALIGN_TOP,marge)
        sizer_1.Add(self.combo1, 1, wx.LEFT|wx.ALIGN_TOP,marge)
        sizer_1.Add(self.combo2, 1, wx.LEFT|wx.ALIGN_TOP,marge)
        sizer_1.Add(self.ctrl1, 1, wx.LEFT|wx.ALIGN_TOP,marge)
        sizer_1.Add(self.combo3, 1, wx.LEFT|wx.ALIGN_TOP,marge)
        sizer_1.Add(self.ctrl2, 1, wx.LEFT|wx.ALIGN_TOP,marge)
        self.SetBackgroundColour(wx.WHITE)
        self.SetSizer(sizer_1)
        self.Layout()
        self.CentreOnScreen()

    def OnBoutonActionCombo1(self, event):
        #Bouton Test
        print("Bonjour l'action OnBoutonActionCombo1 de l'appli")
        self.combo1.btn.SetLabel("Clic")

    def OnBoutonActionCombo2(self, event):
        #Bouton Test
        print("Bonjour l'action OnBoutonActionCombo2 de l'appli")
        self.combo2.ctrl.Set(["Crack","boum","hue"])
        self.combo2.ctrl.SetSelection (0)

    def OnBoutonActionTexte2(self, event):
        #Bouton Test
        print("Bonjour l'action OnBoutonActionCombo2 de l'appli")
        wx.MessageBox("Houston nous avons un problème!",style=wx.OK)
        self.ctrl2.ctrl.SetValue("corrigez")

if __name__ == '__main__':
    app = wx.App(0)
    os.chdir("..")
    dictActions = {'saisieNbre':"wx.MessageBox('Savez-vous ce que vous voulez?)",}
    dictDonnees = {'memoriser': 2, 'ouiNon': False, 'monTexte': "élève", 'choix': ["choix2", "choix3"]}
    dictMatrice = {**MATRICE_IDENT, **MATRICE_CHOIX_CONFIG, **MATRICE_CONFIG}
    frame_1 = xFrame(None, matrice=dictMatrice, donnees=dictDonnees)
    frame_1.Position = (50,50)
    frame_2 = FramePanels(None, )
    frame_2.Position = (500,300)
    app.SetTopWindow(frame_1)
    frame_3 = FrameGrid(None, matrice=MATRICE_CONFIG)
    app.SetTopWindow(frame_3)
    frame_3.Show()
    frame_2.Show()
    frame_1.Show()
    app.MainLoop()

