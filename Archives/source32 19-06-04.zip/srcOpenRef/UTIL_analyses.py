#!/usr/bin/env python
# -*- coding: utf8 -*-

#------------------------------------------------------------------------
# Application :    OpenRef, Génération des exports d'analyses
# Auteurs:          Jacques BRUNEL
# Copyright:       (c) 2019-05     Cerfrance Provence
# Licence:         Licence GNU GPL
#------------------------------------------------------------------------

import os
import wx
import datetime
import xpy.xUTILS_Config as xucfg
import xpy.xGestionDB as xdb

CHAMPS_TABLES = {
    '_Ident' : ['IDdossier','IDagc','IDexploitation','Clôture','IDuser','IDlocalisation','IDjuridique','NomExploitation',
                'IDCodePostal','Siren','IDnaf','Filières','NbreMois','Fiscal','ImpSoc','Caf','SubvReçues','Cessions',
                'NvxEmprunts','Apports','Investissements','RbtEmprunts','Prélèvements','RemAssociés','AnalyseProduction',
                'AnalyseFinances','Perspectives','SAUfermage','SAUmétayage','SAUfvd','SAUmad','SAU','NbreAssociés',
                'MOexploitants','MOpermanents','MOsaisonniers','NbElemCar','ElemCar','Analytique','Validé'],
    '_Infos' : ['IDdossier','IDMinfo','Numerique','Bool','Texte'],
    '_Balances':['IDdossier','Compte','IDligne','Libellé','Quantités1','Unité1','Quantités2','Unité2',
                 'SoldeDeb','DBmvt','CRmvt','SoldeFin','IDplanCompte','Analytique','Affecté'],
    'wVariables':[ 'Ordre','Code','Libelle','Fonction','Param','Atelier','Produit','Observation'],
    }

def ListsToDic(listecles, donnees, poscle=0):
    #le dictionnaire généré a pour clé les champs dans liste clé en minuscules
    dic = {}
    if isinstance(donnees[0],(tuple,list)):
        for serie in donnees:
            dic[serie[poscle]] = {}
            try:
                for ix in range(len(listecles)):
                    dic[serie[poscle]][listecles[ix].lower()] = serie[ix]
            except: continue
    else:
        try:
            for ix in range(len(listecles)):
                dic[listecles[ix].lower()] = donnees[ix]
        except: pass
    return dic


def PrechargeAnalyse(analyse, DBsql):
    lstChamps = CHAMPS_TABLES['wVariables']
    if analyse:
        req = """SELECT wVariables.*
                FROM wVariables INNER JOIN wAnalyses ON wVariables.Code = wAnalyses.Code
                WHERE (wAnalyses.IDanalyse= '%s');""" % analyse
    else:
        req = """SELECT * FROM wVariables;"""
    retour = DBsql.ExecuterReq(req, mess='accès OpenRef précharge wVariables')
    dic = {}
    if retour == "ok":
        recordset = DBsql.ResultatReq()
        dic = ListsToDic(lstChamps, recordset)
    return dic


class Analyse():
    def __init__(self,analyse=None, annee=None, client=None, groupe=None, filiere=None, gesttable=None):
        # vérifie ou crée la table xAnalyse_agc_nomanaluse
        #balayage des dossiers à analyser, appel d'une ligne par client liste de valeurs
        # pointeur de la base principale ( ouverture par défaut de db_prim via xGestionDB)
        DBsql = xdb.DB()

        wx.MessageBox("c'est parti pour : %s-%s-%s-%s-%s-%s")%(analyse,annee,client,groupe,filiere,gesttable)
        # transposition de l'ordre des variables de calcul à sortie
        dicAnalyse = PrechargeAnalyse(analyse,DBsql)
        dicExport = {}
        for ordre,variable in dicAnalyse:
            if variable[""] :
                pass
        #ajouter le champ colonne à dicAnalyse pour trier dessus
        
        lstvariables = []
        table = '%s'%analyse
        dicoDB = {}
        dicoDB[table]=[]
        for code,genre,info in lstvariables:
            dicoDB[table].append((code,genre,info))
        pass

class Fonctions(object):
    # classe des fonctions utilisables dans le calcul des variables, pour un dossier pointé
    def __init__(self,parent, tplIdent, analyse = None, title='',agcuser=None):
        self.parent = parent
        self.analyse = analyse
        self.agcuser = agcuser
        self.title = title +'[UTIL_analyses].Fonctions'
        def Topwin():
            topwin = False
            try:
                # enrichissement du titre pour débug
                nameclass = self.parent.__class__.__name__
                self.title = nameclass + ': ' + self.title
                self.topWindow = wx.GetApp().GetTopWindow()
                if self.topWindow:
                    topwin = True
            except:
                pass
            return topwin
        self.topwin = Topwin()
        self.errorResume = False
        self.messBasEcran = ''
        self.tplIdent = tplIdent
        (self.IDagc, self.IDexploitation, self.Cloture) = self.tplIdent

        # pointeur de la base principale ( ouverture par défaut de db_prim via xGestionDB)
        self.DBsql = xdb.DB()

        #préchargement des infos du dossier
        def PrechargeIdent():
            lstChamps = CHAMPS_TABLES['_Ident']
            req = """SELECT * FROM _Ident
                    WHERE (IDagc = '%s'   AND IDexploitation = '%s' AND Clôture = '%s')
                    ;""" % self.tplIdent
            retour = self.DBsql.ExecuterReq(req, mess='accès OpenRef précharge _Ident')
            dic = {}
            if retour == "ok":
                recordset = self.DBsql.ResultatReq()
                dic = ListsToDic(lstChamps, recordset[0])
            return dic
        def PrechargeInfos():
            req = """SELECT * FROM _Infos
                    WHERE (IDdossier = '%s')
                    ;""" % self.dicIdent['iddossier']
            retour = self.DBsql.ExecuterReq(req, mess='accès OpenRef précharge _Infos')
            dic = {}
            if retour == "ok":
                recordset = self.DBsql.ResultatReq()
                for ligne in recordset:
                    dic[ligne[0]] = (ligne[1],ligne[2],ligne[3])
            return dic
        self.dicIdent = PrechargeIdent()
        self.dicInfos = PrechargeInfos()
        self.dicAnalyse = PrechargeAnalyse(self.analyse,self.DBsql)
        #dicVariables contient le résultat des variables du client, dicAnalyse la liste des expressions de calculs
        self.dicVariables = {}
        self.lstfonctions = ['Ident','Infosident','Communeinsee','Balancemvt','Balance_N1','Balance','Produits','Calcul','Div','Nz']

    def Ident(self,param,*args):
        mess = ''
        expression = str(param[:])
        expr = str(param[:])
        valeur = None
        #découpage de l'expression expression en mots non blancs
        for car in ('+','-','\'','(',')','[',']','/','*',','):
            expr = expr.replace(car,';')
        lstmots = expr.split(';')

        #remplacement des valeurs prises dans la table ident ou infoIdent
        lstfn = []
        for motex in lstmots:
            mot = motex.strip()
            if len(mot) > 0:
                if mot in self.dicIdent.keys():
                    valeur = self.dicIdent[mot]
                    if not valeur : valeur = ''
                    if isinstance(valeur,float): valeur = round(valeur,4)
                    expression = expression.replace(mot,str(valeur))
                    continue
                if mot in self.dicInfos.keys():
                    valeur = self.Infosident(mot)
                    if not valeur : valeur = ''
                    if isinstance(valeur,float): valeur = round(valeur,4)
                    expression = expression.replace('mot',str(valeur))
                    continue
                if mot.title() in self.lstfonctions:
                    lstfn.append(mot)
                    continue
                mess += "Le champ %s n'est pas connu dans fonction Ident\t>>Vérifiez les paramètres des variables\n"%mot

        for mot in lstfn:
            expression, err = self.Fonction(mot, expression)
            if (not expression) or err:
                mess += err + "\n"
                break
        try:
            valeur = eval(expression)
        except Exception as err:
            valeur = expression
        return valeur,mess

    def Infosident(self,param,*args):
        valeur = None
        for car in ('+','-',',',';','&'):
            param = param.replace(car,' ')
        lstChamps = param.split(' ')
        for champ in lstChamps:
            if len(champ)>0:
                if champ in self.dicInfos:
                    if valeur:
                        if isinstance(valeur,str):
                            valeur += ' ' + str(self.dicInfos[champ])
                        else:
                            valeur += self.dicInfos[champ]
                    else: valeur = self.dicInfos[champ]
        return valeur,''

    def Balance(self,param, *args, mvt=False, n1=False):
        mess = ''
        param = param.upper()
        par2 = param.replace('-',',-').replace('+',',+')
        lstComposants = par2.replace(';',',').split(',')
        valeur = 0.0
        lstChamps = CHAMPS_TABLES['_Balances']
        for composant in lstComposants:
            # extraction du signe
            signe = 1
            compos = composant.strip()
            if composant[0] in ('-','+'):
                if composant[0] == '-': signe = -1
                compos = composant[1:]
                compos = compos.strip()
            # extraction du préfixe
            i = 0
            while compos[i] in ('D','C','%'):
                i += 1
            prefixe = compos[0:i]
            radical = compos[i:]
            try:
                j = int(radical)
            except:
                mess += "\tSeul les chiffres sont admis dans le radical '%s' d'un compte\n" % radical
            #appel des valeurs dans la balance éclatement du solde en deux colonnes
            if mvt :
                select = "SUM(round(DBmvt,2)),SUM(round(CRmvt,2))"
            else:
                select = "SUM(IF(SoldeFin > 0,round(SoldeFin,2),0)),SUM(IF(SoldeFin < 0, round(-SoldeFin,2),0))"
            if n1:
                # option n-1 ne permet pas le calcul des mouvements
                select = "SUM(IF(SoldeDeb > 0,round(SoldeDeb,2),0)),SUM(IF(SoldeDeb < 0, round(-SoldeDeb,2),0))"

            req = """SELECT %s
                    FROM _Balances
                    WHERE (IDdossier = '%s' 
                            AND Compte LIKE '%s')
                    ;""" %(select, self.dicIdent['iddossier'], radical+'%')
            retour = self.DBsql.ExecuterReq(req, mess='accès OpenRef précharge _Ident')
            montant = 0.0
            if retour == "ok":
                recordset = self.DBsql.ResultatReq()
                for slddeb, sldcre in recordset:
                    if not slddeb: slddeb = 0
                    if not sldcre: sldcre = 0
                    if prefixe == '':
                        if radical[0] == '7': montant = -(slddeb - sldcre)
                            #inversion pour la classe 7 pour que les montants créditeurs soient positifs
                        else: montant = slddeb - sldcre
                    #le premier caractère du préfixe détermine le sens
                    elif prefixe == 'DC': montant = slddeb - sldcre
                    elif prefixe == 'CD': montant = sldcre - slddeb
                    elif prefixe == 'D': montant = slddeb
                    elif prefixe == 'C': montant = sldcre
                    elif prefixe == 'DC%':
                        if (slddeb - sldcre) > 0.0: montant = slddeb
                        else: montant = 0.0
                    elif prefixe == 'CD%':
                        if (slddeb - sldcre) < 0.0: montant = -slddeb
                        else: montant = 0.0
                    else : mess = "\tLe préfixe '%s', n'est pas géré dans le radical %s\n"%(prefixe,radical)
            valeur += signe*montant
        if mess != '': mess = ("Balance: %s"%mess)
        return valeur,mess

    def Balancemvt(self,param,*args):
        return self.Balance(param,mvt = True)

    def Balance_N1(self, param,*args):
        return self.Balance(param, n1=True)

    def Produits(self, param,*args):
        return 0.0,''
        #TODO Produits'

    def Calcul(self,param,*args):
        #réduire un argument param de fonction calcul contenant une expression
        mess = ''

        #Cas d'une variables de destination nommée dans le param de calcul 'Vxxx = zzzz'
        valeur = None
        lst = param.split('=')
        if len(lst) >2  :
            return 0.0,"Calcul: deux signes égal dans %s"%param
        elif len(lst)==1:
            nomvar = None
            expression = lst[0]
        else:
            nomvar = lst[0]
            expression = lst[1]
        if len(lst) >2  :
            return 0.0,"deux signes égal dans %s"%(param)
        expr = expression

        #découpage de l'expression de la variable en mots non blancs
        for car in ('+','-','\'','(',')','[',']','/','*',','):
            expr = expr.replace(car,';')
        lstmots = expr.split(';')

        #remplacement des variables déjà calculées par leurs valeurs
        for motex in lstmots:
            mot = motex.strip()
            if len(mot) > 0:
                if mot in self.dicVariables:
                    valeur = self.dicVariables[mot]
                    if isinstance(valeur, float): valeur = round(valeur,4)
                    if not valeur: valeur = 0.0
                    ixdep = expression.index(mot)
                    ixfin = ixdep + len(mot)
                    expression = expression[:ixdep] + str(valeur) + expression[ixfin:]

        # test si nom de fonction on lance la fonction
        yafonction = True
        while yafonction:
            yafonction = False
            for mot in self.lstfonctions:
                if mot.lower() in expression.lower():
                    yafonction = True
                    expression,err = self.Fonction(mot,expression)
                    if (not expression) or err:
                        mess += err+"\n"
                        yafonction = False
                        break

        #final toutes les substitutions sensées faites
        try:
            valeur = eval(expression)
        except Exception as err:
            mess += "\n%s: eval(%s) : %s\n"%(param,expression,err)
        if mess == '':
            if nomvar:
                self.dicVariables[nomvar.lower()] = valeur
            return valeur,''
        else:
            if not self.errorResume:
                rep = wx.MessageBox('Erreurs rencontrées : ABANDON ? \n\n%s'%mess,style = wx.YES_NO|wx.ICON_STOP)
                if rep == wx.NO:
                    # les prochaines erreurs seront cumulées sans interruption
                    self.errorResume = True
                if self.topwin:
                    if len(mess)>100: mess = mess[:50] + '...'+mess[-50:]
                    self.messBasEcran += mess
                    self.messBasEcran = self.messBasEcran[-300:]
                    self.topWindow.SetStatusText(self.messBasEcran)
            return 0,mess

    def Div(self,param,*args):
        # fonction division arrangée
        mess = ''
        lst = param.split(',')
        if len(lst) != 2  :
            return 0.0,"Div  : il n'y a pas diviseur et dividende dans %s"%param
        valeur = 0.0
        try:
            a = float(lst[0])
            b = float(lst[1])
            valeur = round(a/b,2)
        except:
            pass
        return valeur,''

    def Nz(self,param,*args):
        # fonction Null devient zero
        mess = ''
        valeur = 0.0
        try:
            valeur = float(param)
        except: pass
        return valeur,''

    # nouvel appel d'une fonction désignée par un mot  trouvé dans expression : Réduction  de l'expression
    def Fonction(self,mot, expression,*args):
        err = ''
        try:
            def Separearg(mot,expression):
                motmin = mot.lower()
                err = ''
                if len(mot)>0:
                    debmot= expression.index(motmin)
                else :
                    debmot=0
                finmot= debmot+len(mot)
                # vérifie les parenthèses derrière fonction
                if expression[finmot:finmot+1] != '(':
                    err = "manque une parenthèse ouvrante derrière '%s' dans %s"%(mot,expression)
                    return None, err
                x,niv =1,1
                for car in expression[finmot+1:]:
                    if car == '(': niv +=1
                    if car == ')': niv -=1
                    if niv == 0:
                        lgarg = x
                        break
                    x += 1
                if niv > 0:
                    err = "manque une parenthèse fermante derrière '%s' dans %s"%(mot,expression)
                finfn = finmot + lgarg
                debut = expression[:debmot]
                fonction = expression[ debmot: finmot]
                arguments = expression[ finmot+1 : finfn]
                fin = expression[finfn+1:]
                return debut,fonction,arguments,fin,err
            debut, fonction, arguments, fin, err = Separearg(mot,expression)

            # recherche d'éventuelles imbrications de fonctions
            def Imbrication(arguments):
                err = ''
                #test de présence de fonction dans l'argument boucle tant qu'il y a à faire
                go = True
                while go:
                    go = False
                    for fn in self.lstfonctions:
                        if fn.lower() in arguments:
                            go = True
                            arguments,err = self.Fonction(fn,arguments)
                            if err != '':
                                ok = False
                                return None, err
                    # test de parenthèses imbriquées agregation préalable
                go = True
                while go:
                    go = False
                    if '(' in arguments:
                        if not ')' in arguments:
                            err = "manque une parenthèse fermante derrière '%s' dans %s" % (mot, arguments)
                            return None, err
                        go = True
                        ix = arguments.index('(')
                        ssdebut, ssfonction, ssarg, ssfin, err = Separearg('',arguments[ix:])
                        valeur, err = self.Calcul(ssarg)
                        if err == '' :
                            arguments = arguments.replace('(%s)'%ssarg,str(valeur))
                        else: return None, err
                return arguments, err
            arguments, err = Imbrication(arguments)
            if err == '':
                #insertion d'apostrophes pour des paramétres en str
                formule = fonction[:].title()+"('%s')"%arguments
                formule = 'self.'+formule
                valeur, err = eval(formule)
                expression = "%s%s%s"%(debut,str(valeur),fin)
        except Exception as err:
             return None,err
        return expression,err
        #fin de Fonction

    # exécute la fonction avec args(expression) désignée par la colonne 'fonction' de wVariables
    def Variable(self,code,libelle,fonction,param,atelier,produit):
        mess = ''
        if atelier == '': atelier = None
        if produit == '': produit = None

        # controle du formalisme des arguments
        if not(libelle and fonction and param ): mess = "%s : impossible car sont obligatoires : libelle,fonction,param 1\n"%code
        elif not isinstance(param,str) : mess = "Chaîne attendue, le paramètre1 pour '%s' est de type: %s\n"%(libelle,type(param))
        elif len(param) == 0 : mess = "Le paramètre1 de '%s' ne peut pas être une chaîne vide\n"%libelle
        elif fonction.title() not in self.lstfonctions : mess = "La fonction '%s.%s' n'est pas connue\nPossibles : %s\n"%(libelle,fonction, str(self.lstfonctions))

        if mess == '':
            try:
                #appel de la fonction et des trois arguments possibles
                expr = "self.%s(\"%s\",\"%s\",\"%s\")"%(fonction.title(), param.lower(),atelier,produit)
                valeur, mess = eval(expr)
            except Exception as err:
                mess = expr + '\n' + str(err)
        if mess!='':
            mess = "%s: %s"%(code,mess)
            valeur = None
        else:
            #stockage de la variable
            self.dicVariables[code.lower()]=valeur
            self.dicVariables[libelle.lower()] = valeur
        return valeur,mess

    # déroule toutes les variables de l'analyse pour composer la ligne des données du client
    def ComposeLigne(self):
        mess = ''
        dicLigne={}
        try:
            for variable in sorted(self.dicAnalyse.keys()):
                valeur, mess = self.Variable(
                                            code=self.dicAnalyse[variable]['code'],
                                            libelle=self.dicAnalyse[variable]['libelle'],
                                            fonction=self.dicAnalyse[variable]['fonction'],
                                            param=self.dicAnalyse[variable]['param'],
                                            atelier=self.dicAnalyse[variable]['atelier'],
                                            produit=self.dicAnalyse[variable]['produit'])
                dicLigne[self.dicAnalyse[variable]['code']] = valeur
                if mess != '':
                    #présence d'erreurs
                    mess = 'variable %s : %s'%(variable, mess)
                    if not self.errorResume:
                        break
        except KeyboardInterrupt:
            wx.MessageBox('Arret clavier Ctrl C\n\nrapport erreurs :\n%s'%mess)

        self.ExporteLigne(self.dicIdent['iddossier'], self.analyse, self.agcuser,dicLigne)
        return dicLigne,mess

    # enregistre dans la table de l'analyse
    def ExporteLigne(self,dossier,analyse,agc,dicLigne):
        if not analyse : analyse = '*'
        if not agc : agc = '*'
        if not dossier : return

    def Close(self):
        try:
            self.DBsql.Close()
        except:pass
        wx.MessageBox('Au revoir Fonctions...')

#************************   Pour Test ou modèle  *********************************
if __name__ == '__main__':
    app = wx.App(0)
    fn = Fonctions(None,('prov','009418','2018-08-31'),analyse='AG83',agcuser='prov')
    valeur = fn.ComposeLigne()
    print('valeur variable: ',valeur[0])
    print('erreurs: ',valeur[1],'-')

    app.MainLoop()

