
import pyodbc
"""Important: 32bit MS driver - 32bit python!"""
"""N'est pas compatible access 95, mais oui avec access 2002"""

constructor = 'DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=c:/temp/test.mdb;'
strsql = "select * from table1"

cnxn = pyodbc.connect(constructor, autocommit=True)
cursor = cnxn.cursor()

cursor.execute(strsql)
t=list(cursor)
print(t)

cursor.execute(strsql)
for row in cursor.fetchall():
    print(row)

csr = cnxn.cursor()
csr.close()
del csr
cnxn.close()

