# !/usr/bin/env python
# -*- coding: utf-8 -*-

#----------------------------------------------------------------------------
# Application :    Projet XPY, Panel contenant Combo box et button action
# Auteurs:          Jacques BRUNEL
# Copyright:       (c) 2019-04     Cerfrance Provence, Matthania
# Licence:         Licence GNU GPL
#----------------------------------------------------------------------------

import wx
import os

class PNL_combo(wx.Panel):
    # Retourne la valeur choisie dans le combo avec action possible sur bouton à droite
    def __init__(self, parent, *args,label="", valeurs=[],btnLabel="...",help="", **kwds):
        wx.Panel.__init__(self,parent,*args, **kwds)
        self.label=label
        self.Initial(btnLabel)

    def Initial(self,btnLabel=""):
        self.btn = wx.Button(self,-1,btnLabel,size=(30,20))
        self.combo = wx.ComboBox(self,-1)
        topbox = wx.BoxSizer(wx.HORIZONTAL)
        topbox.Add(self.combo, 1, wx.ALL | wx.ALIGN_RIGHT, 4)
        topbox.Add(self.btn,0,wx.ALL|wx.ALIGN_RIGHT,4)
        self.SetSizer(topbox)


    def GetValue(self):
        return self.combo.GetValue()

#************************   Pour Test  ou modèle  *******************************
class Frame(wx.Frame):
    def __init__(self, *args, **kwds):
        listArbo=os.path.abspath(__file__).split("\\")
        titre = listArbo[-1:][0] + "/" + self.__class__.__name__
        wx.Frame.__init__(self,*args, title=titre, **kwds)
        self.MinSize = (400,200)
        self.panel = PNL_combo(self,-1,label="Le nom du choix",valeurs=['ceci', 'cela', 'ou un autre', 'la vie est faite de choix'],btnLabel=" ! ", help="Là vous pouvez lancer une action telle que la gestion des choix possibles")
        self.panel.btn.Bind(wx.EVT_BUTTON,self.OnBoutonAction)
        sizer_1 = wx.BoxSizer(wx.VERTICAL)
        sizer_1.Add(self.panel, 1, wx.ALL|wx.ALIGN_CENTRE,4)
        self.SetBackgroundColour(wx.WHITE)
        self.SetSizer(sizer_1)
        self.Layout()
        self.CentreOnScreen()

    def OnBoutonAction(self, event):
        #Bouton Test
        print("Bonjour l'action OnBoutonAction de l'appli")
        self.panel.btn.SetLabel("Clic")


if __name__ == '__main__':
    app = wx.App(0)
    myframe = Frame(None)
    app.SetTopWindow(myframe)
    myframe.Show()
    app.MainLoop()

