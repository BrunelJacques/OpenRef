#!/usr/bin/env python
# -*- coding: utf8 -*-

#------------------------------------------------------------------------
# Application :    OpenRef, utilitaires pour l'import des comptas
# Auteurs:          Jacques BRUNEL
# Copyright:       (c) 2019-04     Cerfrance Provence
# Licence:         Licence GNU GPL
#------------------------------------------------------------------------

import os
import wx
import datetime
import srcOpenRef.GestionConfig as orgc
import xpy.xUTILS_Config as xucfg
import xpy.xGestionDB as xdb

def ListeToDict(listecles, listevaleurs):
    dic = {}
    try:
        for ix in range(len(listecles)):
            dic[listecles[ix]] = listevaleurs[ix]
    except: pass
    return dic

class ImportComptas(object):
    def __init__(self,parent, title=''):
        self.parent = parent
        self.title = title +'[UTIL_import].ImportComptas'
        try:
            # enrichissement du titre pour débug
            nameclass = self.parent.__dir__['nameClass']
            title = nameclass + ': ' + title
        except: pass

        #récup des arguments stockés dans le shelve
        cfg = xucfg.ParamUser()
        implantation= cfg.GetDict(dictDemande=None, groupe='IMPLANTATION', close=False)
        choiximport= cfg.GetDict(dictDemande=None, groupe='IMPORT', close=False)
        user= cfg.GetDict(dictDemande=None, groupe='USER')
        ident= cfg.GetDict(dictDemande=None, groupe='IDENT')
        self.config = {}
        for groupe in [implantation,choiximport,user,ident]:
            for key,value in groupe.items():
                self.config[key] = value

        #ouverture des bases communes GI et OpenRef en s'appuyant sur le  self.config(dict)
        self.DBgi = self.GetGI()
        # ouverture base principale ( ouverture par défaut de db_prim via xGestionDB)
        self.DBsql = xdb.DB()

    def GetGI(self):
        # pointer la gestion interne quadra
        DBgi = None
        if self.config['compta'] == 'quadratus':
            configGI = {}
            configGI['typeDB'] = 'access'
            configGI['serveur'] = self.config['serveur']
            configGI['nameDB'] = 'qgi.mdb'
            configGI['serveur'].replace('datadouble', 'database')
            DBgi = xdb.DB(config=configGI)
            if DBgi.echec == 1: DBgi = None
        return DBgi

    def GetClient(self,code, dicCompta):
        if not 'ident' in dicCompta : dicCompta['ident']={}
        dicIdent = {}
        dicInfos = {}
        if self.config['compta'] == 'quadratus':
            lstCle = ['code', 'juridique', 'production','impot','is-ir','dja']
            req = """SELECT Clients.Code, Intervenants.TypeSociete, Activites.Libelle, Fiscal.CodeImpotDirect, Fiscal.Impot, Intervenants.DateInstallation
                    FROM ((Clients 
                    LEFT JOIN Intervenants ON Clients.Code = Intervenants.Code) 
                    LEFT JOIN Fiscal ON Clients.Code = Fiscal.CodeClient) 
                    LEFT JOIN Activites ON Clients.CodeActivite = Activites.Code
                    WHERE (((Clients.Code) = '%s' ))
                    ;""" % code
            retour = self.DBgi.ExecuterReq(req, mess='accès GI quadra')
            if retour == "ok":
                recordset = self.DBgi.ResultatReq()
                dicGI = ListeToDict(lstCle, recordset[0])
                dicIdent['IDagc'] = self.config['agc']
                dicIdent['IDexploitation'] = code
                dicIdent['IDuser'] = self.config['domaine'] + '.'+self.config['utilisateur']+'/'+self.config['pseudo']
                dicIdent['IDlocalisation'] = self.config['localis']
                dicIdent['IDjuridique'] = dicGI['juridique']
                dicIdent['Filières'] = [dicGI['production']]
                dicIdent['Fiscal'] = dicGI['impot']
                dicIdent['IS-IR'] = dicGI['is-ir']
                if str(dicGI['dja'])[:4] > '1950':
                    dicInfos['dja'] = str(dicGI['dja'])[:10]
        dicCompta['ident'] = dicIdent
        dicCompta['infos'] = dicInfos

    def GetCompta(self,configCPTA,dicCompta):
        nomBase = None
        try:
            DBq = xdb.DB(config = configCPTA)
            nomBase = DBq.nomBase
            if DBq.echec != 0:
                mess = self.title+ ": " + DBq.echec
                nomBase=None
                wx.MessageBox(mess)
        except Exception as err:
            mess = self.title + '.GetCompta:\n%s'%err
            wx.MessageBox(mess, style=wx.ICON_INFORMATION)
        if nomBase:
            lstBalance = []
            if self.config['compta'] == 'quadratus':
                #import des infos de la table dossier dans la compta
                lstCle = ['cloture', 'nomexploitation', 'codepostal', 'siret', 'naf', 'duree']
                req = """SELECT Dossier1.FinExercice, Dossier1.RaisonSociale, Dossier1.CodePostal, Dossier1.Siret, Dossier1.CodeNAF, Dossier1.DureeExercice
                        FROM Dossier1;"""
                retour = DBq.ExecuterReq(req, mess='accès Qcompta.dossier quadra')
                if retour == "ok":
                    recordset = DBq.ResultatReq()
                    dicDoss = ListeToDict(lstCle, recordset[0])
                    dicCompta['ident']['Clôture'] = str(dicDoss['cloture'])[:10]
                    dicCompta['ident']['NomExploitation'] = dicDoss['nomexploitation']
                    dicCompta['ident']['IDCodePostal'] = dicDoss['codepostal']
                    dicCompta['ident']['Siren'] = dicDoss['siret'][:9]
                    dicCompta['ident']['IDnaf'] = dicDoss['naf']
                    dicCompta['ident']['NbreMois'] = int(dicDoss['duree'])

                # appel de la balance clients et fournisseurs
                # lstCle = ['compte', 'libcompte', 'libecriture', 'anouv', 'qte', 'qtenature','qte2','qte2nature','debits','credits']
                req = """
                    SELECT Comptes.Collectif, Comptes.Type, "collectif" AS ecrLibelle, 
                        IIf(Left([TypeJournal],1)="N",1,0) AS AN, Sum([Quantite]) AS qte, 
                        Comptes.QuantiteLibelle, Sum([Quantite2]) AS qte2, Comptes.QuantiteLibelle2, 
                        Sum(Ecritures.MontantTenuDebit) AS Debits, Sum(Ecritures.MontantTenuCredit) AS Credits
                    FROM Dossier1, (Ecritures 
                                    INNER JOIN Comptes ON Ecritures.NumeroCompte = Comptes.Numero) 
                        INNER JOIN Journaux ON Ecritures.CodeJournal = Journaux.Code
                    WHERE (((Ecritures.PeriodeEcriture)<=[dossier1].[finexercice]) AND ((Left([NumeroCompte],1))='0'))
                    GROUP BY Comptes.Collectif, Comptes.Type, IIf(Left([TypeJournal],1)="N",1,0), 
                            Comptes.QuantiteLibelle, Comptes.QuantiteLibelle2;
                    """
                retour = DBq.ExecuterReq(req, mess='accès Qcompta.ecritures auxiliaires quadra')
                recordsetAux = recordset = []
                if retour == "ok":
                    recordsetAux = DBq.ResultatReq()
                #appel de la balance hors clients et fournisseurs
                #lstCle = ['compte', 'libcompte', 'libecriture', 'anouv', 'qte', 'qtenature','qte2','qte2nature','debits','credits']
                req = """
                    SELECT Ecritures.NumeroCompte, Comptes.Intitule, Max(Ecritures.Libelle) AS ecrLibelle,
                        IIf(Left([TypeJournal],1)="N",1,0) AS AN,
                        Sum([Quantite]) AS qte, Comptes.QuantiteLibelle, Sum([Quantite2]) AS qte2, Comptes.QuantiteLibelle2, 
                        Sum(Ecritures.MontantTenuDebit) AS Debits, Sum(Ecritures.MontantTenuCredit) AS Credits
                    FROM Dossier1, (Ecritures 
                                    INNER JOIN Comptes ON Ecritures.NumeroCompte = Comptes.Numero) 
                    INNER JOIN Journaux ON Ecritures.CodeJournal = Journaux.Code
                    WHERE (((Ecritures.PeriodeEcriture)<=[dossier1].[finexercice]) AND ((Left([NumeroCompte],1))<>'0'))
                    GROUP BY Ecritures.NumeroCompte, Comptes.Intitule, IIf(Left([TypeJournal],1)="N",1,0), 
                                Comptes.QuantiteLibelle, Comptes.QuantiteLibelle2
                    ORDER BY Ecritures.NumeroCompte;
                    """
                retour = DBq.ExecuterReq(req, mess='accès Qcompta.ecritures quadra')
                if retour == "ok":
                    recordset = DBq.ResultatReq()

                # constitution des lignes a importer
                for compte, libcompte, libmaxecriture, anouv, qte, qtenature,qte2,qte2nature,debits,credits in recordset + recordsetAux :
                    if anouv ==1 :
                        #cumul d'écritures a nouveaux
                        soldedeb = soldefin = round(debits - credits,2)
                        mvtdeb = mvtcre = 0.0
                    else:
                        soldedeb = 0.0
                        mvtdeb = round(debits,2)
                        mvtcre = round(credits,2)
                        soldefin = round(debits - credits,2)
                    lstBalance.append((compte, libcompte.strip() + ' % ' + libmaxecriture.strip(), qte, qtenature,
                                       qte2,qte2nature, soldedeb,mvtdeb, mvtcre, soldefin))

            dicCompta['balance'] = lstBalance


    def Stockage(self,dicCompta):
        print('récolte: ',dicCompta)
        return

    def QuadraLstPaths(self,pathCompta,annee,nbAnter):
        #renvoie la liste des répertoires qu'il faut inspecter pour une plage d'exercices
        lstPaths = []
        if not annee : annee = datetime.datetime.now().year -1
        if not nbAnter : nbAnter = 0
        annee = int(annee)
        pathCpta = pathCompta+ '/CPTA/'
        # balayage dossiers archives
        for item in os.listdir(pathCpta):
            if (item[:2].lower() == 'da') and os.path.isdir(pathCpta +item):
                for i in range(0,int(nbAnter)):
                    an = 'DA'+str(annee-i)
                    if an in item:
                        lstPaths.append(pathCpta+item)
        lstPaths.append(pathCpta+'DC')
        return lstPaths

    def ImportMono(self):
        # import des comptas d'un seul dossier sur une plage d'exercices
        configCPTA = {}
        if self.config['compta'] == 'quadratus':
            configCPTA['nameDB'] = 'Qcompta.mdb'
            configCPTA['typeDB'] = 'access'
            # balayage de la liste des répertoires utiles pour la compta
            lstPaths = self.QuadraLstPaths(self.config['pathCompta'],self.config['annee'],self.config['nbAnter'],)
            dicCompta = {}
            self.GetClient(self.config['client'],dicCompta)
            # lancement du balayage des comptas dans la plage d'exerices
            for path in lstPaths:
                if os.path.isfile(path+'/'+self.config['client']+'/QCompta.mdb'):
                    configCPTA['serveur'] = path + '/'+self.config['client']
                    self.GetCompta(configCPTA,dicCompta)
                    self.Stockage(dicCompta)
        self.Close()

    def Close(self):
        try:
            self.DBgi.Close()
            self.DBsql.Close()
        except:pass
        wx.MessageBox('%s \n\nFin de l\'import'%self.title)


#************************   Pour Test ou modèle  *********************************
if __name__ == '__main__':
    app = wx.App(0)
    imp = ImportComptas(None)
    imp.ImportMono()
    app.MainLoop()

