# !/usr/bin/env python
# -*- coding: utf-8 -*-

#----------------------------------------------------------------------------
# Application :    Projet XPY, gestion des paramètres de configuration
# Licence:         Licence GNU GPL
#----------------------------------------------------------------------------

import wx

class FichierConfig():
    def __init__(self, nomFichier = None):
        self.nomFichier = nomFichier

    def GetDictConfig(self):
        """ Recupere une copie du dictionnaire du fichier de config """
        import shelve
        db = shelve.open(self.nomFichier, 'c')
        dictDonnees = {}
        for key in db.keys():
            dictDonnees[key] = db[key]
            #print key, db[key]
        db.close()
        return dictDonnees

    def SetDictConfig(self, dictConfig={} ):
        """ Remplace le fichier de config présent sur le disque dur par le dict donné """
        import shelve
        db = shelve.open(self.nomFichier)
        for key in dictConfig.keys():
            db[key] = dictConfig[key]
        db.close()
        db = shelve.open(self.nomFichier)

    def GetItemConfig(self, key, defaut=None):
        """ Récupère une valeur du dictionnaire du fichier de config """
        import shelve
        db = shelve.open(self.nomFichier, "c")
        if key in db :
            valeur = db[key]
        else:
            valeur = defaut
        db.close()
        return valeur

    def SetItemConfig(self, key, valeur ):
        """ Remplace une valeur dans le fichier de config """
        import shelve
        db = shelve.open(self.nomFichier, "c")
        db[key] = valeur
        db.close()

    def DelItemConfig(self, key ):
        """ Supprime une valeur dans le fichier de config """
        import shelve
        db = shelve.open(self.nomFichier, "c")
        del db[key]
        db.close()

# --------------Traitement par lot ------------------------------------------------------------------------------------

def GetParametres(parametres=[]):
    """ dict parametres = {nom : valeur, nom: valeur...} """
    """ list ou tuple = [nom , nom] """
    """ l'absence de parametres veut dire : tous les possibles"""
    dictFinal = {}
    try :
        topWindow = wx.GetApp().GetTopWindow()
        nomWindow = topWindow.GetName()
    except :
        nomWindow = None

    # Cherche la sources des données
    if nomWindow == "general" :
        dictSource = topWindow.userConfig
    else :
        nomFichierConfig = "Config"
        cfg = FichierConfig(nomFichierConfig)
        dictSource = cfg.GetDictConfig()

    # Lit les données
    if isinstance(parametres, dict):
        lstNoms = parametres.keys()
    elif isinstance(parametres,(list, tuple)): lstNoms = parametres
    else: lstNoms = dictSource.keys()

    # l'absence de parametres veut dire tous les possibles
    if len(lstNoms) == 0 : lstNoms = dictSource.keys()

    for nom in lstNoms :
        if nom in dictSource:
            dictFinal[nom] = dictSource[nom]
        else:
            # par défaut si la valeur demandée n'était pas stockée on retourne ce qui est arrivé
            if isinstance(parametres, dict): dictFinal[nom] = parametres[nom]
            else: dictFinal[nom] = None

    return dictFinal

def SetParametres(dictParametres={}):
    """ dictParametres = {nom : valeur, nom: valeur...} """
    try :
        topWindow = wx.GetApp().GetTopWindow()
        nomWindow = topWindow.GetName()
    except :
        nomWindow = None
    if nomWindow == "general" :
        # Si la frame 'General' est chargée, on y récupère le dict de config
        for nom, valeur in dictParametres.items() :
            topWindow.userConfig[nom] = valeur
    else:
        # Enregistrement dans le fichier de config sur le disque dur
        nomFichierConfig = "Config"
        cfg = FichierConfig(nomFichierConfig)
        cfg.SetDictConfig(dictParametres)
    return dictParametres

# --------------- TESTS -----------------------------------------------------------------------------------------------

class MyFrame(wx.Frame):
    def __init__(self, parent, id, title):
        nomCfg = 'Config'

        self.cfg = GetParametres({'TestXPYConfigwidth': 200, 'TestXPYConfigheight': 200})
        if 'TestXPYConfigwidth' in self.cfg :
            w, h = self.cfg['TestXPYConfigwidth'], self.cfg['TestXPYConfigheight']
        else:
            (w, h) = (250, 250)
        wx.Frame.__init__(self, parent, id, title, wx.DefaultPosition, wx.Size(300, 300))

        wx.StaticText(self, -1, 'TestXPYConfigWidth:', (20, 20))
        wx.StaticText(self, -1, 'TestXPYConfigHeight:', (20, 70))
        self.sc1 = wx.SpinCtrl(self, -1, str(w), (140, 15), (60, -1), min=0, max=500)
        self.sc2 = wx.SpinCtrl(self, -1, str(h), (140, 65), (60, -1), min=0, max=500)
        wx.Button(self, 1, 'Save', (20, 120))

        self.Bind(wx.EVT_BUTTON, self.OnSave, id=1)
        self.statusbar = self.CreateStatusBar()
        self.Centre()
        self.statusbar.SetStatusText('Configuration saved in %s ' % nomCfg)

    def OnSave(self, event):
        self.cfg["TestXPYConfigwidth"]= self.sc1.GetValue()
        self.cfg["TestXPYConfigheight"]= self.sc2.GetValue()
        SetParametres(self.cfg)
        self.statusbar.SetStatusText('Configuration saved')


class MyApp(wx.App):
    def OnInit(self):
        frame = MyFrame(None, -1, 'myconfig.py')
        frame.Show(True)
        self.SetTopWindow(frame)
        return True


app = MyApp(0)
app.MainLoop()
