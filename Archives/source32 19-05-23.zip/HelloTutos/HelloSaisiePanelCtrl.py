# !/usr/bin/env python
# -*- coding: utf-8 -*-

#------------------------------------------------------------------------------
# Application :    Projet XPY, Gestion de Panels contenant des objets de saisie
# Auteurs:          Jacques BRUNEL
# Copyright:       (c) 2019-04     Cerfrance Provence, Matthania
# Licence:         Licence GNU GPL
#------------------------------------------------------------------------------

import wx
import os

class PNL_ctrl(wx.Panel):
    # GetValue retourne la valeur choisie dans le ctrl avec action possible par bouton à droite
    def __init__(self, parent, *args,label=None, genre='string', name=None, value= None, labels=None, values=None,valeurs=[], help=None,
                 btnLabel=None, btnHelp=None, btnAction='', ctrlAction='', **kwds):
        wx.Panel.__init__(self,parent,*args, **kwds)
        self.value = value
        if btnLabel :
            self.avecBouton = True
        else: self.avecBouton = False

        self.MaxSize = (2000, 35)
        self.txt = wx.StaticText(self, -1, label + " :")
        self.txt.MinSize = (150, 65)

        if genre.lower() in ['enum', 'combo', 'multichoice']:
            self.ctrl = wx.ComboBox(self, -1)
            self.ctrl.Set(valeurs)
            self.ctrl.SetSelection(0)
        elif genre.lower() in ['bool', 'check']:
            self.ctrl = wx.CheckBox(self, -1)
            self.UseCheckbox = 1
        else:
            self.ctrl= wx.TextCtrl(self, -1)
        if help:
            self.ctrl.SetToolTip(help)
            self.txt.SetToolTip(help)
        if genre.lower() == 'dir':
            self.avecBouton = True
            if not btnLabel: btnLabel = '...'
            self.btn = wx.Button(self, -1, btnLabel, size=(30, 20))
            self.btn.Bind(wx.EVT_BUTTON, self.OnDir)
        elif self.avecBouton:
            self.btn = wx.Button(self, -1, btnLabel, size=(30, 20))
            if btnHelp:
                self.btn.SetToolTip(btnHelp)
        self.BoxSizer()

    def BoxSizer(self):
        topbox = wx.BoxSizer(wx.HORIZONTAL)
        topbox.Add(self.txt,0, wx.LEFT|wx.TOP|wx.ALIGN_TOP, 4)
        topbox.Add(self.ctrl, 1, wx.ALL | wx.EXPAND, 4)
        if self.avecBouton:
            topbox.Add(self.btn, 0, wx.ALL|wx.EXPAND, 4)
        self.SetSizer(topbox)

    def GetValue(self):
        return self.ctrl.GetValue()

    def SetValue(self,value):
        self.ctrl.SetValue(value)

    def SetValues(self,values):
        self.ctrl.Set(values)

    def OnDir(self,event):
        """ Open a file"""
        self.dirname = ''
        dlg = wx.DirDialog(self, "Choisissez un emplacement", self.dirname)
        if dlg.ShowModal() == wx.ID_OK:
            self.ctrl.SetValue(dlg.GetPath())
        dlg.Destroy()

class BoxPanel(wx.Panel):
    # aligne les contrôles définis dans la matrice dans une box
    def __init__(self, parent, *args, lblbox="Box", lignes=[], **kwds):
        wx.Panel.__init__(self,parent, *args, **kwds)
        self.parent = parent

        ssbox = wx.BoxSizer(wx.VERTICAL)
        for ligne in lignes:
            for nom,valeur in ligne.items():
               kwds[nom] = valeur
            if 'genre' in ligne:
                panel = PNL_ctrl(self, *args, **kwds)
                if ligne['genre'].lower() in ['bool', 'check']:
                    self.UseCheckbox = 1
                if panel:
                    for cle in ('name','label','ctrlAction','btnLabel','btnAction'):
                        if not cle in ligne:
                            ligne[cle]=None
                    ssbox.Add(panel,1,wx.ALL|wx.EXPAND,4)
                    panel.ctrl.genreCtrl = ligne['genre']
                    panel.ctrl.nameCtrl = ligne['name']
                    panel.ctrl.labelCtrl = ligne['label']
                    panel.ctrl.actionCtrl = ligne['ctrlAction']
                    if panel.avecBouton and ligne['genre'].lower() != 'dir' :
                        panel.btn.nameBtn = ligne['name']
                        panel.btn.labelBtn = ligne['btnLabel']
                        panel.btn.actionBtn = ligne['btnAction']
                        panel.btn.Bind(wx.EVT_BUTTON,self.parent.OnBouton)
                    panel.ctrl.Bind(wx.EVT_TEXT,self.parent.OnEnter)
                    panel.ctrl.Bind(wx.EVT_COMBOBOX, self.parent.OnEnter)
                    panel.ctrl.Bind(wx.EVT_CHECKBOX, self.parent.OnEnter)
        self.SetSizerAndFit(ssbox)

class TopPanel(wx.Panel):
    def __init__(self, parent, *args, matrice={}, donnees={}, lblbox="Paramètres", **kwds):
        wx.Panel.__init__(self,parent,*args, **kwds)
        self.parent = parent

        cadre_staticbox = wx.StaticBox(self,-1,label=lblbox)
        topbox = wx.StaticBoxSizer(cadre_staticbox,wx.HORIZONTAL)
        for nomCategorie in matrice:
            if isinstance(nomCategorie,str):
                topbox.Add(BoxPanel(self, -1, lblbox=nomCategorie, lignes=matrice[nomCategorie]), 1, wx.EXPAND,0)
        self.SetSizerAndFit(topbox)
    def OnEnter(self,event):
        self.parent.OnEnter(event)

    def OnBouton(self,event):
        self.parent.OnBouton(event)

class xFrame(wx.Frame):
    def __init__(self, *args, matrice={}, donnees={}, btnaction=None, lblbox="Paramètres", **kwds):
        listArbo=os.path.abspath(__file__).split("\\")
        titre = listArbo[-1:][0] + "/" + self.__class__.__name__
        wx.Frame.__init__(self,*args, title=titre, **kwds)
        self.topPnl = TopPanel(self,-1, matrice=matrice, donnees=donnees, lblbox=lblbox)
        self.btn0 = wx.Button(self, -1, "Action Frame")
        self.btn0.Bind(wx.EVT_BUTTON,self.OnBoutonAction)
        marge = 10
        sizer_1 = wx.BoxSizer(wx.VERTICAL)
        sizer_1.Add(self.topPnl, 0, wx.LEFT|wx.EXPAND,marge)
        sizer_1.Add(self.btn0, 0, wx.RIGHT|wx.ALIGN_TOP,marge)
        self.SetSizerAndFit(sizer_1)
        self.CentreOnScreen()

    def OnEnter(self,event):

        print('Bonjour Enter sur le ctrl : ',event.EventObject.Name)
        print(event.EventObject.genreCtrl, event.EventObject.nameCtrl, event.EventObject.labelCtrl,)
        print('Action prévue : ',event.EventObject.actionCtrl)

    def OnBouton(self,event):
        print('Vous avez cliqué sur le bouton')
        print(event.EventObject.Name)
        print( event.EventObject.nameBtn, event.EventObject.labelBtn,)
        print('vous avez donc souhaité : ',event.EventObject.actionBtn)

    def OnSauvegarde(self, event):
        #Bouton Test
        print("Bonjour l'action de sauvegarde dans la frame")

    def OnBoutonAction(self, event):
        #Bouton Test
        print("Bonjour l'action OnBoutonAction de l'appli")

#************************   Pour Test  ou modèle  *******************************
class myFrame(wx.Frame):
    def __init__(self, *args, **kwds):
        # cette frame ne passe pas par des panels de présentation elle appelle directement les panels des controles
        listArbo=os.path.abspath(__file__).split("\\")
        titre = listArbo[-1:][0] + "/" + self.__class__.__name__
        wx.Frame.__init__(self,*args, title=titre, **kwds)
        self.Size = (600,400)
        self.combo1 = PNL_ctrl(self,-1,
                            genre="combo",
                            label="Le nom du choix PEUT être long ",
                            valeurs=["ceci est parfois plus long, plus long qu'un autre", 'cela', 'ou un autre', 'la vie est faite de choix'],
                            help="Je vais vous expliquer",
                            btnLabel=" ! ",
                            btnHelp="Là vous pouvez lancer une action par clic")

        self.combo2 = PNL_ctrl(self,-1,genre="combo",label="Le nom2",valeurs=['ceci', 'cela', 'ou un autre', 'la vie LOong fleuve tranquile'],help="Je vais vous expliquer",btnLabel="...", btnHelp="Là vous pouvez lancer une action de gestion des choix possibles")
        self.combo3 = PNL_ctrl(self,-1,genre="combo",label="Le nom3 plus long",value=['ceci sans bouton', 'cela', 'ou un autre', 'la vie EST COURTE'], btnHelp="Là vous pouvez lancer une action telle que la gestion des choix possibles")
        self.ctrl1 = PNL_ctrl(self,-1,genre="string",label="Un ctrl à saisir",value='monchoix', help="Je vais vous expliquer",)
        self.ctrl2 = PNL_ctrl(self,-1,genre="string",label="Avec bouton de ctrl",value='monchoix étendu', help="Je vais vous expliquer", btnLabel="Ctrl", btnHelp="Là vous pouvez lancer une action de validation")

        self.combo1.btn.Bind(wx.EVT_BUTTON,self.OnBoutonActionCombo1)
        self.combo2.btn.Bind(wx.EVT_BUTTON,self.OnBoutonActionCombo2)
        self.ctrl2.btn.Bind(wx.EVT_BUTTON,self.OnBoutonActionTexte2)

        marge = 10
        sizer_1 = wx.BoxSizer(wx.VERTICAL)
        sizer_1.Add((10,10), 0, wx.LEFT|wx.ALIGN_TOP,marge)
        sizer_1.Add(self.combo1, 1, wx.LEFT|wx.ALIGN_TOP,marge)
        sizer_1.Add(self.combo2, 1, wx.LEFT|wx.ALIGN_TOP,marge)
        sizer_1.Add(self.ctrl1, 1, wx.LEFT|wx.ALIGN_TOP,marge)
        sizer_1.Add(self.combo3, 1, wx.LEFT|wx.ALIGN_TOP,marge)
        sizer_1.Add(self.ctrl2, 1, wx.LEFT|wx.ALIGN_TOP,marge)
        self.SetBackgroundColour(wx.WHITE)
        self.SetSizer(sizer_1)
        self.Layout()
        self.CentreOnScreen()

    def OnBoutonActionCombo1(self, event):
        #Bouton Test
        print("Bonjour l'action OnBoutonActionCombo1 de l'appli")
        self.combo1.btn.SetLabel("Clic")

    def OnBoutonActionCombo2(self, event):
        #Bouton Test
        print("Bonjour l'action OnBoutonActionCombo2 de l'appli")
        self.combo2.ctrl.Set(["Crack","boum","hue"])
        self.combo2.ctrl.SetSelection (0)

    def OnBoutonActionTexte2(self, event):
        #Bouton Test
        print("Bonjour l'action OnBoutonActionCombo2 de l'appli")
        wx.MessageBox("Houston nous avons un problème!",style=wx.OK)
        self.ctrl2.ctrl.SetValue("corrigez")

if __name__ == '__main__':
    app = wx.App(0)
    dictActions = {'saisieNbre':"wx.MessageBox('Savez-vous ce que vous voulez?)",}
    dictDonnees = {'memoriser': 2, 'ouiNon': False, 'monTexte': "élève", 'choix': ["choix2", "choix3"]}
    dictMatrice = {
        # Chapitre  = categorie ou box verticale
        "Mémorisation": [
            # Alinea 11 = ligne dans la box
            {'genre': 'Enum', 'name': 'memoriser', 'label': 'Mémoriser les paramètres', 'value': 3,
             'labels': ["Non", "Oui", "Peut-être"], 'values': [0, 1, 3],
             'help': 'Faut-il mémoriser les paramètres?'},
            # Alinea 12
            {'genre': 'Dir', 'name': 'repertoire', 'label': 'Choix du répertoire', 'value': '',
             'help': 'Veuillez choisir le répertoire'},
        ],
        # Chapitre 2
        "Autres éléments": [
            # Alinea 21 et suivants
            {'genre': 'Bool', 'name': 'ouiNon', 'label': 'Etes-vous oui ou non', 'value': True,
                'help': 'Cochez pour le oui'},
            {'genre': 'String', 'name': 'monTexte', 'label': 'Saisir un ctrl', 'value': '',
                'help': 'Saisir votre ctrl'},
            {'genre': 'Int', 'name': 'entier', 'label': 'Saisir un entier', 'value': 0,
                'help': 'Saisir votre nombre entier'},
            {'genre': 'Float', 'name': 'saisieNbre', 'label': 'Saisir un nombre réel', 'value': 0.0,
                'help': 'Saisir votre nombre réel', 'btnLabel':' ! ', 'btnHelp':'Là vous pouvez lancer une action par clic', 'btnAction' : 'OnClicFloat','ctrlAction' : 'OnEnterFloat'},
            {'genre': 'Colour', 'name': 'couleur', 'label': 'Choisir votre couleur', 'value': wx.Colour(255, 0, 0),
                'help': 'Saisir votre couleur préférée','btnLabel': None, 'btnHelp': None},
            {'genre': 'MultiChoice', 'name': 'choix', 'label': 'Choix multiples', 'value': [],
                'labels': ["choix 1", "choix 2", "choix3"]},
        ]
    }
    frame_1 = xFrame(None, matrice=dictMatrice, donnees=dictDonnees)
    frame_1.Position = (50,50)
    frame_2 = myFrame(None, )
    frame_2.Position = (500,300)
    app.SetTopWindow(frame_1)
    frame_2.Show()
    frame_1.Show()
    app.MainLoop()
