#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-
#------------------------------------------------------------------------
# Application :    Noethys, Matthania
# Auteur:           Ivan LUCAS, Jacques Brunel
# Licence:         Licence GNU GPL
# Ajout d'une gestion des Index Uniques et Cr�ation des tables 83
# Ouvre aDATA_Tables comme GestionDB ouvre DATA_Tables, acces SQL sans ID autoincrement
#------------------------------------------------------------------------

from UTILS_Traduction import _
import sqlite3
import datetime
import wx
import os
import random
import aDATA_Tables
import DATA_Tables
import aCTRL_ChoixListe
import aGestionArticle
#DATA_Tables contient toutes les tables matthania
DICT_CONNEXIONS = {}

# Import MySQLdb
try :
    import MySQLdb
    from MySQLdb.constants import FIELD_TYPE
    from MySQLdb.converters import conversions
    IMPORT_MYSQLDB_OK = True
except Exception, err :
    IMPORT_MYSQLDB_OK = False

# import mysql.connector
try :
    import mysql.connector
    from mysql.connector.constants import FieldType
    from mysql.connector import conversion
    IMPORT_MYSQLCONNECTOR_OK = True
except Exception, err :
    IMPORT_MYSQLCONNECTOR_OK = False
# Interface pour Mysql = "mysql.connector" ou "mysqldb"
# Est modifi� automatiquement lors du lancement de Noethys selon les pr�f�rences (Menu Param�trage > Pr�f�rences)
# Peut �tre �galement modifi� manuellement ici dans le cadre de tests sur des fichiers ind�pendamment de l'interface principale 
INTERFACE_MYSQL = "mysqldb"

def Supprime_accent(texte):
    liste = [ (u"�", u"e"), (u"�", u"e"), (u"�", u"e"), (u"�", u"e"), (u"�", u"a"), (u"�", u"u"), (u"�", u"o"), (u"�", u"c"), (u"�", u"i"), (u"�", u"i"),]
    for a, b in liste :
        texte = texte.replace(a, b)
        texte = texte.replace(a.upper(), b.upper())
    return texte

def SetInterfaceMySQL(nom="mysqldb"):
    """ Permet de s�lectionner une interface MySQL """
    global INTERFACE_MYSQL
    if nom == "mysqldb" and IMPORT_MYSQLDB_OK == True :
        INTERFACE_MYSQL = "mysqldb"
    if nom == "mysql.connector" and IMPORT_MYSQLCONNECTOR_OK == True :
        INTERFACE_MYSQL = "mysql.connector"

def ListeToStr(lst=[], separateur=", "):
    # Convertit une liste en texte
    chaine = separateur.join([str(x) for x in lst])
    if chaine == "": chaine = "*"
    return chaine

def DateEngEnDateDD(dateEng):
    return datetime.date(int(dateEng[:4]), int(dateEng[5:7]), int(dateEng[8:10]))

class DB():
    def __init__(self, suffixe="DATA", nomFichier="", modeCreation=False, IDconnexion=None):
        """ Utiliser GestionDB.DB(suffixe="PHOTOS") pour acc�der � un fichier utilisateur """
        """ Utiliser GestionDB.DB(nomFichier="Geographie.dat", suffixe=None) pour ouvrir un autre type de fichier """
        self.nomFichier = nomFichier
        self.modeCreation = modeCreation
        self.lstIndex=[]
        # M�morisation de l'ouverture de la connexion et des requ�tes
        if IDconnexion == None :
            self.IDconnexion = random.randint(0, 1000000)
        else :
            self.IDconnexion = IDconnexion
        DICT_CONNEXIONS[self.IDconnexion] = []
        
        # Si aucun nom de fichier n'est sp�cifi�, on recherche celui par d�faut dans le Config.dat
        if self.nomFichier == "" :
            self.nomFichier = self.GetNomFichierDefaut()
        
        if "[RESEAU]" in self.nomFichier :
            self.isNetwork = True
            suffixe = suffixe.lower()
        else :
            self.isNetwork = False

        # On ajoute le pr�fixe de type de fichier et l'extension du fichier
        if suffixe != None :
            self.nomFichier += u"_%s" % suffixe
        
        # Est-ce une connexion Local ?
        if self.isNetwork == False :
            if suffixe != None :
                self.nomFichier = u"Data/%s.dat" % self.nomFichier
        
        # Ouverture de la base de donn�es
        if self.isNetwork == True :
            self.OuvertureFichierReseau(self.nomFichier, suffixe)
        else:
            self.OuvertureFichierLocal(self.nomFichier)

    def GetNomPosteReseau(self):
        if self.isNetwork == False :
            return None
        return self.GetParamConnexionReseau()["user"]
        
    def OuvertureFichierLocal(self, nomFichier):
        """ Version LOCALE avec SQLITE """
        # V�rifie que le fichier sqlite existe bien
        if self.modeCreation == False :
            if os.path.isfile(nomFichier)  == False :
                #print "Le fichier SQLITE demande n'est pas present sur le disque dur."
                self.echec = 1
                return
        # Initialisation de la connexion
        try :
            self.connexion = sqlite3.connect(nomFichier.encode('utf-8'))
            self.cursor = self.connexion.cursor()
        except Exception, err:
            print "La connexion avec la base de donnees SQLITE a echouee : \nErreur detectee :%s" % err
            self.erreur = err
            self.echec = 1
        else:
            self.echec = 0
    
    def GetParamConnexionReseau(self):
        """ R�cup�ration des param�tres de connexion si fichier MySQL """
        pos = self.nomFichier.index("[RESEAU]")
        paramConnexions = self.nomFichier[:pos]
        port, host, user, passwd = paramConnexions.split(";")
        nomFichier = self.nomFichier[pos:].replace("[RESEAU]", "")
        nomFichier = nomFichier.lower() 
        dictDonnees = {"port":int(port), "hote":host, "host":host, "user":user, "utilisateur":user, "mdp":passwd, "password":passwd, "fichier":nomFichier}
        return dictDonnees

    def OuvertureFichierReseau(self, nomFichier, suffixe):
        """ Version RESEAU avec MYSQL """
        try :
            # R�cup�ration des param�tres de connexion
            pos = nomFichier.index("[RESEAU]")
            paramConnexions = nomFichier[:pos]
            port, host, user, passwd = paramConnexions.split(";")
            nomFichier = nomFichier[pos:].replace("[RESEAU]", "")
            nomFichier = nomFichier.lower() 
            
            # Info sur connexion MySQL
            #print "IDconnexion=", self.IDconnexion, "Interface MySQL =", INTERFACE_MYSQL
            
            # Connexion MySQL
            if INTERFACE_MYSQL == "mysqldb" :
                my_conv = conversions
                my_conv[FIELD_TYPE.LONG] = int
                self.connexion = MySQLdb.connect(host=host,user=user, passwd=passwd, port=int(port), use_unicode=True, conv=my_conv) # db=dbParam, 
                self.connexion.set_character_set('utf8')
                
            if INTERFACE_MYSQL == "mysql.connector" :
                self.connexion = mysql.connector.connect(host=host, user=user, passwd=passwd, port=int(port), use_unicode=True, pool_name="mypool2%s" % suffixe, pool_size=3)
    
            self.cursor = self.connexion.cursor()

            # Cr�ation
            if self.modeCreation == True :
                self.cursor.execute("CREATE DATABASE IF NOT EXISTS %s CHARSET utf8 COLLATE utf8_unicode_ci;" % nomFichier)
            
            # Utilisation
            if nomFichier not in ("", None, "_data") :
                self.cursor.execute("USE %s;" % nomFichier)
            
        except Exception, err:
            print "La connexion avec la base de donnees MYSQL a echouee. Erreur :"
            print (err,)
            self.erreur = err
            self.echec = 1
            #AfficheConnexionOuvertes() 
        else:
            self.echec = 0
    
    def GetNomFichierDefaut(self):
        nomFichier = ""
        try :
            topWindow = wx.GetApp().GetTopWindow()
            nomWindow = topWindow.GetName()
        except :
            nomWindow = None
        if nomWindow == "general" : 
            # Si la frame 'General' est charg�e, on y r�cup�re le dict de config
            nomFichier = topWindow.userConfig["nomFichier"]
        else:
            # R�cup�ration du nom de la DB directement dans le fichier de config sur le disque dur
            import UTILS_Config
            nomFichierConfig = "Data/Config.dat"
            cfg = UTILS_Config.FichierConfig(nomFichierConfig)
            nomFichier = cfg.GetItemConfig("nomFichier")
        return nomFichier

    def ComposeListeChamps(self,listeDonnees, separateur):
        champs = ""
        valeurs = []
        for donnee in listeDonnees:
            if self.isNetwork == True :
                # Version MySQL
                champs = champs + donnee[0] + "=%s" + separateur
            else:
                # Version Sqlite
                champs = champs + donnee[0] + "=?" + separateur
            valeurs.append(donnee[1])
        champs = champs[:-2]
        # pour la  composition de cl�s, le s�parateur peut �tre ' AND '
        if len(separateur) == 5 : champs = champs[:-3]
        return champs,valeurs

    def ReqInsert(self, nomTable="", listeDonnees=[], commit=True, retourID=None, MsgBox=None):
        """ Permet d'ins�rer des donn�es dans une table """
        #retourID none : retourne l'ID, True : retourne 'ok' et g�re self.newID, False : retourne 'ok'
        # Pr�paration des donn�es
        if retourID == None:   modeRetour = 1
        elif retourID == True: modeRetour = 2
        else :                 modeRetour = 3
        champs = "("
        interr = "("
        valeurs = []
        for donnee in listeDonnees:
            champs = champs + donnee[0] + ", "
            if self.isNetwork == True :
                # Version MySQL
                interr = interr + "%s, "
            else:
                # Version Sqlite
                interr = interr + "?, "
            valeurs.append(donnee[1])
        champs = champs[:-2] + ")"
        interr = interr[:-2] + ")"
        req = "INSERT INTO %s %s VALUES %s" % (nomTable, champs, interr)
        retourReq = "ok"
        self.newID= 0
        try:
            # Enregistrement
            self.cursor.execute(req, tuple(valeurs))
            if commit == True :
                self.Commit()
            # R�cup�ration de l'ID
            if modeRetour in [1,2]:
                if self.isNetwork == True :
                    # Version MySQL
                    self.cursor.execute("SELECT LAST_INSERT_ID();")
                else:
                    # Version Sqlite
                    self.cursor.execute("SELECT last_insert_rowid() FROM %s" % nomTable)
                self.newID = self.cursor.fetchall()[0][0]
        except Exception, err:
            retourReq= "Requete sql d'INSERT incorrecte :\n%s\nErreur detectee:\n%s" % (req, err)
            if MsgBox != None:
                msg = Messages()
                msg.Box(titre = "Erreur aGestionDB : " + MsgBox,message=retourReq)
                return
        if modeRetour in [1,3]:
            retour = retourReq
        else :
            retour = self.newID
            self.retour = retourReq
        # Retourne le message
        return retour

    def ReqMAJ(self, nomTable, listeDonnees, nomChampID, ID, IDestChaine=False, MsgBox = None):
        """ Permet d'ins�rer des donn�es dans une table """
        # Pr�paration des donn�es
        champs, valeurs = self.ComposeListeChamps(listeDonnees,", ")
        if IDestChaine == False and (type(ID)== int or type(ID)== long):
            req = "UPDATE %s SET %s WHERE %s=%d" % (nomTable, champs, nomChampID, ID)
        else:
            req = "UPDATE %s SET %s WHERE %s='%s'" % (nomTable, champs, nomChampID, ID)
        self.retourReq = "ok"
        # Enregistrement
        try:
            self.cursor.execute(req, tuple(valeurs))
            self.Commit()
        except Exception, err:
            self.retourReq= (u"Requete sql de mise a jour incorrecte :\n%s\nErreur detectee:\n%s") % (req, err)
            if MsgBox != None:
                msg = Messages()
                msg.Box(titre = "Erreur aGestionDB : " + MsgBox,message=self.retourReq)
                return
        return self.retourReq

    def ReqMAJcles(self, nomTable, listeDonnees, listeCles):
        """ Permet d'ins�rer des donn�es dans une table avec cl�s multiples """
        champs, valeurs = self.ComposeListeChamps(listeDonnees,", ")
        if isinstance(listeCles, (list, tuple)) :
            nomsCles, valeursCles =self.ComposeListeChamps(listeCles," and ")
            req = "UPDATE %s SET %s WHERE %s " % (nomTable, champs, nomsCles)
            for cle in valeursCles :
                valeurs.append(cle)
        else :
            self.retourReq = u"Liste cl� n'est pas une liste"
            return self.retourReq
        self.retourReq = "ok"
        # Enregistrement
        try:
            self.cursor.execute(req, tuple(valeurs))
            self.Commit()
        except Exception, err:
            self.retourReq= (u"Requete sql de mise a jour incorrecte :\n%s\nErreur detectee:\n%s") % (req, err)
        return self.retourReq

    def ReqDEL(self, nomTable="", nomChampID="", ID="", commit=True, MsgBox = False):
        """ Suppression d'un enregistrement """
        self.retourReq = "ok"
        if ID <> None:
            if type(ID) == int :
               req = "DELETE FROM %s WHERE %s=%d" % (nomTable, nomChampID, ID)
            elif type(ID) == long :
               req = "DELETE FROM %s WHERE %s=%d" % (nomTable, nomChampID, ID)
            else :
                if ID[:1] <> "'" :
                    ID = "'"+ID+"'"
                req = "DELETE FROM %s WHERE %s= %s" % (nomTable, nomChampID, ID)
            try:
                self.cursor.execute(req)
                if commit == True :
                    self.Commit()
            except Exception, err:
                self.retourReq =  _(u"Requete sql de suppression incorrecte :\n%s\nErreur detectee:\n%s") % (req, err)
                if MsgBox != None:
                    msg = Messages()
                    msg.Box(titre = "Erreur aGestionDB : " + MsgBox,message=self.retourReq)
                    return
        return self.retourReq

    def ReqSelect(self, nomTable, conditions, MsgBox = None):
        """ Permet d'appeler des donn�es d'une seule table selon conditions """
        req = "SELECT *  FROM %s WHERE %s " % (nomTable, conditions)
        self.retourReq = "ok"
        # Enregistrement
        try:
            self.cursor.execute(req)
            self.Commit()
        except Exception, err:
            self.retourReq= (u"Requete ReqSelect incorrecte :\n%s\nErreur detectee:\n%s") % (req, err)
            if MsgBox != None:
                msg = Messages()
                msg.Box(titre = "Erreur aGestionDB : " + MsgBox,message=self.retourReq)
                return
        return self.retourReq

    def ExecuterReq(self, req, commit=True, MsgBox = None):
        # Pour parer le pb des () avec MySQL
        if self.isNetwork == True :
            req = req.replace("()", "(10000000, 10000001)")
        try:
            self.retourReq = "ok"
            self.cursor.execute(req)
            DICT_CONNEXIONS[self.IDconnexion].append(req)
            if commit: self.Commit()
        except Exception, err:
            try :
                req = str(req)
            except: req=str(req.encode('UTF-8'))
            self.retourReq =  _(u"Requete SQL incorrecte :\n%s\nErreur detectee:\n%s") % (req, err)
            if MsgBox != None:
                if not isinstance(MsgBox, str):
                    texte = str(MsgBox)
                else: texte = MsgBox
                msg = Messages()
                msg.Box(titre = "Erreur aGestionDB : " + texte,message=self.retourReq)
                return
        # Retourne le message
        return self.retourReq

    def Executermany(self, req="", listeDonnees=[], commit=True):
        """ Executemany pour local ou r�seau """
        """ Exemple de req : "INSERT INTO table (IDtable, nom) VALUES (?, ?)" """
        """ Exemple de listeDonnees : [(1, 2), (3, 4), (5, 6)] """
        # Adaptation r�seau/local
        if self.isNetwork == True :
            # Version MySQL
            req = req.replace("?", "%s")
        else:
            # Version Sqlite
            req = req.replace("%s", "?")
        # Executemany
        self.cursor.executemany(req, listeDonnees)
        if commit == True :
            self.connexion.commit()

    def ResultatReq(self):
        if self.echec == 1 : return []
        resultat = self.cursor.fetchall()
        try :
            # Pour contrer MySQL qui fournit des tuples alors que SQLITE fournit des listes
            if self.isNetwork == True and type(resultat) == tuple :
                resultat = list(resultat)
        except :
            pass
        return resultat

    def GetProchainID(self, nomTable=""):
        if self.isNetwork == False :
            # Version Sqlite
            req = "SELECT seq FROM sqlite_sequence WHERE name='%s';" % nomTable
            self.ExecuterReq(req)
            donnees = self.ResultatReq()

            # Renvoie le prochain ID
            if len(donnees) > 0 :
                return donnees[0][0] + 1

        else:
            # Version MySQL
            self.ExecuterReq("USE information_schema;")
            pos = self.nomFichier.index("[RESEAU]")
            nomFichier = self.nomFichier[pos:].replace("[RESEAU]", "")
            req = "SELECT auto_increment FROM tables WHERE table_schema='%s' and table_name='%s' ;" % (nomFichier, nomTable)
            self.ExecuterReq(req)
            donnees = self.ResultatReq()

            # Se remet sur le fichier normal
            if nomFichier not in ("", None, "_data") :
                self.ExecuterReq("USE %s;" % nomFichier)

            # Renvoie le prochain ID
            if len(donnees) > 0 :
                return donnees[0][0]

        return 1

    def AfficheErr(self,parent,retour):
        dlgErr = wx.MessageDialog(parent, _(retour), _(u"Retour SQL !"), wx.OK | wx.ICON_EXCLAMATION)
        dlgErr.ShowModal()
        dlgErr.Destroy()
        return

    def Commit(self):
        if self.connexion:
            self.connexion.commit()

    def Close(self):
        try :
            self.connexion.close()
            del DICT_CONNEXIONS[self.IDconnexion]
            #print "Fermeture connexion ID =", self.IDconnexion
        except :
            pass

    def IsTableExists(self, nomTable=""):
        """ V�rifie si une table donn�e existe dans la base """
        tableExists = False
        for (nomTableTmp,) in self.GetListeTables() :
            if nomTableTmp == nomTable :
                tableExists = True
        return tableExists

    def IsIndexExists(self, nomIndex=""):
        """ V�rifie si un index existe dans la base """
        indexExists = False
        if self.lstIndex == []:
            self.lstIndex = self.GetListeIndex()
        if nomIndex in self.lstIndex :
            indexExists = True
        return indexExists
                        
    def GetListeTables(self):
        if self.isNetwork == False :
            # Version Sqlite
            req = "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;"
            self.ExecuterReq(req)
            listeTables = self.ResultatReq()
        else:
            # Version MySQL
            req = "SHOW TABLES;"
            self.ExecuterReq(req)
            listeTables = self.ResultatReq()
        return listeTables

    def GetListeChamps(self):
        """ Affiche la liste des champs de la pr�c�dente requ�te effectu�e """
        liste = []
        for fieldDesc in self.cursor.description:
            liste.append(fieldDesc[0])
        return liste

    def GetListeChamps2(self, nomTable=""):
        """ Affiche la liste des champs de la table donn�e """
        listeChamps = []
        if self.isNetwork == False :
            # Version Sqlite
            req = "PRAGMA table_info('%s');" % nomTable
            self.ExecuterReq(req)
            listeTmpChamps = self.ResultatReq()
            for valeurs in listeTmpChamps :
                listeChamps.append( (valeurs[1], valeurs[2]) )
        else:
            # Version MySQL
            req = "SHOW COLUMNS FROM %s;" % nomTable
            self.ExecuterReq(req)
            listeTmpChamps = self.ResultatReq()
            for valeurs in listeTmpChamps :
                listeChamps.append( (valeurs[0], valeurs[1]) )
        return listeChamps
                        
    def GetListeIndex(self):
        if self.isNetwork == False :
            # Version Sqlite
            req = "SELECT name FROM sqlite_master WHERE type='index' ORDER BY name;"
            self.ExecuterReq(req)
            listeIndex = self.ResultatReq()
        else:
            # Version MySQL
            listeIndex = []
            for table in self.GetListeTables():
                req = "SHOW INDEX IN %s;" %str(table[0])
                self.ExecuterReq(req)
                for index in self.ResultatReq():
                    if str(index[2]) != 'PRIMARY':
                        listeIndex.append(str(index[2]))
        return listeIndex

    def SupprChamp(self, nomTable="", nomChamp = ""):
        """ Suppression d'une colonne dans une table """
        if self.isNetwork == False :
            # Version Sqlite

            # Recherche des noms de champs de la table
    ##        req = """
    ##        SELECT sql FROM sqlite_master
    ##        WHERE name='%s'
    ##        """ % nomTable
    ##        self.ExecuterReq(req)
    ##        reqCreate = self.ResultatReq()[0][0]
    ##        posDebut = reqCreate.index("(")+1
    ##        champs = reqCreate[posDebut:-1]
    ##        listeChamps = champs.split(", ")

            listeChamps = self.GetListeChamps2(nomTable)

            index = 0
            varChamps = ""
            varNomsChamps = ""
            for nomTmp, typeTmp in listeChamps :
                if nomTmp == nomChamp :
                    listeChamps.pop(index)
                    break
                else:
                    varChamps += "%s %s, " % (nomTmp, typeTmp)
                    varNomsChamps += nomTmp + ", "
                index += 1
            varChamps = varChamps[:-2]
            varNomsChamps = varNomsChamps[:-2]

            # Proc�dure de mise � jour de la table
            req = ""
            req += "BEGIN TRANSACTION;"
            req += "CREATE TEMPORARY TABLE %s_backup(%s);" % (nomTable, varChamps)
            req += "INSERT INTO %s_backup SELECT %s FROM %s;" % (nomTable, varNomsChamps, nomTable)
            req += "DROP TABLE %s;" % nomTable
            req += "CREATE TABLE %s(%s);" % (nomTable, varChamps)
            req += "INSERT INTO %s SELECT %s FROM %s_backup;" % (nomTable, varNomsChamps, nomTable)
            req += "DROP TABLE %s_backup;" % nomTable
            req += "COMMIT;"
            self.cursor.executescript(req)

        else:
            # Version MySQL
            req = "ALTER TABLE %s DROP %s;" % (nomTable, nomChamp)
            self.ExecuterReq(req)
            self.Commit()

    def AjoutChamp(self, nomTable = "", nomChamp = "", typeChamp = ""):
        req = "ALTER TABLE %s ADD %s %s;" % (nomTable, nomChamp, typeChamp)
        self.ExecuterReq(req)
        self.Commit()

    def ReparationTable(self, nomTable="", dicoDB=DATA_Tables.DB_DATA):
        """ R�paration d'une table (re-cr�ation de la table) """
        if self.isNetwork == False :
            # R�cup�ration des noms et types de champs
            listeChamps = []
            listeNomsChamps = []
            for descr in dicoDB[nomTable]:
                nomChamp = descr[0]
                typeChamp = descr[1]
                if self.isNetwork == False and typeChamp == "LONGBLOB" : typeChamp = "BLOB"
                listeChamps.append("%s %s" % (nomChamp, typeChamp))
                listeNomsChamps.append(nomChamp)
            varChamps = ", ".join(listeChamps)
##            varNomsChamps = ", ".join(listeNomsChamps)

            # Proc�dure de mise � jour de la table
##            req = "BEGIN TRANSACTION;"
##            req += "CREATE TEMPORARY TABLE %s_backup(%s);" % (nomTable, varChamps)
##            req += "INSERT INTO %s_backup SELECT %s FROM %s;" % (nomTable, ", ".join(listeNomsChamps[1:]), nomTable)
##            req += "DROP TABLE %s;" % nomTable
##            req += "CREATE TABLE %s(%s);" % (nomTable, varChamps)
##            req += "INSERT INTO %s SELECT %s FROM %s_backup;" % (nomTable, ", ".join(listeNomsChamps[1:]), nomTable)
##            req += "DROP TABLE %s_backup;" % nomTable
##            req += "COMMIT;"

            # Cr�ation de la table temporaire
            req = "BEGIN TRANSACTION;"
            req += "CREATE TEMPORARY TABLE %s_backup(%s);" % (nomTable, varChamps.replace(" PRIMARY KEY AUTOINCREMENT", ""))
            req += "INSERT INTO %s_backup SELECT %s FROM %s;" % (nomTable, ", ".join(listeNomsChamps), nomTable)
            req += "DROP TABLE %s;" % nomTable
            req += "CREATE TABLE %s(%s);" % (nomTable, varChamps)
            req += "COMMIT;"
            self.cursor.executescript(req)

            # Copie des donn�es dans la table temporaire
            req = "SELECT %s FROM %s_backup;" % (", ".join(listeNomsChamps[1:]), nomTable)
            self.cursor.execute(req)
            listeDonnees = self.cursor.fetchall()

            for ligne in listeDonnees :
                temp = []
                for x in range(0, len(ligne)) :
                    temp.append("?")
                req = "INSERT INTO %s (%s) VALUES (%s)" % (nomTable, ", ".join(listeNomsChamps[1:]), ", ".join(temp))
                self.cursor.execute(req, ligne)
                self.Commit()

            # Suppression de la table temporaire
            self.cursor.execute("DROP TABLE %s_backup;" % nomTable)
            self.Commit()

            print "Reparation de la table '%s' terminee." % nomTable

    def Importation_table_reseau(self, nomTable="", nomFichier="", dictTables={}):
        """ Importe toutes les donn�es d'une table donn�e dans un fichier r�seau """
        import cStringIO

        # Ouverture de la base r�seau
        try :
            # R�cup�ration des param�tres de connexion
            pos = nomFichier.index("[RESEAU]")
            paramConnexions = nomFichier[:pos]
            port, host, user, passwd = paramConnexions.split(";")
            nomFichier = nomFichier[pos:].replace("[RESEAU]", "")
            nomFichier = nomFichier.lower()

            # Connexion MySQL
            if INTERFACE_MYSQL == "mysqldb" :
                my_conv = conversions
                my_conv[FIELD_TYPE.LONG] = int
                connexionDefaut = MySQLdb.connect(host=host,user=user, passwd=passwd, port=int(port), use_unicode=True, conv=my_conv) # db=dbParam,
                connexionDefaut.set_character_set('utf8')

            if INTERFACE_MYSQL == "mysql.connector" :
                connexionDefaut = mysql.connector.connect(host=host, user=user, passwd=passwd, port=int(port), use_unicode=True, pool_name="mypool4%s" % suffixe, pool_size=3)

            cursor = connexionDefaut.cursor()

            # Ouverture Database
            cursor.execute("USE %s;" % nomFichier)

        except Exception, err:
            print "La connexion avec la base de donnees MYSQL a importer a echouee : \nErreur detectee :%s" % err
            erreur = err
            echec = 1
        else:
            echec = 0

        # Recherche des noms de champs de la table
        req = "SELECT * FROM %s" % nomTable
        cursor.execute(req)
        listeDonneesTmp = cursor.fetchall()
        listeChamps = []
        for fieldDesc in cursor.description:
            listeChamps.append(fieldDesc[0])

        # Pr�paration des noms de champs pour le transfert
        txtChamps = "("
        txtQMarks = "("
        for nomChamp in listeChamps[0:] :
            txtChamps += nomChamp + ", "
            txtQMarks += "?, "
        txtChamps = txtChamps[:-2] + ")"
        txtQMarks = txtQMarks[:-2] + ")"

        # R�cup�ration des donn�es
        listeDonnees = []
        for donnees in listeDonneesTmp :
            # Analyse des donn�es pour trouver les champs BLOB
            numColonne = 0
            listeValeurs = []
            for donnee in donnees[0:] :
                typeChamp = dictTables[nomTable][numColonne][1]
                if typeChamp == "BLOB" or typeChamp == "LONGBLOB" :
                    if donnee != None :
                        donnee = sqlite3.Binary(donnee)
                if typeChamp == "blob" or typeChamp == "longblob" :
                    if donnee != None :
                        donnee = Decod(donnee)
                listeValeurs.append(donnee)
                numColonne += 1
            listeDonnees.append(tuple(listeValeurs))

        # Importation des donn�es vers la nouvelle table
        req = "INSERT INTO %s %s VALUES %s" % (nomTable, txtChamps, txtQMarks)
        self.cursor.executemany(req, listeDonnees)
        self.connexion.commit()

    def ConversionTypeChamp(self, nomTable="", nomChamp="", typeChamp=""):
        """ Pour convertir le type d'un champ """
        """ Ne fonctionne qu'avec MySQL """
        if self.isNetwork == True :
            req = "ALTER TABLE %s CHANGE %s %s %s;" % (nomTable, nomChamp, nomChamp, typeChamp)
            self.ExecuterReq(req)

    def Exportation_vers_base_defaut(self, nomTable="", nomFichierdefault="Defaut.dat"):
        """ Exporte toutes les donn�es d'une table donn�e vers la base d�faut """
        """ ATTENTION, la TABLE d�faut sera supprim�e !!! """
        # Ouverture de la base par d�faut
        connexionDefaut = sqlite3.connect(nomFichierdefault.encode('utf-8'))
        cursorDefaut = connexionDefaut.cursor()

        # Supprime la table
        cursorDefaut.execute("DROP TABLE IF EXISTS %s;" % nomTable)

        # Cr�ation de la table dans la base DEFAUT si elle n'existe pas
        req = "SELECT name FROM sqlite_master WHERE type='table' AND name='%s';" % nomTable
        cursorDefaut.execute(req)
        listeTemp = cursorDefaut.fetchall()
        if len(listeTemp) == 0 :
            req = "CREATE TABLE %s (" % nomTable
            pk = ""
            for descr in DATA_Tables.DB_DATA[nomTable]:
                nomChamp = descr[0]
                typeChamp = descr[1]
                if self.isNetwork == False and typeChamp == "LONGBLOB" : typeChamp = "BLOB"
                req = req + "%s %s, " % (nomChamp, typeChamp)
            req = req[:-2] + ")"
            cursorDefaut.execute(req)

        # Recherche des noms de champs de la table
        listeChamps = self.GetListeChamps2(nomTable)

        # R�cup�ration des donn�es � exporter
        req = "SELECT * FROM %s" % nomTable
        self.ExecuterReq(req)
        listeDonnees = self.ResultatReq()

        # Pr�paration des noms de champs pour le transfert
        txtChamps = "("
        txtQMarks = "("
        for nomChamp, typeChamp in listeChamps :
            txtChamps += nomChamp + ", "
            txtQMarks += "?, "
        txtChamps = txtChamps[:-2] + ")"
        txtQMarks = txtQMarks[:-2] + ")"

        # R�cup�ration des donn�es
        listeDonnees2 = []
        for donnees in listeDonnees :
            listeDonnees2.append(donnees[0:])

        # Importation des donn�es vers la nouvelle table
        req = "INSERT INTO %s %s VALUES %s" % (nomTable, txtChamps, txtQMarks)
        cursorDefaut.executemany(req, listeDonnees2)
        connexionDefaut.commit()
        connexionDefaut.close()

    def CreationTables(self, dicoDB={}, fenetreParente=None):
        for table in dicoDB:
            retour = self.CreationUneTable(dicoDB=dicoDB,table=table,fenetreParente=fenetreParente)
            print table, "-----------/-------------",retour
        #fin CreationTables

    def CreationUneTable(self, dicoDB={},table=None, fenetreParente=None):
        retour = None
        if table == None : return retour
        if not self.IsTableExists(table) :
            # Affichage dans la StatusBar
            if fenetreParente != None :
                fenetreParente.SetStatusText(_(u"Cr�ation de la table de donn�es %s...") % table)
            req = "CREATE TABLE %s (" % table
            for descr in dicoDB[table]:
                nomChamp = descr[0]
                typeChamp = descr[1]
                # Adaptation � Sqlite
                if self.isNetwork == False and typeChamp == "LONGBLOB" : typeChamp = "BLOB"
                # Adaptation � MySQL :
                if self.isNetwork == True and typeChamp == "INTEGER PRIMARY KEY AUTOINCREMENT" : typeChamp = "INTEGER PRIMARY KEY AUTO_INCREMENT"
                if self.isNetwork == True and typeChamp == "FLOAT" : typeChamp = "REAL"
                if self.isNetwork == True and typeChamp == "DATE" : typeChamp = "VARCHAR(10)"
                if self.isNetwork == True and typeChamp.startswith("VARCHAR") :
                    nbreCaract = int(typeChamp[typeChamp.find("(")+1:typeChamp.find(")")])
                    if nbreCaract > 255 :
                        typeChamp = "TEXT(%d)" % nbreCaract
                    if nbreCaract > 20000 :
                        typeChamp = "MEDIUMTEXT"
                # ------------------------------
                req = req + "%s %s, " % (nomChamp, typeChamp)
            req = req[:-2] + ")"
            retour = self.ExecuterReq(req)
            if retour == "ok":
                    self.Commit()
        return retour
            #fin CreationUneTable

    def CreationIndex(self,nomIndex="",listeIndex={}):
        """ Cr�ation d'un index """
        nomTable = listeIndex[nomIndex]["table"]
        nomChamp = listeIndex[nomIndex]["champ"]

        if self.IsTableExists(nomTable) :
            #print "Creation de l'index : %s" % nomIndex
            if nomIndex[:2] == "PK":
                req = "CREATE UNIQUE INDEX %s ON %s (%s);" % (nomIndex, nomTable, nomChamp)
            else :
                req = "CREATE INDEX %s ON %s (%s);" % (nomIndex, nomTable, nomChamp)
            retour = self.ExecuterReq(req)
            print nomIndex, "-----------/-------------",retour
            if retour == "ok":
                    self.Commit()

    def CreationTousIndex(self,dictIndex):
        """ Cr�ation de tous les index """
        for nomIndex, temp in dictIndex.iteritems() :
            if not self.IsIndexExists(nomIndex) :
                self.CreationIndex(nomIndex,dictIndex)

    def ConversionDB(self, versionFichier=(0, 0, 0, 0) ) :
        """ Adapte un fichier obsol�te � la version actuelle du logiciel """
        # =============================================================
        #laiss� � titre d'exemple
        versionFiltre = (1, 1, 2, 3)
        if versionFichier < versionFiltre :
            try :
                self.AjoutChamp("unites", "coeff", "VARCHAR(50)")
                #------------
                import UTILS_Procedures
                UTILS_Procedures.A8260()
                #------------
                if self.isNetwork == True :
                    self.ExecuterReq("ALTER TABLE parametres MODIFY COLUMN parametre TEXT;")
                    self.Commit()
                #------------
            except Exception, err :
                return " filtre de conversion %s | " % ".".join([str(x) for x in versionFiltre]) + str(err)

        # =============================================================

        versionFiltre = (1, 2, 4, 117)
        if versionFichier < versionFiltre :
            try :
                Ajout_TablesMat()
                Ajout_IndexMat()
            except Exception, err :
                return " filtre de conversion %s | " % ".".join([str(x) for x in versionFiltre]) + str(err)

        # =============================================================

        versionFiltre = (1, 2, 4, 75)
        if versionFichier < versionFiltre :
            try :
                Ajout_IndexMat()
                self.AjoutChamp("types_groupes_activites", "anaTransports", "VARCHAR(8)")
            except Exception, err :
                return " filtre de conversion %s | " % ".".join([str(x) for x in versionFiltre]) + str(err)

        # =============================================================

        versionFiltre = (1, 2, 4, 75)
        if versionFichier < versionFiltre :
            try :
                if self.IsTableExists("matConvois") == True :
                    print "supprime index matConvois ------",
                    req = """DROP INDEX PK_matConvois_cnvDteLigSens ON matConvois"""
                    retour = self.ExecuterReq(req)
                    if retour == "ok" : print "--------- ok"
                    else :
                        msg = Messages()
                        msg.Box(titre = u"GetParam",message = retour)
                    print "supprime table matConvois ------",
                    req = """DROP TABLE matConvois"""
                    retour = self.ExecuterReq(req)
                    if retour == "ok" : print "--------- ok"
                    #"PK_matConvois_cnvDteLigSens"  :  {"table"  :  "matConvois",  "champ" : "cnvDate,cnvIDligne,cnvSens", },

            except Exception, err :
                return " filtre de conversion %s | " % ".".join([str(x) for x in versionFiltre]) + str(err)

        # =============================================================

        versionFiltre = (1, 2, 4, 70)
        if versionFichier < versionFiltre :
            try :
                self.AjoutChamp("reglements", "compta", "INTEGER")
                self.AjoutChamp("matPieces", "pieComptaFac", "INTEGER")
                self.AjoutChamp("matPieces", "pieComptaAvo", "INTEGER")
                self.AjoutChamp("prestations", "compta", "INTEGER")
                self.AjoutChamp("inscriptions", "jours", "INTEGER")
            except Exception, err :
                return " filtre de conversion %s | " % ".".join([str(x) for x in versionFiltre]) + str(err)

        # =============================================================

        versionFiltre = (1, 2, 5, 2)
        if versionFichier < versionFiltre :
            try :
                Ajout_TablesMat()
            except Exception, err :
                return " filtre de conversion %s | " % ".".join([str(x) for x in versionFiltre]) + str(err)
        # =============================================================

        return True

    def GetParam(self, param = None, type= "string",user= None):
        if user == None:
            user = self.UtilisateurActuel()
        if user == None : user = "NoName"
        self.type = "prm" + type[0].upper() + type[1:]
        if user == None : user = "NoName"
        req = "SELECT " + self.type + " FROM matParams WHERE prmUser = '" + user + "' and prmParam = '" + param +"';"
        retour = self.ExecuterReq(req)
        if retour <> "ok" :
            msg = Messages()
            msg.Box(titre = u"GetParam",message = retour)
        recordset = self.ResultatReq()
        value = None
        if len(recordset)>0 :
            if len(recordset[0])>0 :
                value = recordset[0][0]
        return value

    def SetParam(self, param= None, value= None, type= "string", user= None, unique=False):
        if user == None:
            user = self.UtilisateurActuel()
        if user == None : user = "NoName"
        self.type = "prm" + type[0].upper() + type[1:]
        table = "matParams"
        if unique:
            #suppression avant insertion
            req = """DELETE FROM %s WHERE prmUser = '%s' AND prmParam = '%s' ;""" % (table, user, param)
            try:
                self.cursor.execute(req)
                self.Commit()
            except Exception, err:
                pass
        listeDonnees = []
        listeDonnees.append(("prmUser",user))
        listeDonnees.append(("prmParam", param))
        listeDonnees.append((self.type, value))
        retour = self.ReqInsert(table, listeDonnees,retourID = False)
        if retour == "ok" :
            self.Commit()
        return retour

    def SetAnnee(self, annee = None):
        if annee == None:
            import datetime
            annee = datetime.date().today().annee()
        retour= self.SetParam(param = "periodeAnnee",value=annee, type="string")
        return retour

    def GetAnnee(self):
        annee = str(self.GetParam("periodeAnnee","string"))
        if annee == None:
            self.SetAnnee()
        debut= str(annee + "-01-01")
        fin = str(annee + "-12-31")
        return annee, debut, fin

    def UtilisateurActuel(self):
        utilisateur = "NoName"
        try :
            topWindow = wx.GetApp().GetTopWindow()
            nomWindow = topWindow.GetName()
        except :
            nomWindow = None
        if nomWindow == "general" :
            # Si la frame 'General' est charg�e, on y r�cup�re le dict de config
            dictUtilisateur = topWindow.dictUtilisateur
            utilisateur = dictUtilisateur["prenom"] + " " + dictUtilisateur["nom"]
        return utilisateur

    def IDutilisateurActuel(self):
        IDutilisateur = 0
        try :
            topWindow = wx.GetApp().GetTopWindow()
            nomWindow = topWindow.GetName()
        except :
            nomWindow = None
        if nomWindow == "general" :
            # Si la frame 'General' est charg�e, on y r�cup�re le dict de config
            dictUtilisateur = topWindow.dictUtilisateur
            IDutilisateur = dictUtilisateur["IDutilisateur"]
        return IDutilisateur

    def GetNomIndividu(self,ID, first="prenom" ):
        if ID == None :
            value = " "
        else:
            if first == "prenom":
                select = "SELECT prenom, nom "
            else: select = "SELECT nom, prenom "
            form = "FROM individus "
            if type(ID) != str:
                where = """WHERE (individus.IDindividu = %s );""" % str(ID)
            else:
                where = """WHERE (individus.IDindividu = %s );""" % ID
            req = select + form + where

            retour = self.ExecuterReq(req)
            if retour <> "ok" :
                wx.MessageBox(str(retour))
            recordset = self.ResultatReq()
            value = " "
            if len(recordset)>0 :
                if len(recordset[0])>0 :
                    value = recordset[0][0] + " " + recordset[0][1]
        return value
        #   .encode('utf-8')

    def GetNomFamille(self,ID, first="prenom" ):
        if ID == None :
            value = " "
        else:
            if first == "prenom":
                select = "SELECT individus.prenom, individus.nom "
            else: select = "SELECT individus.nom, individus.prenom "
            form = "FROM individus INNER JOIN rattachements ON individus.IDindividu = rattachements.IDindividu "
            if type(ID) != str:
                where = """WHERE (rattachements.IDfamille = %s )""" % str(ID)
            else:
                where = """WHERE (rattachements.IDfamille = %s )""" % ID
            req = select + form + where + "ORDER BY rattachements.titulaire DESC , individus.IDcivilite;"
            retour = self.ExecuterReq(req)
            if retour <> "ok" :
                wx.MessageBox(str(retour))
            recordset = self.ResultatReq()
            value = " "
            if len(recordset)>0 :
                if len(recordset[0])>0 :
                    value = recordset[0][0] + " " + recordset[0][1]
        return value

    def GetNomActivite(self,ID):
        if ID == None :
            value = " "
        else:
            req = """SELECT nom
                    FROM activites
                    WHERE (IDactivite = %s );""" % ID
            retour = self.ExecuterReq(req)
            if retour <> "ok" :
                wx.MessageBox(str(retour))
            recordset = self.ResultatReq()
            value = " "
            if len(recordset)>0 :
                if len(recordset[0])>0 :
                    value = recordset[0][0]
        return value

    def GetNomGroupe(self,ID):
        if ID == None :
            value = " "
        else:
            req = """SELECT nom
                    FROM groupes
                    WHERE (IDgroupe = %s );""" % ID
            retour = self.ExecuterReq(req)
            if retour <> "ok" :
                wx.MessageBox(str(retour))
            recordset = self.ResultatReq()
            value = " "
            if len(recordset)>0 :
                if len(recordset[0])>0 :
                    value = recordset[0][0]
        return value

    def GetNomCategorieTarif(self,ID):
        if ID == None : Nom = "no name"
        req = """SELECT nom
                FROM categories_tarifs
                WHERE (IDcategorie_tarif = %s );""" % ID
        retour = self.ExecuterReq(req)
        if retour <> "ok" :
            wx.MessageBox(str(retour))
        recordset = self.ResultatReq()
        value = None
        if len(recordset)>0 :
            if len(recordset[0])>0 :
                value = recordset[0][0]
        return value

    def GetLastActivite(self,IDfamille):
        # recherche de la derni�re activite inscrite pour cette famille
        if IDfamille == None : return None
        IDactivite = None
        # recherche de la derni�re date de cr�ation de pi�ce niveau activit�
        req = """SELECT Max(pieDateCreation)
                FROM matPieces
                WHERE (((pieIDfamille)=%d) AND ((pieIDactivite)<>0));
                """ % IDfamille
        self.ExecuterReq(req,MsgBox = True)
        recordset = self.ResultatReq()
        if len(recordset)>0 :
            if len(recordset[0])>0 :
                DateCreation = recordset[0][0]
                # r�cup�ration d'un activit� � cette date
                req = """SELECT Max(pieIDactivite)
                        FROM matPieces
                        WHERE (((pieDateCreation)= '%s' ) AND ((pieIDactivite)<>0));
                        """ % DateCreation
                self.ExecuterReq(req,MsgBox = True)
                recordset = self.ResultatReq()
                if len(recordset)>0 :
                    if len(recordset[0])>0 :
                        IDactivite = recordset[0][0]
        return IDactivite

    def GetExercice(self,dateInput = None,labelDate = u"test�e",alertes = True,approche = False):
        # recherche la date d�but et fin d'exercice de dateInput
        if not isinstance(dateInput, datetime.date):
            mess = u"La valeur %s entr�e n'est pas une date : %s " % (labelDate,str(dateInput))
            if alertes : wx.MessageBox(mess)
            return (None,None)
        req = """SELECT date_debut, date_fin
                FROM compta_exercices
                """
        retour = self.ExecuterReq(req)
        if retour <> "ok" :
            wx.MessageBox(str(retour))
        recordset = self.ResultatReq()
        dateDebut = None
        dateFin = None
        lastDeb = None
        lastFin = datetime.date(1900,1,1)
        if len(recordset)>0 :
            for dd, df in recordset:
                ddebut = DateEngEnDateDD(dd)
                dfin = DateEngEnDateDD(df)
                if (ddebut <= dateInput) and (dfin >= dateInput) :
                    dateDebut = ddebut
                    dateFin = dfin
                if dfin >lastFin :
                    lastDeb = ddebut
                    lastFin = dfin
        if dateDebut == None:
            mess = u"Il n'y a pas d'exercice ouvert pour la date %s: %s \n V�rifiez la date comptable" % (labelDate,str(dateInput))
            if alertes : wx.MessageBox(mess)
            if approche and lastDeb != None :
                if dateInput.month >= lastDeb.month : 
                    anneeDeb = dateInput.year
                else: anneeDeb = dateInput.year - 1
                if dateInput.month > lastFin.month :
                    anneeFin = dateInput.year + 1
                else: anneeFin = dateInput.year
                dateDebut = datetime.date(anneeDeb,lastDeb.month,lastDeb.day)
                dateFin = datetime.date(anneeFin,lastFin.month,lastFin.day)
            else :
                return (None,None)
        if str(dateFin) > str(dateDebut):
            return (dateDebut,dateFin)
        else:
            mess = u"Incoh�rence dans les dates de l'exercie du %s au %s" % (str(dateDebut),str(dateFin))
            if alertes : wx.MessageBox(mess)
        return (None,None)

    def GetDateFacture(self,IDinscription, IDactivite,today,alertes = True, retourExercice = False ):
        msg = Messages()
        exercice = None
        dateFacture = None
        if IDactivite > 0:
            dateDeb, dateFin = aGestionArticle.DebutFin_Activite(self,IDactivite)
            if dateFin == None or dateDeb == None:
                # l'activit� n'a pas de dates d�finies
                    if alertes :
                        msg.Box(titre = u"Date de l'activit� non d�fine",message = u"Il n'a pas �t� possible de trouver les dates de l'activit�" )
        else:
            # le niveau famille stocke l'ann�e de l'activit� � la place de l'IDinscription, on l'affecte au 01 janvier
            dateDeb, dateFin = self.GetExercice(datetime.date(IDinscription,1,1), alertes = alertes)
            if dateDeb == None:
                dateDeb = datetime.date(IDinscription,1,1)
                dateFin = datetime.date(IDinscription,1,1)

        exTodayD,exTodayF = self.GetExercice(today, alertes= alertes )
        if dateFin != None and dateDeb != None:
            exActD,exActF = self.GetExercice(dateFin,labelDate = u"de fin d'activit�", alertes = alertes)
            if exActD != None:
                exercice = True
            else:
                exercice = False
            if today <= dateDeb :
                dateFacture = dateDeb
                if alertes :
                    # la date du jour pr�c�de le d�but de l'activit�, choix n�cessaire
                    txt1 = u"Facture � la date du jour_____________ %s" %(str(today))
                    txt2 = u"Facture � la date de d�but d'activit�_ %s" %(str(dateDeb))
                    retour = msg.Choix([(1,txt1),(2,txt2)],u"La facture n'est pas cens�e pr�c�der l'activit�,\nQuel est votre choix?")
                    if retour[0] == 1 :
                        dateFacture = today
                    elif retour[0] == 2:
                        dateFacture = dateDeb
                    else : dateFacture = None
            elif today > dateFin :
                # la fin d'activit� pr�c�de la facture, on facture donc tardivement, v�rifier la concordance des exercices
                if exActD == None:
                    #exercice de l'activit� non ouvert
                    if alertes :
                        msg.Box(titre = u"l'Exercice de l'activit� est ferm�",message = u"Vous ne facturez pas cette activit� dans le bon exercice" )
                    dateFacture = None
                else:
                    #exercice de l'activit� ouvert
                    if exTodayD == None:
                        # seul l'exercice de l'activit� est ouvert, on facture encore N-1, ok
                        dateFacture = exActF
                    else:
                        # les deux exercices sont ouverts
                        if exTodayD == exActD: # on est dans le m�me exercice, ok
                            dateFacture = today
                        else :
                            # choix n�cessaire car le deux exerices sont diff�rents
                            retour=[None]
                            dateFacture = dateFin
                            if alertes :
                                txt1 = u"Exercice activit� du %s au %s" %(str(exActD),str(exActF))
                                txt2 = u"Exercice du jour  du %s au %s" %(str(exTodayD),str(exTodayF))
                                retour = msg.Choix([(1,txt1),(2,txt2)],u"Deux exercices sont possibles, dans lequel faut-il affecter la pi�ce?")
                                if retour[0] == 1 :
                                    dateFacture = dateFin
                                elif retour[0] == 2:
                                    dateFacture = today
                                else :
                                    dateFacture = None
            else : #on facture pendant la dur�e de l'activit�, ok
                dateFacture = today
        if dateFacture == None and exTodayD != None:
            # on affecte la date du jour mais il y a probl�me
            if alertes :
                msg.Box(titre = u"Probl�me avec les Exercices comptables",message = u"La facture prend la date du jour, \nmais ce n'est pas correct au vu des exercices ouverts et de l'activit�" )
                dateFacture = today
        if dateFacture == None and dateFin != None:
            # on affecte la date fin activit� mais il y a probl�me
            if alertes :
                msg.Box(titre = u"Probl�me avec les Exercices comptables",message = u"La facture prend la date de fin activit�, \nmais ce n'est pas correct au vu des exercices ouverts" )
            dateFacture = dateFin
        if self.GetExercice(dateFacture, alertes = alertes) == (None,None):
            # aucun exercice ouvert n'a permis de fixer une date de facture
            if alertes :
                msg.Box(titre = u"Exercices comptables",message = u"Pas d'exercice ouvert ni pour l'activit� ni pour aujourd'hui\nLa facture est toutefois dat�e de ce jour" )
                dateFacture = today # valeur par d�faut mais probl�me
        msg.Close()
        if retourExercice:
            return dateFacture,exercice
        return dateFacture

# ------------- Fonctions de MAJ de la base de donn�es ---------------------------------------------------------------

class Ajout_TablesMat(wx.Frame):
    def __init__(self):
        """Constructor"""
        wx.Frame.__init__(self, parent=None, size=(550, 400))
        DB1 = DB(suffixe="DATA", modeCreation=False)
        DB1.CreationTables(DATA_Tables.DB_DATA)
        if DB1.retourReq <> "ok" :
            dlg = wx.MessageDialog(self, _(u"Erreur base de donn�es.\n\nErreur : %s") % DB1.retourReq, _(u"Erreur de cr�ation de fichier"), wx.OK | wx.ICON_ERROR)
            dlg.ShowModal()
            dlg.Destroy()
        DB1.Close()

class Ajout_IndexMat(wx.Frame):
    def __init__(self):
        """Constructor"""
        wx.Frame.__init__(self, parent=None, size=(550, 400))
        DB1 = DB(suffixe="DATA", modeCreation=False)
        DB1.CreationTousIndex(aDATA_Tables.DB_PK)
        if DB1.retourReq <> "ok" :
            dlg = wx.MessageDialog(self, _(u"Erreur base de donn�es.\n\nErreur : %s") % DB1.retourReq, _(u"Erreur de cr�ation d'index PK"), wx.OK | wx.ICON_ERROR)
            dlg.ShowModal()
            dlg.Destroy()
        DB1.CreationTousIndex(aDATA_Tables.DB_INDEX)
        if DB1.retourReq <> "ok" :
            dlg = wx.MessageDialog(self, _(u"Erreur base de donn�es.\n\nErreur : %s") % DB1.retourReq, _(u"Erreur de cr�ation d'index IX"), wx.OK | wx.ICON_ERROR)
            dlg.ShowModal()
            dlg.Destroy()
        DB1.Close()

# ------------- Affichages --------------- ---------------------------------------------------------------
def MessageBox(self,mess,titre = u"Erreur Bloquante !",YesNo = False):
    if YesNo :
        dlg = wx.MessageDialog(self, _(mess),_(titre) , wx.YES_NO|wx.NO_DEFAULT|wx.CANCEL| wx.ICON_EXCLAMATION)
    else :
        dlg = wx.MessageDialog(self, _(mess),_(titre) , wx.OK | wx.ICON_EXCLAMATION)
    ret = dlg.ShowModal()
    dlg.Destroy()
    return ret

class Messages(wx.Frame):
    def __init__(self):
        """Constructor"""
        wx.Frame.__init__(self, parent=None, size=(550, 400))

    def Box(self, titre= u"Erreur Bloquante", message= u"Avertissement",YesNo = False ):
        if YesNo :
            dlg = wx.MessageDialog(self,  message, titre , wx.YES_NO|wx.NO_DEFAULT|wx.CANCEL| wx.ICON_QUESTION)
        else :
            dlg = wx.MessageDialog(self, message, titre, wx.OK | wx.ICON_EXCLAMATION)
        ret = dlg.ShowModal()
        dlg.Destroy()
        return ret

    def Choix(self,listeTuples=[(1,"a"),(2,"b")], titre = u"Choisissez", intro = u"Dans la liste"):
        dlg = aCTRL_ChoixListe.Dialog(self,LargeurCode= 30,LargeurLib= 200,minSize = (500,300), listeOriginale=listeTuples, titre = titre, intro = intro)
        interroChoix = dlg.ShowModal()
        if interroChoix == wx.ID_OK :
            sel=dlg.choix
            return sel
        else:
            return None,None

def Decod(valeur):
    if valeur == None:
        valeurDecod =  u""
    elif type(valeur) in (int, long, float):
        valeurDecod = str(valeur)
    else :
        try :
            valeurDecod = valeur.decode('utf8')
        except:
            try :
                valeurDecod = unicode(str(valeur).decode('utf8'))
            except:
                try:
                    valeurDecod = unicode(str(valeur).decode('iso-8859-15'))
                except: valeurDecod = valeur
    try :
        u"�����$�"+ valeurDecod
    except :
        MessageBox(None,"Probleme Codec valeur : %s" % valeur)
    return valeurDecod

def AppelDB(fonction,ID):
    result = "KO"
    if fonction != None and ID != None:
        db = DB()
        if type(ID)== int or type(ID)== long:
            f="db."+fonction + '(%d)'% ID
            result = eval(f)
        elif type(ID)== str:
            f="db."+fonction + '(%s)'% ID
            result = eval(f)
        else:
            print "Type de l'ID non g�r� : ",type(ID)
        db.Close()
    return result


def AfficheConnexionOuvertes():
    """ Affiche les connexions non ferm�es """
    if len(DICT_CONNEXIONS) > 0 :
        print "--------- Attention, il reste %d connexions encore ouvertes : ---------" % len(DICT_CONNEXIONS)
        for IDconnexion, requetes in DICT_CONNEXIONS.iteritems() :
            print ">> IDconnexion = %d (%d requetes) :" % (IDconnexion, len(requetes))
            for requete in requetes :
                print requete

if __name__ == "__main__":
    app = wx.App()
    f = Ajout_TablesMat()
    f = Ajout_IndexMat()
    DB1 = DB()
    #retour = DB1.UtilisateurActuel()
    #DB = Messages(None)
    DB1.Close()
    #MessageBox(None,retour,titre="R�sultat Test")

    # Update de la base de donn�es : def ConversionDB(self, versionFichier=(0, 0, 0, 0) )
    # Lancement des script de Update � l'ouverture
